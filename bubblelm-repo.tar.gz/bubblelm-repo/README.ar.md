# BubbleLM — دليل المطورين

مكتبة بايثون لتدريب نموذج لغوي على نصوصك أنت، وفحص كل إجابة قبل إرسالها مقابل ذاكرة شجرية مبنية من نفس النصوص.
لو الدليل ناقص أو المصادر متعارضة، المكتبة بترجّع امتناع عن الإجابة بدل التخمين.

**المؤلف:** مصطفى اشرف مصطفي الدعوشي (Mostafa Ashraf Mostafa Eldoushy)
**الترخيص:** Apache 2.0 (ملفي `LICENSE` و`NOTICE`)
**الدليل الكامل بالإنجليزي:** [README.md](README.md)

## المفاهيم

| الجزء | معناه |
|---|---|
| **الفقاعة** | مجموعة توكنات. كل مستند يتحول لشجرة: مستند ← فقرة ← جملة ← توكن، وكل عقدة فقاعة. |
| **فهرس الفقاعات** | قوائم معكوسة من التوكن للجمل والفقرات والمستندات اللي فيها. |
| **التفعيل** | وقت توليد الرد، التوكنات المرجّحة بتفعّل الفقاعات اللي بتحتويها. |
| **درجة التحقق** | تغطية موزونة (0 إلى 1) للسؤال والرد داخل أقوى فقاعة. |
| **العتبة τ** | الرد اللي درجته أقل منها يتحول لامتناع. `calibrate` بتختارها من أمثلتك. |
| **السكراتش باد** | سجل مراجعة لكل سؤال: كل مرشح ودرجته والقرار. |
| **الفقاعة الرئيسية** | الهوية والقواعد خارج الأوزان، وتعديلها لا يحتاج إعادة تدريب. |
| **خانات الأوزان** | حتى 20 نسخة أوزان مستقلة في المشروع الواحد. |
| **الأدوات** | دوال بايثون من عندك تجاوب أسئلة معينة بشكل حتمي. |
| **وضع التفكير** | مرات فحص إضافية (بحث أوسع، إعادة صياغة، تصويت بين النسخ) قبل الإجابة. |

## التثبيت

```bash
pip install -e .                 # numpy, torch
pip install -e ".[vision]"       # اختياري للصور والفيديو
pip install -e ".[dev]"          # pytest
```

## بداية سريعة

```python
from bubblelm import BubbleLM, EngineConfig, ModelConfig

bl = BubbleLM("my_project", EngineConfig(model=ModelConfig(epochs=80)))
bl.add_texts(["Aron lives in Cairo. Aron works as a doctor."])
bl.build()
bl.train(name="first", log=print)
bl.calibrate([("Aron lives in", "cairo"), ("Gamal lives in", None)])
a = bl.ask("Aron lives in")
print(a.text, a.status, a.verification)
bl.save()
```

السؤال لازم يكون **بداية جملة** ممكن النص التدريبي يكون كتبها. لو عايز أسئلة بصيغة محادثة، ضيف أزواج سؤال/جواب في بيانات التدريب.
حالات الإجابة: `answered`، `abstained`، `rule_response`، `refused`، `tool_response`، `tool_error`.

## بياناتك

الصيغ المقبولة: `.txt` و`.md` (مستند لكل ملف) و`.jsonl` (`{"text": ...}` في كل سطر) ومجلدات منها. استخدم `add_text` / `add_texts` / `add_path` ثم `build()`.
التقسيم على مستوى الكلمة ويدعم العربية (إزالة التشكيل والتطويل، توحيد الألف والياء، تحويل الأرقام الهندية).
لو بياناتك قليلة اضبط `IndexConfig` (`rel_min_ratio`, `rel_min_df`, `stop_ratio`). المطابقة الناعمة محتاجة نص إضافي بدون تصنيف: `bl.fit_soft(aux_texts)`.

## النسخ العشرين وأحجامها

كل مشروع فيه 20 خانة. كل خانة فيها `model.pt` و`vocab.json` و`meta.json`. الفهرس والمطابقة والفقاعة الرئيسية مشتركين.

```python
bl.train(name="small")               # أول خانة فاضية
bl.train(slot=7, use_preset=True)    # معمارية 3B
bl.versions(); bl.use(3); bl.ask(q, version=5)
bl.compare(examples); bl.delete_version(2)
```

الخانات: 100M، 500M، 1B، 1.5B، 2B، 2.5B، 3B، 4B، 5B، 6B، 8B، 10B، 12B، 14B، 16B، 18B، 20B، 24B، 27B، 30B (`bubblelm presets` بتطبع الجدول).
الخانة الحادية والعشرين تطلع `RegistryFull`.

## التدريب

حقول `ModelConfig`: `arch`, `d_model`, `layers`, `heads`, `hidden`, `maxlen`, `epochs`, `lr`, `batch_size`, `weight_decay`, `seed`, `threads`,
`device`, `dtype`, `grad_accum`, `checkpoint`, `distributed`.

- الذاكرة: حوالي 16 بايت لكل معامل (float32) أو 18 (bfloat16). `CapacityError` لو تجاوزت 80% من المتاح، و`allow_large=True` للتجاوز.
- `grad_accum=N` لتجميع التدرجات. `checkpoint=True` لتوفير الذاكرة بإعادة الحساب.
- `distributed=True` لتدريب `DistributedDataParallel`، وتشغّل نفس السكربت بـ `torchrun --nproc_per_node=N script.py`، والمعالج رقم 0 هو اللي يحفظ.
- `store_half=True` لتخزين الأوزان fp16.

## خيارات فك التشفير والتحقق

`DecodeConfig`: `beam`, `topk`, `lam`, `mu`, `level` (`sent`/`par`/`doc`/`tree`), `max_new`, `verify`, `relation`, `consensus` (كشف التعارض), `soft` (مطابقة ناعمة).
تقدر تغيّرها لكل استدعاء: `bl.ask(q, consensus=True, soft=True)`.

## الوضع الخفيف

`bl.set_profile("light")` (أو `accurate` / `balanced`) بيفعّل: المسار السريع (إجابة من الفهرس بدون النموذج لو فيه استمرار واحد فقط)، ضغط int8،
كاش للإجابات، بحث أصغر. كمان `runtime.kv_cache` و`runtime.threads`. لازم تعيد المعايرة بعد تغيير البروفايل.

## الأدوات

```python
bl.enable_builtin_tools()
@bl.tool(patterns=[r"^add (?P<a>\d+) and (?P<b>\d+)$"])
def add(a: int, b: int):
    return a + b
bl.ask("add 2 and 40").text   # 42
```

الترتيب: قاعدة الفقاعة الرئيسية ← أداة ← (مسار سريع أو نموذج). الاختيار بتعبيرات منتظمة وليس بالنموذج. `bl.tool_schemas()` بتطلّع مخططات بصيغة OpenAI.
ملاحظات: تحقق من المدخلات داخل الدالة، لا يوجد sandbox، والأدوات كود فلا تُحفظ مع المشروع (سجّلها عند التشغيل).

## وضع التفكير

`bl.ask(q, think="low" | "medium" | "high")`: `low` بحث أوسع مع كشف التعارض، `medium` يضيف صياغات بديلة موجودة فعلاً في النصوص، `high` يضيف سؤال نسخ أوزان أخرى والتصويت.
لو الاتفاق أقل من `think.min_agree` بيمتنع. الخطوات في `a.thinking_text()`.

## الفقاعة الرئيسية

```python
bl.set_identity("Atlas", "Acme")
bl.add_rule("no_pay", "refuse", when_any=["salary"], text="I do not discuss pay.")
```

## الصور والفيديو (اختياري)

`fit_visual` ثم `add_image` / `add_video` ثم `build()` ثم `ask_media` و`calibrate_media`. الصورة تتقسم لشبكة، كل خلية توكن بصري `v:k`، والفيديو فقرة لكل إطار.

## سطر الأوامر

`bubblelm --project P add | train | calibrate | ask | evaluate | compare | versions | use | delete-version | presets | soft | profile | export | import | add-image | add-video | fit-visual | ask-media`

## هيكل المشروع على القرص

`config.json`, `corpus.jsonl.gz`, `main_bubble.json`, `soft.npz`, `visual.npz`, `state.json`, و`weights/slot_01 ... slot_20` (كل خانة: model.pt, vocab.json, meta.json).

## التوسعة

- معمارية جديدة: كلاس في `model.py` ثم فرع في `build_model`.
- تدريب مختلف: استبدل `train_model` في `train.py` وحافظ على `make_sequences` وصيغة الـ registry.
- إشارة تحقق جديدة: دالة في `BubbleIndex` تُستدعى من `verify`، وتظهر نتيجتها في `info`.
- وسيط جديد: توكنات نصية ببادئة مميزة داخل `Document.visual`.

## الاختبارات والمساهمة

`pytest`. الكود بدون تعليقات أو docstrings، والتوثيق كله في الريدمي. أي إشارة تحقق لازم تظهر في `Answer.candidates[i]["info"]`. المساهمات تحت Apache 2.0.
