import glob
import json
import os
import sys

import numpy as np

root = sys.argv[1] if len(sys.argv) > 1 else "results"
runs = {"clean": [], "noisy": []}
for p in sorted(glob.glob(os.path.join(root, "*_seed*.json"))):
    d = json.load(open(p))
    runs[d["condition"]].append(d["results"])


def avg(rows, cond, key):
    xs = [r[cond][key] for r in rows]
    return float(np.mean(xs)), float(np.std(xs))


def fmt(m, s, digits=3):
    return f"{m:.{digits}f} ±{s:.{digits}f}"


out = []
for cond, title in [("clean", "Clean corpus"), ("noisy", "Noisy corpus (10% of fact statements written wrong)")]:
    rs = runs[cond]
    if not rs:
        continue
    names = list(rs[0].keys())
    out += [f"### {title} — standard questions ({len(rs)} seeds, mean ± std)", "",
            "| System | Recall | Precision | Hallucination rate | Utility | Recall@P99 |", "|---|---|---|---|---|---|"]
    for n in names:
        cells = [fmt(*avg([r[n] for r in rs], "standard", k)) for k in
                 ("recall", "precision", "hallucination_rate")]
        u = avg([r[n] for r in rs], "standard", "utility")
        r99 = avg([r[n] for r in rs], "standard", "recall_at_precision_99")
        out.append(f"| {n} | " + " | ".join(cells) + f" | {u[0]:.0f} ±{u[1]:.0f} | {fmt(*r99)} |")
    out.append("")
    if cond == "clean":
        out += [f"### Clean corpus — paraphrased questions (question wording never seen in training, {len(rs)} seeds)", "",
                "| System | Recall | Precision | Wrong answers (of 300) |", "|---|---|---|---|"]
        for n in names:
            has_both = "paraphrase_noaux" in rs[0][n]
            for key, label in (("paraphrase_aux", " (with auxiliary text)" if has_both else ""),
                               ("paraphrase_noaux", " (no auxiliary text)")):
                if key in rs[0][n]:
                    rec = fmt(*avg([r[n] for r in rs], key, "recall"))
                    pre = fmt(*avg([r[n] for r in rs], key, "precision"))
                    wr = avg([r[n] for r in rs], key, "wrong_known")
                    out.append(f"| {n}{label} | {rec} | {pre} | {wr[0]:.1f} ±{wr[1]:.1f} |")
        out.append("")
open(os.path.join(root, "results.md"), "w").write("\n".join(out))
print("\n".join(out))
