from __future__ import annotations

import argparse
import collections
import json
import os
import random
import shutil
import sys
import tempfile
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from bubblelm import BubbleLM, EngineConfig, ModelConfig  # noqa: E402

ATTRS = ["city", "job", "salary", "pet", "color", "hobby"]
VALUES = {
    "city": ["cairo", "giza", "luxor", "aswan", "tanta", "suez", "dubai", "riyadh", "doha", "amman", "beirut",
             "tunis", "rabat", "paris", "london", "berlin", "rome", "madrid", "tokyo", "seoul", "delhi", "lagos",
             "nairobi", "oslo", "lima"],
    "job": ["doctor", "engineer", "teacher", "pilot", "chef", "nurse", "farmer", "lawyer", "painter", "driver",
            "tailor", "baker", "banker", "guard", "editor", "singer", "dentist", "plumber", "joiner", "clerk",
            "pharmacist", "judge", "barber", "sailor", "miner"],
    "salary": [f"lvl{i}" for i in range(1, 11)],
    "pet": ["cat", "dog", "parrot", "rabbit", "turtle", "hamster", "horse", "goat", "fish", "falcon", "lizard",
            "canary", "ferret", "donkey", "snake"],
    "color": ["red", "blue", "green", "yellow", "black", "white", "purple", "orange", "pink", "brown", "gray",
              "teal"],
    "hobby": ["chess", "football", "swimming", "reading", "drawing", "hiking", "cooking", "fishing", "gaming",
              "cycling", "singing", "dancing", "gardening", "running", "writing", "photography", "climbing",
              "sailing", "knitting", "skating"],
}
TEMPLATES = {
    "city": ["{n} lives in {v} .", "{n} is from {v} .", "the home of {n} is {v} ."],
    "job": ["{n} works as {v} .", "{n} is a {v} .", "the job of {n} is {v} ."],
    "salary": ["{n} earns {v} .", "the pay of {n} is {v} .", "{n} gets {v} ."],
    "pet": ["{n} has a pet {v} .", "{n} keeps a {v} .", "the pet of {n} is {v} ."],
    "color": ["{n} likes the color {v} .", "the favorite color of {n} is {v} .", "{n} prefers {v} ."],
    "hobby": ["{n} enjoys {v} .", "the hobby of {n} is {v} .", "{n} spends time on {v} ."],
}
PARAPHRASE = {"city": "{n} resides in", "job": "{n} is employed as", "salary": "{n} receives",
              "pet": "{n} owns a pet", "color": "{n} adores the color", "hobby": "{n} practices"}
SYL = ["ka", "ro", "mi", "vel", "su", "na", "dor", "li", "tan", "be", "zu", "fa", "ren", "mo", "ki", "sa", "lo",
       "pe", "xi", "wa", "har", "ned", "qui", "bor"]


def make_names(rng, n, taken):
    out = set()
    while len(out) < n:
        nm = "".join(rng.choice(SYL) for _ in range(rng.choice([2, 3])))
        if nm not in taken and nm not in out:
            out.add(nm)
    out = sorted(out)
    rng.shuffle(out)
    return out


def taken_words():
    t = {w for vs in VALUES.values() for w in vs}
    for ts in TEMPLATES.values():
        for x in ts:
            t |= set(x.split())
    for x in PARAPHRASE.values():
        t |= set(x.split())
    return t | {"model", "company", "name"}


def build(seed, n_known, n_unknown, n_aux, noise):
    rng = random.Random(seed)
    names = make_names(rng, n_known + n_unknown + n_aux, taken_words())
    known, unknown, aux = names[:n_known], names[n_known:n_known + n_unknown], names[n_known + n_unknown:]
    world = {n: {a: rng.choice(VALUES[a]) for a in ATTRS} for n in known}
    texts = []
    for n, facts in world.items():
        for d in range(rng.choices([1, 2, 3], [0.5, 0.3, 0.2])[0]):
            order = ATTRS[:]
            if d == 0:
                rng.shuffle(order)
            else:
                order = [rng.choice(ATTRS) for _ in range(6)]
            paras = []
            for pi in range(2):
                sents = []
                for a in order[pi * 3:(pi + 1) * 3]:
                    v = facts[a]
                    if noise and rng.random() < noise:
                        v = rng.choice([x for x in VALUES[a] if x != v])
                    sents.append(TEMPLATES[a][rng.randrange(3)].format(n=n, v=v))
                paras.append(" ".join(sents))
            texts.append("\n\n".join(paras))
    aux_texts = []
    for n in aux:
        aux_texts.append("\n\n".join(" ".join(PARAPHRASE[a].format(n=n) + f" {rng.choice(VALUES[a])} ."
                                              for a in ATTRS[i:i + 3]) for i in (0, 3)))
    ents = known[:]
    rng.shuffle(ents)
    nval = int(0.3 * len(ents))
    val_e, test_e = ents[:nval], ents[nval:]
    val_u, test_u = unknown[:len(unknown) // 3], unknown[len(unknown) // 3:]

    def queries(es, us, para=False):
        qs = []
        for n in es:
            for a in ATTRS:
                tpl = PARAPHRASE[a] if para else TEMPLATES[a][0].split("{v}")[0]
                qs.append((tpl.format(n=n), world[n][a]))
        if not para:
            for n in us:
                for a in rng.sample(ATTRS, 2):
                    qs.append((TEMPLATES[a][0].split("{v}")[0].format(n=n), None))
        return qs

    qpara = queries(test_e, [], True)
    rng.shuffle(qpara)
    return dict(texts=texts, aux=aux_texts, val=queries(val_e, val_u), test=queries(test_e, test_u),
                para=qpara[:300], world=world)


CONFIGS = [
    ("plain model + confidence threshold", dict(verify=False, beam=1, topk=1, lam=0.0, mu=0.0, relation=False)),
    ("bubbles v1 (nudge+rerank+verify+relation)", dict()),
    ("v1 + soft matching", dict(soft=True)),
    ("v1 + conflict detection", dict(consensus=True)),
    ("v1 + soft + conflict", dict(soft=True, consensus=True)),
]


def evaluate_all(bl, data, matcher_aux, matcher_noaux, log):
    out = {}
    for name, ov in CONFIGS:
        bl.matcher = matcher_aux
        tau = bl.calibrate(data["val"], **ov)
        row = {"standard": bl.evaluate(data["test"], tau=tau, **ov)}
        row["paraphrase_aux"] = bl.evaluate(data["para"], tau=tau, **ov)
        if ov.get("soft"):
            bl.matcher = matcher_noaux
            row["paraphrase_noaux"] = bl.evaluate(data["para"], tau=tau, **ov)
        out[name] = row
        s = row["standard"]
        p = row["paraphrase_aux"]
        log(f"  {name:45s} std: recall={s['recall']:.3f} prec={s['precision']:.3f} hall={s['hallucination_rate']:.4f} "
            f"U={s['utility']:.0f} | para(aux): recall={p['recall']:.3f} wrong={p['wrong_known']}")
    bl.matcher = matcher_aux
    return out


def run(seed, epochs, entities, unknown, noise, workdir, log, aux=400):
    data = build(seed, entities, unknown, aux, noise)
    mc = ModelConfig(epochs=epochs, seed=seed, threads=2)
    bl = BubbleLM(workdir, EngineConfig(model=mc))
    bl.add_texts(data["texts"])
    bl.build()
    log(f"index {bl.index.sizes()}")
    t0 = time.time()
    bl.train(name=f"seed{seed}", log=lambda s: log("   " + s))
    log(f"trained in {time.time() - t0:.0f}s")
    m_aux = bl.fit_soft(data["aux"])
    from bubblelm.embeddings import SoftMatcher
    m_noaux = SoftMatcher(bl.config.soft).fit(list(bl.corpus.lm_sentences()), bl.index)
    return evaluate_all(bl, data, m_aux, m_noaux, log)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--entities", type=int, default=400)
    ap.add_argument("--unknown", type=int, default=150)
    ap.add_argument("--noise", type=float, default=0.1)
    ap.add_argument("--no-noise-run", action="store_true")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    t0 = time.time()

    def log(s):
        print(f"[{time.time() - t0:7.1f}s] {s}", flush=True)

    for seed in args.seeds:
        for cond, noise in [("clean", 0.0)] + ([] if args.no_noise_run else [("noisy", args.noise)]):
            path = os.path.join(args.out, f"{cond}_seed{seed}.json")
            if os.path.exists(path):
                continue
            log(f"== seed {seed} / {cond} ==")
            wd = tempfile.mkdtemp(prefix="bench_")
            try:
                res = run(seed, args.epochs, args.entities, args.unknown, noise, wd, log)
            finally:
                shutil.rmtree(wd, ignore_errors=True)
            with open(path, "w") as f:
                json.dump(dict(seed=seed, condition=cond, noise=noise, results=res), f, indent=1)


if __name__ == "__main__":
    main()
