### Clean corpus — standard questions (3 seeds, mean ± std)

| System | Recall | Precision | Hallucination rate | Utility | Recall@P99 |
|---|---|---|---|---|---|
| plain model + confidence threshold | 0.636 ±0.085 | 0.905 ±0.026 | 0.063 ±0.026 | 1095 ±82 | 0.212 ±0.277 |
| bubbles v1 (nudge+rerank+verify+relation) | 0.881 ±0.019 | 1.000 ±0.000 | 0.000 ±0.000 | 1680 ±33 | 0.883 ±0.017 |
| v1 + soft matching | 0.881 ±0.019 | 1.000 ±0.000 | 0.000 ±0.000 | 1680 ±33 | 0.883 ±0.017 |
| v1 + conflict detection | 0.881 ±0.019 | 1.000 ±0.000 | 0.000 ±0.000 | 1680 ±33 | 0.883 ±0.017 |
| v1 + soft + conflict | 0.881 ±0.019 | 1.000 ±0.000 | 0.000 ±0.000 | 1680 ±33 | 0.883 ±0.017 |

### Clean corpus — paraphrased questions (question wording never seen in training, 3 seeds)

| System | Recall | Precision | Wrong answers (of 300) |
|---|---|---|---|
| plain model + confidence threshold | 0.176 ±0.084 | 0.921 ±0.058 | 5.0 ±4.1 |
| bubbles v1 (nudge+rerank+verify+relation) | 0.000 ±0.000 | 1.000 ±0.000 | 0.0 ±0.0 |
| v1 + soft matching (with auxiliary text) | 0.757 ±0.040 | 0.971 ±0.012 | 6.7 ±2.5 |
| v1 + soft matching (no auxiliary text) | 0.000 ±0.000 | 1.000 ±0.000 | 0.0 ±0.0 |
| v1 + conflict detection | 0.000 ±0.000 | 1.000 ±0.000 | 0.0 ±0.0 |
| v1 + soft + conflict (with auxiliary text) | 0.757 ±0.040 | 0.971 ±0.012 | 6.7 ±2.5 |
| v1 + soft + conflict (no auxiliary text) | 0.000 ±0.000 | 1.000 ±0.000 | 0.0 ±0.0 |

### Noisy corpus (10% of fact statements written wrong) — standard questions (3 seeds, mean ± std)

| System | Recall | Precision | Hallucination rate | Utility | Recall@P99 |
|---|---|---|---|---|---|
| plain model + confidence threshold | 0.538 ±0.035 | 0.869 ±0.032 | 0.074 ±0.023 | 965 ±37 | 0.018 ±0.004 |
| bubbles v1 (nudge+rerank+verify+relation) | 0.804 ±0.016 | 0.897 ±0.001 | 0.082 ±0.001 | 1397 ±26 | 0.000 ±0.000 |
| v1 + soft matching | 0.804 ±0.016 | 0.897 ±0.001 | 0.082 ±0.001 | 1397 ±26 | 0.000 ±0.000 |
| v1 + conflict detection | 0.793 ±0.016 | 0.903 ±0.001 | 0.076 ±0.002 | 1389 ±23 | 0.000 ±0.000 |
| v1 + soft + conflict | 0.793 ±0.016 | 0.903 ±0.001 | 0.076 ±0.002 | 1389 ±23 | 0.000 ±0.000 |
