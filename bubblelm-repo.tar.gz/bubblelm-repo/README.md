# BubbleLM

Train a small language model on **your own text**, and verify every answer it gives against a hierarchical
memory of that same text before the answer is sent. If the evidence is missing or the sources disagree,
the system says it is not sure instead of guessing.

**Author:** Mostafa Ashraf Mostafa Eldoushy (مصطفى اشرف مصطفي الدعوشي)
**License:** Apache License 2.0 (see `LICENSE` and `NOTICE`)

Arabic summary: [README.ar.md](README.ar.md)

---

## 1. The idea in one page

1. Every training document becomes a tree: **document → paragraph → sentence → token**. Every node is a *bubble*
   (the set of tokens below it). Tokens are the "links".
2. While the model writes a reply, its likely next tokens *activate* the bubbles that contain them. A bubble that
   contains several tokens from the question **and** the draft reply is strong evidence.
3. Before an answer is sent, the draft is scored against the strongest bubble (the **verification score**,
   a weighted token-coverage between 0 and 1). Drafts below a calibrated threshold τ become an abstention.
4. A **scratchpad** records every candidate, its score and the decision, so an answer can be audited.
5. A **main bubble** stores identity and restriction rules outside the weights. Changing the model's name or
   banning a topic needs no retraining.

Two extensions (this release) sit on top of the original method:

| Extension | What it does | When it helps |
|---|---|---|
| **Conflict detection** (`consensus=True`) | Counts the distinct documents that support the answer and the distinct documents that support a different continuation. If the answer is not at least 2× the rival it abstains, otherwise it scales the score by the majority share. | Training text that contradicts itself. |
| **Soft matching** (`soft=True`) | Learns word vectors (PPMI + SVD) from the corpus and optional unlabelled extra text, and rewrites unseen question words to the nearest known relation word before decoding. | Questions worded differently from the training text. |

Both are off by default and switch per call.

## 2. Install

```bash
pip install -e .                 # core: numpy, torch
pip install -e ".[vision]"       # optional: Pillow, opencv-python-headless, imageio
pip install -e ".[dev]"          # pytest
```

Tested on Python 3.13 (the code avoids newer-only syntax at runtime but older versions were not run). Images and video are optional: nothing in the core imports them.

## 3. Quick start

```python
from bubblelm import BubbleLM, EngineConfig, ModelConfig

bl = BubbleLM("my_project", EngineConfig(model=ModelConfig(epochs=80)))
bl.add_texts(["Kamo lives in Cairo. Kamo works as a doctor.", "..."])   # or bl.add_path("folder_or_file")
bl.build()                                    # bubble index
bl.train(name="v1", log=print)                # trains weights, stores them in slot 1
bl.calibrate([("Kamo lives in", "cairo"), ("Zorbo lives in", None)])   # tunes the abstention threshold

a = bl.ask("Kamo lives in")
a.text, a.status, a.verification, a.evidence, a.scratchpad.render()
bl.save()
```

`examples/quickstart.py` is the same flow, runnable. With a corpus this small the relation check has nothing to separate names from relation words, so wrong-attribute drafts (a job offered for a city question) can still score high; use a few hundred sentences or tune `IndexConfig` as described in section 6. The same flow from the shell:

```bash
bubblelm --project my_project add docs/
bubblelm --project my_project train --epochs 80 --name v1
bubblelm --project my_project calibrate examples.jsonl
bubblelm --project my_project ask "Kamo lives in" --scratchpad
```

### How questions must be written

The model is a closed-book language model trained on sentences, so a question is the **beginning of a sentence
that the training text could have written** ("Kamo lives in", "the pet of Rimi is"). It is not a chat model and
it does not parse "Where does Kamo live?". To get chat-style questions, put question/answer pairs in the training
text as sentences ("Q where does Kamo live A Cairo") and ask with the matching prefix.

### Answer statuses

| `status` | Meaning |
|---|---|
| `answered` | verification score ≥ τ |
| `abstained` | score below τ, or no candidate. `reason` says why (`conflict between sources`, `relation not supported`, `verification below threshold`) |
| `rule_response` / `refused` | the main bubble answered or refused before the model ran |

`a.evidence` lists the source sentences and documents that support the answer.

## 4. Your own data

Accepted inputs: `.txt`, `.md` (one document per file), `.jsonl` (`{"text": ..., "id": ..., ...}` per line), or
directories of those. Paragraphs are separated by a blank line, sentences by `. ! ? ؟ …` or a line break.

Tokenization (`bubblelm/tokenizer.py`) is word-level and Unicode aware: lower-casing, NFKC, Arabic diacritics and
tatweel removed, alef variants and ya unified, Arabic-Indic digits converted. Punctuation is dropped. Change it
through `TokenizerConfig`. Tokens that never occur in training are `<unk>` in the language model but are still
useful as *evidence* in the index (an unseen name is the strongest evidence that the answer is unsupported).

Practical notes:

- Facts the model must be able to answer should appear at least once as a plain sentence. Facts that appear once
  are learned and retrieved, but check `recall` on a held-out set.
- Calibrate on questions the system has **not** been trained to answer as well as ones it has. The threshold is
  the one that maximises `+1 correct (or correct abstention) −1 wrong answer` on the examples you give.
- Re-run `bl.build()` after adding documents; `ask` rebuilds a stale index automatically.

## 5. The 20 weight versions

A project has 20 slots (`MAX_VERSIONS = 20`). Each slot stores its own weights, vocabulary, architecture,
threshold τ and metrics in `weights/slot_NN/`. The bubble index, embeddings and main bubble are shared by all
slots because they are keyed by token strings, not by model ids.

```python
bl.train(name="small")                       # first free slot
bl.train(slot=7, use_preset=True)            # the 3B architecture
bl.versions(); bl.use(3); bl.ask(q, version=5)
bl.compare(examples)                         # metrics for every slot
bl.ask_versions(q)                           # same question to every slot
bl.delete_version(2)
```

A 21st version raises `RegistryFull`; pass `slot=` with `overwrite=True` to replace one.

### Size presets

`preset(slot)` returns the architecture for each slot (decoder-only Transformer, untied embeddings, 2048
positions, 32k reference vocabulary). `exact_params` instantiates it on the `meta` device to count parameters
without allocating memory. `bubblelm presets` prints the table.

| Slot | Size | d_model | Layers | Heads | bf16 weights |
|---|---|---|---|---|---|
| 1 | 100M | 768 | 7 | 6 | 0.2 GB |
| 2 | 500M | 1536 | 14 | 12 | 1.0 GB |
| 3 | 1B | 1792 | 23 | 14 | 2.0 GB |
| 4 | 1.5B | 1920 | 31 | 15 | 3.0 GB |
| 5 | 2B | 2304 | 29 | 18 | 4.0 GB |
| 6 | 2.5B | 2432 | 33 | 19 | 5.0 GB |
| 7 | 3B | 2560 | 36 | 20 | 6.0 GB |
| 8 | 4B | 2816 | 40 | 22 | 8.0 GB |
| 9 | 5B | 3328 | 36 | 26 | 10.0 GB |
| 10 | 6B | 3200 | 47 | 25 | 12.0 GB |
| 11 | 8B | 3968 | 41 | 31 | 16.0 GB |
| 12 | 10B | 3712 | 59 | 29 | 20.0 GB |
| 13 | 12B | 4992 | 39 | 39 | 24.0 GB |
| 14 | 14B | 4224 | 64 | 33 | 28.0 GB |
| 15 | 16B | 5504 | 43 | 43 | 32.0 GB |
| 16 | 18B | 4992 | 59 | 39 | 36.0 GB |
| 17 | 20B | 5504 | 54 | 43 | 40.0 GB |
| 18 | 24B | 5504 | 65 | 43 | 48.0 GB |
| 19 | 27B | 5888 | 64 | 46 | 54.0 GB |
| 20 | 30B | 6016 | 68 | 47 | 60.0 GB |

Parameter counts are within 1% of the label (checked by `tests/test_registry_presets.py`).

**Hardware reality.** The presets are architectures; the code path is the same as for tiny models, but only the
tiny path has been run end to end in this repository. Training needs about 16 bytes per parameter in fp32 (weights,
gradients, Adam state), about 18 in bf16 mixed precision. `BubbleLM.train` refuses to start when that exceeds 80% of
available memory and raises `CapacityError`; pass `allow_large=True` only when you know the memory is there.
Training is single-device: there is no tensor, pipeline or data parallelism, no gradient checkpointing and no
sharded optimizer, so the 8B+ slots need those added (see "Extending") or a multi-GPU wrapper around
`train_model`. A model of this size also needs far more text than a typical private corpus; with little data the
smaller slots will generalise better. The word-level vocabulary is built from your corpus, so real parameter counts
differ from the table by the difference between your vocabulary and 32,000.

## 6. Decoding and verification options (`DecodeConfig`)

| Field | Default | Effect |
|---|---|---|
| `beam`, `topk` | 5, 6 | beam width, candidates per step |
| `lam` | 2.0 | strength of the bubble nudge added to token log-probabilities during search |
| `mu` | 8.0 | weight of the verification score when choosing the final candidate |
| `level` | `tree` | `sent`, `par`, `doc` or `tree` (all levels, discounted 1.0 / 0.9 / 0.8) |
| `max_new` | 4 | maximum answer tokens |
| `verify` | True | turn verification off to get the plain model with a confidence threshold |
| `relation` | True | the question's relation words must co-occur with the answer in one sentence |
| `consensus` | False | conflict detection |
| `soft` | False | soft matching (needs `bl.fit_soft(aux_texts)` first) |

Override per call: `bl.ask(q, consensus=True, soft=True)`, `bl.evaluate(examples, soft=True)`.

Token weights are `w(t) = [log(1 + N / df(t))]^2`, `w = 0` for tokens in more than 25% of sentences, and a fixed
high weight for tokens the index has never seen. Coverage of a bubble `b` is `Σ w(t) over question+answer tokens in b / Σ w(t)`.

### Conflict detection

`BubbleIndex.consensus(prompt, answer)` finds the longest suffix of the question (up to `stem_max` tokens) that
contains an *anchor* token (a rare token such as a name) and occurs in the index, and collects what follows it in
each sentence. Support and rival counts are numbers of **distinct documents**. If the stem never occurs the check is
neutral. Anchor/relation words are separated by document frequency (`IndexConfig.rel_min_ratio`, `rel_min_df`,
`stop_ratio`); on very small corpora set these by hand or names will look like relation words.

### Soft matching

`bl.fit_soft(aux_texts)` fits `SoftMatcher` on the corpus plus any unlabelled text you pass. A question word the
index has never seen is replaced by the nearest *relation word* (a word frequent enough in the corpus) if cosine
similarity ≥ `sim_min`. Words that co-occur with the question word in the same sentence are never chosen, because
they are its context, not its synonym. Context words with fewer than `min_context` occurrences are ignored when
building vectors so rare names do not dominate. Without auxiliary text that uses the new wording, soft matching
has nothing to learn from and changes nothing (see the benchmark). You can also build `SoftMatcher.vec` from external
vectors.

## 7. Main bubble

```python
bl.set_identity("Atlas", "Acme")                       # answers "what is your name", "who made you" (English + Arabic)
bl.add_rule("no_pay", "refuse", when_any=["salary", "earns"], text="I do not discuss pay.")
bl.add_rule("greet", "respond", when_any=["hello"], text="Hello.")
```

Rules match token phrases in the normalised question, run before the model, and are saved with the project
(`main_bubble.json`). Matching is lexical; there is no semantic understanding of the topic.

## 8. Images and video (optional)

```python
bl.fit_visual(images)                 # k-means codebook over patch features
bl.add_image(img, "a red block")      # numpy array or file path (path needs Pillow)
bl.add_video(frames_or_path, "red then bar")   # list of frames or file path (cv2 or imageio)
bl.build()
bl.ask_media(img)                     # also kind="video"
bl.calibrate_media([(img, "a red block"), (noise_img, None)])
```

An image is split into a `grid × grid` patch grid; each patch becomes a discrete visual token `v:k`; each grid row is
a sentence bubble, the image a paragraph, plus the caption text. A video becomes one paragraph per sampled frame
(rows are sentences, the first row carries a time marker `t:i`). Media questions use document-level coverage over
the same index; the language model is not involved, relation check and conflict detection are off, and the reply is
the caption of the best-matching item with its coverage as the verification score. This is retrieval with a
verifiable score, not image understanding: patch features are colour and edge statistics, so it separates images that
differ in colour/texture layout and will not recognise object categories. `examples/multimodal.py` runs end to end.

## 9. Project layout on disk

```
my_project/
  config.json            EngineConfig
  corpus.jsonl.gz        tokenised documents (text and media)
  main_bubble.json       identity and rules
  soft.npz               soft matcher (if fitted)
  visual.npz             visual codebook (if fitted)
  state.json             media threshold
  weights/registry.json  active slot
  weights/slot_01/       model.pt, vocab.json, meta.json   (… up to slot_20)
```

## 10. Code map

| Module | Responsibility |
|---|---|
| `config.py` | all dataclass configs, `MAX_VERSIONS` |
| `tokenizer.py` | normalisation, sentence/paragraph splitting, `Vocab` |
| `corpus.py` | `Document`, `Corpus`, file loading, save/load |
| `index.py` | `BubbleIndex`: weights, activation, coverage, relation check, consensus, `verify` |
| `embeddings.py` | `SoftMatcher` |
| `model.py` | `TransformerLM`, `GRULM`, `build_model`, `LM` inference wrapper |
| `train.py` | sequences and the training loop |
| `decode.py` | beam search with bubble nudge, candidate ranking, `Answer` |
| `mainbubble.py`, `scratchpad.py` | rules and the audit trail |
| `registry.py` | the 20-slot weight store |
| `presets.py` | the 20 size presets |
| `engine.py` | `BubbleLM`: the public API |
| `vision.py` | optional visual tokenizer and loaders |
| `evaluate.py` | metrics and threshold tuning |
| `cli.py` | `bubblelm` command |

## 11. Extending

- **New architecture:** add a class to `model.py`, branch on `ModelConfig.arch` in `build_model`. It must map token ids
  `(B, T)` to logits `(B, T, V)` causally. Nothing else changes; the registry stores `ModelConfig` per slot.
- **Real large-scale training:** wrap `train_model` (DDP/FSDP, gradient checkpointing, a streaming dataset). Keep
  `make_sequences` and the registry format.
- **New verifier signal:** add a function to `BubbleIndex`, call it in `BubbleIndex.verify`, expose a flag in
  `DecodeConfig`, record its outcome in the `info` dict so the scratchpad shows it.
- **New modality:** produce tokens as strings with a unique prefix (like `v:`), put them in `Document.visual`, and the
  index treats them like any other tokens. Add `ask_<modality>` to the engine.
- **Better soft matching:** replace `SoftMatcher.fit` with external embeddings; keep `canonicalize` and `attach`.

### Conventions

- The code has no comments or docstrings by design; guidance lives in this README. Keep it that way in pull requests
  and document behaviour here.
- Tests live in `tests/`, run with `pytest`. Anything that trains uses tiny models and a fixed seed.
- Retrieval scores must stay explainable: every new signal appears in `Answer.candidates[i]["info"]`.
- Files are Apache 2.0; keep the `NOTICE` file when redistributing.

## 12. Tests

```bash
pytest                  # under a minute on 2 CPU cores
```

Covers tokenizer (English and Arabic), corpus loading, index and verification, conflict detection, soft matching,
main bubble, scratchpad, the 20-slot registry (including the 21st-slot error), presets, training/ask/calibrate/save/
reload, several versions side by side, the capacity guard, Arabic end to end, images and video, and the CLI.

## 13. Benchmark

`benchmarks/synthetic_world.py` builds a world of invented people with six facts each, written as text with three
sentence templates per fact, trains a 0.4M-parameter Transformer for 80 epochs per seed and compares the systems below. Questions are held-out
entities plus entities that were never in the training text (the correct reply is to abstain). The abstention
threshold is tuned on a separate validation split of entities. Paraphrase questions reword the relation ("resides in"
instead of "lives in"); for soft matching the auxiliary text is 400 other invented people described in the new
wording with random values, never the world's people. The noisy run writes 10% of fact statements with a wrong value;
scoring uses the true value.

```bash
python benchmarks/synthetic_world.py --seeds 0 1 2 --out benchmarks/results
python benchmarks/aggregate.py benchmarks/results
```

Results (3 seeds, mean ± std; produced by the commands above, saved in `benchmarks/results/`):

### Clean corpus — standard questions (3 seeds, mean ± std)

| System | Recall | Precision | Hallucination rate | Utility | Recall@P99 |
|---|---|---|---|---|---|
| plain model + confidence threshold | 0.636 ±0.085 | 0.905 ±0.026 | 0.063 ±0.026 | 1095 ±82 | 0.212 ±0.277 |
| bubbles v1 (nudge+rerank+verify+relation) | 0.881 ±0.019 | 1.000 ±0.000 | 0.000 ±0.000 | 1680 ±33 | 0.883 ±0.017 |
| v1 + soft matching | 0.881 ±0.019 | 1.000 ±0.000 | 0.000 ±0.000 | 1680 ±33 | 0.883 ±0.017 |
| v1 + conflict detection | 0.881 ±0.019 | 1.000 ±0.000 | 0.000 ±0.000 | 1680 ±33 | 0.883 ±0.017 |
| v1 + soft + conflict | 0.881 ±0.019 | 1.000 ±0.000 | 0.000 ±0.000 | 1680 ±33 | 0.883 ±0.017 |

### Clean corpus — paraphrased questions (question wording never seen in training, 3 seeds)

| System | Recall | Precision | Wrong answers (of 300) |
|---|---|---|---|
| plain model + confidence threshold | 0.176 ±0.084 | 0.921 ±0.058 | 5.0 ±4.1 |
| bubbles v1 (nudge+rerank+verify+relation) | 0.000 ±0.000 | 1.000 ±0.000 | 0.0 ±0.0 |
| v1 + soft matching (with auxiliary text) | 0.757 ±0.040 | 0.971 ±0.012 | 6.7 ±2.5 |
| v1 + soft matching (no auxiliary text) | 0.000 ±0.000 | 1.000 ±0.000 | 0.0 ±0.0 |
| v1 + conflict detection | 0.000 ±0.000 | 1.000 ±0.000 | 0.0 ±0.0 |
| v1 + soft + conflict (with auxiliary text) | 0.757 ±0.040 | 0.971 ±0.012 | 6.7 ±2.5 |
| v1 + soft + conflict (no auxiliary text) | 0.000 ±0.000 | 1.000 ±0.000 | 0.0 ±0.0 |

### Noisy corpus (10% of fact statements written wrong) — standard questions (3 seeds, mean ± std)

| System | Recall | Precision | Hallucination rate | Utility | Recall@P99 |
|---|---|---|---|---|---|
| plain model + confidence threshold | 0.538 ±0.035 | 0.869 ±0.032 | 0.074 ±0.023 | 965 ±37 | 0.018 ±0.004 |
| bubbles v1 (nudge+rerank+verify+relation) | 0.804 ±0.016 | 0.897 ±0.001 | 0.082 ±0.001 | 1397 ±26 | 0.000 ±0.000 |
| v1 + soft matching | 0.804 ±0.016 | 0.897 ±0.001 | 0.082 ±0.001 | 1397 ±26 | 0.000 ±0.000 |
| v1 + conflict detection | 0.793 ±0.016 | 0.903 ±0.001 | 0.076 ±0.002 | 1389 ±23 | 0.000 ±0.000 |
| v1 + soft + conflict | 0.793 ±0.016 | 0.903 ±0.001 | 0.076 ±0.002 | 1389 ±23 | 0.000 ±0.000 |


Reading the tables:

- **Verification works on clean text.** The plain model with a confidence threshold answers wrongly about 6% of the
  time; the verified system answered with precision 1.000 and a hallucination rate of 0.000 in all three seeds, at the
  same time as higher recall (0.88 vs 0.64). The original method is reproduced in this library.
- **Soft matching fixes most paraphrase failures, but only with auxiliary text.** Without it every paraphrased question
  is refused (recall 0). With 400 unlabelled sentences in the new wording, recall is 0.76 at precision 0.97 (about 7
  wrong answers in 300). Without auxiliary text it is exactly the old behaviour, which is the control for the claim.
- **Conflict detection is a small effect here.** With 10% wrong statements it raised precision from 0.897 to 0.903 and
  lowered the hallucination rate from 0.082 to 0.076, but it also lowered recall (0.804 to 0.793) and the utility score
  did not improve (1397 to 1389). It cannot catch a wrong statement that is the only one for that fact, which is the
  common case in this corpus (about half the people appear in a single document). Treat it as a safeguard for corpora
  with real redundancy, not as a fix for noisy data. The noisy-data hallucination rate stays near 8%.
- Standard questions are unchanged by soft matching and conflict detection on clean data, as expected: they only act
  when the wording is new or the sources disagree.


### Limits you should know

- The world is synthetic: short fact sentences, a closed vocabulary, one right answer. Results do not transfer
  automatically to long free-form text, multi-hop questions or open-ended generation.
- The relation check, the anchor/relation split and the soft-matching thresholds were developed on this world.
  The first version of the relation check was designed after inspecting seed-0 errors, so its numbers are optimistic.
- Conflict detection only helps when a fact is stated in more than one document. A fact stated once with a wrong value
  is verified as true because the index, like the model, only knows the training text.
- Tree levels (sentence/paragraph/document) gave no measurable difference here because every fact lives in a single
  sentence. They are expected to matter only for facts spread over several sentences, which this benchmark does not test.
- Soft matching needs distributional evidence about the new wording. Without it, nothing changes.
- Speed and memory were not optimised or measured; the index keeps token lists in RAM.
- The language model is trained closed-book on the same text the index holds. There is no baseline here that
  retrieves from the index and copies the answer directly; such a retriever would be a fair and probably strong
  comparison for this kind of question.

## License

Copyright 2026 Mostafa Ashraf Mostafa Eldoushy. Licensed under the Apache License, Version 2.0.
