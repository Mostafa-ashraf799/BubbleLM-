# BubbleLM

BubbleLM is a Python library for training a language model on your own text and checking every answer against a
tree-structured memory of that same text before the answer is returned. When the evidence is missing or the sources
disagree, the library returns an abstention instead of a guess.

**Author:** Mostafa Ashraf Mostafa Eldoushy (مصطفى اشرف مصطفي الدعوشي)
**License:** Apache License 2.0 (`LICENSE`, `NOTICE`)
**Arabic guide:** [README.ar.md](README.ar.md)

## Contents

1. [Concepts](#1-concepts)
2. [Install](#2-install)
3. [Quick start](#3-quick-start)
4. [Writing questions and reading answers](#4-writing-questions-and-reading-answers)
5. [Your data](#5-your-data)
6. [Weight versions and size presets](#6-weight-versions-and-size-presets)
7. [Training](#7-training)
8. [Decoding and verification options](#8-decoding-and-verification-options)
9. [Light mode](#9-light-mode)
10. [Tools](#10-tools)
11. [Thinking mode](#11-thinking-mode)
12. [Main bubble: identity and rules](#12-main-bubble-identity-and-rules)
13. [Images and video](#13-images-and-video)
14. [Command line](#14-command-line)
15. [HTTP server](#15-http-server)
16. [Project layout on disk](#16-project-layout-on-disk)
17. [Code map](#17-code-map)
18. [Extending the library](#18-extending-the-library)
19. [Tests and contributing](#19-tests-and-contributing)

## 1. Concepts

| Part | What it is |
|---|---|
| **Bubble** | A set of tokens. Every document becomes a tree: document, paragraph, sentence, token. Each node is a bubble and the tokens are the links. |
| **Bubble index** | Inverted lists from tokens to the sentences, paragraphs and documents that contain them. |
| **Activation** | While a reply is decoded, the model's likely next tokens switch on the bubbles that contain them. |
| **Verification score** | Weighted token coverage (0 to 1) of the question plus draft reply inside the strongest bubble. |
| **Threshold τ** | A reply scoring below τ becomes an abstention. `calibrate` picks τ from your examples. |
| **Scratchpad** | Per-question audit trail: every candidate, its score and the decision. |
| **Main bubble** | Identity and rules stored outside the weights. Editing them needs no retraining. |
| **Weight slots** | Up to 20 independent trained versions inside one project. |
| **Tools** | Your own Python functions that answer certain questions deterministically. |
| **Thinking mode** | Extra checking passes (wider search, rephrasings, voting between versions) before answering. |

Token weight is `w(t) = [log(1 + N / df(t))]^2`; `w = 0` for tokens that appear in more than 25% of sentences; a token the
index has never seen gets a fixed high weight. Coverage of a bubble is the summed weight of the question and answer tokens
found in it divided by the summed weight of all of them. Tree-level coverage takes the best of sentence, paragraph and
document bubbles, discounted by 1.0, 0.9 and 0.8.

Two optional signals refine the score:

- **Conflict detection** counts the distinct documents that support the answer and the distinct documents that support a
  different continuation of the same phrase. If support is below `ratio` times the rival count the system abstains; otherwise
  the score is multiplied by the majority share.
- **Soft matching** learns word vectors (PPMI and SVD) from your corpus plus optional unlabelled text and rewrites question
  words the index has never seen to the nearest known relation word.

## 2. Install

```bash
pip install -e .                 # numpy, torch
pip install -e ".[vision]"       # optional: Pillow, opencv-python-headless, imageio
pip install -e ".[dev]"          # pytest
```

Images and video are optional; nothing in the core imports the vision dependencies.

## 3. Quick start

```python
from bubblelm import BubbleLM, EngineConfig, ModelConfig

bl = BubbleLM("my_project", EngineConfig(model=ModelConfig(epochs=80)))
bl.add_texts(["Aron lives in Cairo. Aron works as a doctor.", "..."])
bl.build()
bl.train(name="first", log=print)
bl.calibrate([("Aron lives in", "cairo"), ("Gamal lives in", None)])

a = bl.ask("Aron lives in")
print(a.text, a.status, a.verification)
print(a.scratchpad.render())
bl.save()
```

`examples/quickstart.py`, `examples/preset_slots.py` and `examples/multimodal.py` are runnable versions.

## 4. Writing questions and reading answers

A question is the **beginning of a sentence the training text could have written**: `"Aron lives in"`. The model is a
closed-book sentence model, not a chat parser. For chat-style input, put pairs in the training text
(`"Q where does Aron live A Cairo"`) and ask with the matching prefix.

`bl.ask(question, version=None, think=None, **decode_overrides)` returns an `Answer`:

| Field | Meaning |
|---|---|
| `text` | the reply, or the abstention text |
| `status` | see below |
| `verification` | the score used for the decision |
| `reason` | why it abstained, when it did |
| `evidence` | source sentences and documents supporting the reply |
| `candidates` | every draft with its score and signal details |
| `scratchpad` | audit trail, `scratchpad.render()` |
| `thinking` | steps taken in thinking mode, `thinking_text()` |

| `status` | Meaning |
|---|---|
| `answered` | score at or above τ |
| `abstained` | below τ, no candidate, conflict between sources, or relation not supported |
| `rule_response`, `refused` | a main-bubble rule replied before the model ran |
| `tool_response`, `tool_error` | a tool replied, or failed (a failure counts as an abstention) |

**Everyday questions.** `bl.ask("Where does Aron live?", natural=True)` (CLI `--natural`, server field `natural`) turns a question into
the sentence beginning it implies, using sentences from your own documents as templates: question words are dropped, word forms are matched by
a light stemmer (`live` to `lives`), the template's trailing function words are kept (`aron lives in`), and a name the documents have never seen
stays in the prefix, so the answer is checked as usual and declined. The chosen prefix is recorded in the scratchpad as `question_rewrite`.
Matching is lexical, so wording far from your documents (or Arabic dialect words absent from them) falls back to `question not understood`;
`bl.fit_soft(...)` extends it to words the soft matcher knows. `QuestionAdapter` in `adapter.py` exposes `prefixes(question)`.

Related calls: `ask_many(questions)`, `ask_versions(question)`, `lookup(question)` (exact-prefix retrieval without the model).

## 5. Your data

Accepted inputs: `.txt`, `.md` (one document per file), `.jsonl` (`{"text": ..., "id": ...}` per line) and folders of these.
Paragraphs are separated by a blank line, sentences by `. ! ? ؟ …` or a line break.

```python
bl.add_text("...")  ;  bl.add_texts([...])  ;  bl.add_path("data/")
bl.build()          # builds the bubble index; ask() rebuilds a stale index on its own
```

Tokenization is word level and Unicode aware: lower-casing, NFKC, Arabic diacritics and tatweel removed, alef variants and ya
unified, Arabic-Indic digits converted, punctuation dropped. Adjust it with `TokenizerConfig`.

Guidance:

- State each fact you want answered at least once as a plain sentence.
- Calibrate on questions the system can answer **and** questions it should decline; τ maximises
  `+1 per correct answer or correct abstention, −1 per wrong answer` on the examples you give.
- On very small corpora tune `IndexConfig` (`rel_min_ratio`, `rel_min_df`, `stop_ratio`) so names are treated as anchors and
  verbs as relation words.
- Soft matching needs unlabelled text that uses the alternative wording: `bl.fit_soft(aux_texts)`.

## 6. Weight versions and size presets

A project holds 20 slots (`MAX_VERSIONS = 20`). Each slot stores `model.pt`, `vocab.json` and `meta.json` (architecture, τ,
metrics). The index, soft matcher and main bubble are shared by all slots.

```python
bl.train(name="small")                    # first free slot
bl.train(slot=7, use_preset=True)         # the 3B architecture
bl.versions(); bl.use(3); bl.ask(q, version=5)
bl.compare(examples)                      # metrics per slot
bl.delete_version(2)
```

A 21st version raises `RegistryFull`; pass `slot=` and `overwrite=True` to replace a slot.

`preset(slot)` returns a decoder-only Transformer sized for each slot (untied embeddings, 2048 positions, 32k reference vocabulary).
`exact_params(cfg)` counts parameters on the `meta` device without allocating memory. `bubblelm presets` prints the table.

| Slot | Size | d_model | Layers | Heads | bf16 weights |
|---|---|---|---|---|---|
| 1 | 100M | 768 | 7 | 6 | 0.2 GB |
| 2 | 500M | 1536 | 14 | 12 | 1.0 GB |
| 3 | 1B | 1792 | 23 | 14 | 2.0 GB |
| 4 | 1.5B | 1920 | 31 | 15 | 3.0 GB |
| 5 | 2B | 2304 | 29 | 18 | 4.0 GB |
| 6 | 2.5B | 2432 | 33 | 19 | 5.0 GB |
| 7 | 3B | 2560 | 36 | 20 | 6.0 GB |
| 8 | 4B | 2816 | 40 | 22 | 8.0 GB |
| 9 | 5B | 3328 | 36 | 26 | 10.0 GB |
| 10 | 6B | 3200 | 47 | 25 | 12.0 GB |
| 11 | 8B | 3968 | 41 | 31 | 16.0 GB |
| 12 | 10B | 3712 | 59 | 29 | 20.0 GB |
| 13 | 12B | 4992 | 39 | 39 | 24.0 GB |
| 14 | 14B | 4224 | 64 | 33 | 28.0 GB |
| 15 | 16B | 5504 | 43 | 43 | 32.0 GB |
| 16 | 18B | 4992 | 59 | 39 | 36.0 GB |
| 17 | 20B | 5504 | 54 | 43 | 40.0 GB |
| 18 | 24B | 5504 | 65 | 43 | 48.0 GB |
| 19 | 27B | 5888 | 64 | 46 | 54.0 GB |
| 20 | 30B | 6016 | 68 | 47 | 59.9 GB |

Real parameter counts depend on your vocabulary size, which is built from your corpus.

## 7. Training

```python
bl.train(
    slot=None, use_preset=False, model_cfg=None, name="",
    overwrite=False, allow_large=False, log=None, store_half=False,
)
```

`ModelConfig` fields: `arch` (`transformer` or `gru`), `d_model`, `layers`, `heads`, `hidden`, `maxlen`, `epochs`, `lr`,
`batch_size`, `weight_decay`, `seed`, `threads`, `device` (`auto`, `cpu`, `cuda`), `dtype` (`float32`, `bfloat16`),
`grad_accum`, `checkpoint`, `distributed`, `parallel`.

**Memory.** Training needs about 16 bytes per parameter in float32 and about 18 in bfloat16 mixed precision (weights, gradients,
optimizer state). `train` raises `CapacityError` when that exceeds 80% of available memory; pass `allow_large=True` to override.

**Large models.**

- `grad_accum=N` accumulates gradients over N batches.
- `checkpoint=True` recomputes activations in the backward pass to save memory (Transformer only).
- `distributed=True` trains across processes (NCCL on CUDA, Gloo on CPU). Launch the same script on every process
  with `torchrun`; only rank 0 writes the slot. `parallel="ddp"` (default) replicates the model on every device;
  `parallel="fsdp"` shards parameters, gradients and optimizer state across devices (PyTorch `fully_shard`, one unit per Transformer block),
  which is the mode for the 8B and larger slots. The full weights are gathered to rank 0 when training ends, so rank 0 needs CPU memory
  for the whole model.

```bash
torchrun --nproc_per_node=4 train_script.py
```

```python
cfg = EngineConfig(model=ModelConfig(device="cuda", dtype="bfloat16", checkpoint=True, grad_accum=4, distributed=True))
bl = BubbleLM("my_project", cfg)
bl.add_path("data/")
bl.build()
bl.train(slot=11, use_preset=True, allow_large=True)
```

Tensor and pipeline parallelism are not included; a model that does not fit even when sharded needs them added in `train.py`.

`store_half=True` (`--half`) saves the weights as float16 and loads them back as float32.

## 8. Decoding and verification options

`DecodeConfig`, overridable per call: `bl.ask(q, consensus=True, soft=True)`, `bl.evaluate(examples, soft=True)`.

| Field | Default | Effect |
|---|---|---|
| `beam`, `topk` | 5, 6 | beam width and candidates per step |
| `lam` | 2.0 | strength of the bubble nudge on token log-probabilities |
| `mu` | 8.0 | weight of the verification score when ranking final candidates |
| `level` | `tree` | `sent`, `par`, `doc` or `tree` |
| `max_new` | 4 | maximum answer tokens |
| `verify` | True | switch off to get the plain model with a confidence threshold |
| `relation` | True | the question's relation words must co-occur with the answer in one sentence |
| `consensus` | False | conflict detection |
| `soft` | False | soft matching (call `bl.fit_soft(aux_texts)` first) |

Calibration and evaluation: `bl.calibrate(examples, think=None)` stores τ for the active setup; `bl.evaluate(examples)` returns
recall, precision, hallucination rate and utility; `examples` is a list of `(question, expected_answer_or_None)`.

Conflict-detection settings live in `ConsensusConfig`; soft-matching settings in `SoftConfig` (`dim`, `sim_min`, `min_source_count`,
`min_context`, `alpha`).

## 9. Light mode

For weak machines. Every option is off by default; `bl.set_profile("light")` turns the useful ones on together.

| Feature | Setting | What it does |
|---|---|---|
| Vectorised index | always on | numpy posting lists |
| Fast path | `runtime.fast_path` | when the index holds exactly one continuation for the question's anchored phrase, the answer is verified and returned without running the model |
| KV cache | `runtime.kv_cache` (default on) | the question is encoded once and beams reuse it (Transformer) |
| int8 weights | `runtime.quantize` | PyTorch dynamic quantization of Linear and GRU layers at load time, CPU |
| float16 on disk | `train(store_half=True)` | smaller weights file |
| Answer cache | `runtime.answer_cache = N` | LRU cache, cleared when data, rules, weights or soft matcher change |
| Small beam | `decode.beam`, `decode.topk`, `decode.max_new` | cheaper search |
| Threads | `runtime.threads` | `torch.set_num_threads` |

Profiles: `bl.set_profile("accurate" | "balanced" | "light")`, `bubblelm profile NAME`. Calibrate again after changing profile because τ belongs
to a decoding setup.

## 10. Tools

Tools answer from your code (arithmetic, a database, an API). Order for every question: main-bubble rule, tool, then fast path or
model. A tool is chosen by regular expression or trigger phrase on the normalised question, never by the language model.

```python
bl.enable_builtin_tools()                       # calculator and document search

@bl.tool(patterns=[r"^add (?P<a>\d+) and (?P<b>\d+)$"], description="Add two integers")
def add(a: int, b: int):
    return a + b

bl.ask("what is 12 * (3 + 4)?").text            # "84"
bl.ask("add 2 and 40").text                     # "42"
bl.call_tool("add", a=1, b=2)
bl.tool_schemas()                               # OpenAI-style function schemas
bl.remove_tool("add")
```

| `@bl.tool` option | Meaning |
|---|---|
| `patterns` | regexes searched in the normalised question; named groups become arguments |
| `params` | `{"a": "int"}`; read from type hints when omitted (`int`, `float`, otherwise `str`) |
| `triggers`, `raw=True` | phrases that call the function with `text=<whole question>` |
| `template` | reply format, default `"{result}"` |
| `timeout` | seconds, default 5 |

Results come back as `tool_response` (score 1.0) or `tool_error`; every call is written to the scratchpad.

Notes for tool authors:

- Tools run the Python you register with arguments taken from user text. Validate arguments inside the function and never pass them
  to a shell or `eval`. The built-in calculator parses with `ast`, allows numbers and `+ - * / // % **` with parentheses, and limits
  expression length and exponent size.
- Tools run in a daemon thread with a timeout; there is no sandbox.
- A tool's reply is reported as `tool_response`; it is not checked against the documents.
- Tools are code, so they are not saved with the project. Register them at start-up.
- Routing is lexical: wording outside your patterns goes to the model. While the built-in calculator is enabled, questions that
  start with `what is` followed by an arithmetic expression go to it.

## 11. Thinking mode

`bl.ask(q, think="low" | "medium" | "high")` (`True` means medium; CLI `--think`) runs several verification passes before replying. Each
line in `answer.thinking` records a computation that ran; `answer.thinking_text()` prints them.

| Level | Passes |
|---|---|
| `low` | wider beam (`beam_factor` times the normal beam) with conflict detection on |
| `medium` | `low`, plus rephrasings of the question from the soft matcher that are attested in the documents |
| `high` | `medium`, plus the same question put to up to `think.versions` other weight versions |

Passes that produced a verified answer vote. Agreement is the share of voting passes that gave the winning answer; the final score is the best
verification of the winner times agreement. Below `think.min_agree` (0.5) the system abstains with reason `disagreement across checks`.
Rules and tools skip thinking and the fast path is off while thinking. `ThinkConfig` fields: `level`, `variants`, `versions`, `min_agree`,
`beam_factor`.

`high` needs several trained slots. Calibrate with the level you will use: `bl.calibrate(examples, think="high")`.

## 12. Main bubble: identity and rules

```python
bl.set_identity("Atlas", "Acme")                          # name and maker, English and Arabic questions
bl.add_rule("no_pay", "refuse", when_any=["salary", "earns"], text="I do not discuss pay.")
bl.add_rule("greet", "respond", when_any=["hello"], text="Hello.")
```

Rules match token phrases in the normalised question, run before tools and the model, and are saved in `main_bubble.json`.

## 13. Images and video

```python
bl.fit_visual(images)                          # k-means codebook over patch features
bl.add_image(img, "a red block")               # array or path (path needs Pillow)
bl.add_video(frames_or_path, "red then bar")   # frames or path (cv2 or imageio)
bl.build()
bl.ask_media(img)                              # kind="video" for clips
bl.calibrate_media([(img, "a red block"), (noise_img, None)])
bl.evaluate_media(examples)
```

An image is cut into a grid of patches; each patch becomes a discrete token `v:k`; each grid row is a sentence bubble, the image is a paragraph, and
the caption text joins it. A video becomes one paragraph per sampled frame with time markers `t:i`. Media questions use document-level
coverage over the same index and return the caption of the best-matching item with its coverage as the score. Features are colour and edge
statistics, so media retrieval separates items by colour and texture layout.

## 14. Command line

```bash
bubblelm --project P add docs/
bubblelm --project P train --epochs 80 --name v1          # or --preset --slot 7
bubblelm --project P calibrate examples.jsonl
bubblelm --project P ask "Aron lives in" --scratchpad --think high --builtin-tools
bubblelm --project P evaluate examples.jsonl
bubblelm --project P compare examples.jsonl
bubblelm --project P versions | use N | delete-version N
bubblelm presets
bubblelm --project P soft aux.txt
bubblelm --project P profile light
bubblelm --project P serve --port 8000
bubblelm --project P export out.zip      ;  bubblelm import out.zip DEST
bubblelm --project P add-image / add-video / fit-visual / ask-media
```

`train` also takes `--grad-accum`, `--checkpoint`, `--distributed`, `--parallel ddp|fsdp`, `--half`, `--allow-large`, `--overwrite`.

## 15. HTTP server

```bash
bubblelm --project P serve --host 127.0.0.1 --port 8000 --builtin-tools
```

Standard library only; requests are handled one at a time through a lock. The server has no authentication or TLS, so bind it to
localhost or put it behind a reverse proxy that provides both.

| Endpoint | Body | Reply |
|---|---|---|
| `GET /health` | | `{"ok": true}` |
| `GET /versions` | | weight slots and the active slot |
| `GET /tools` | | OpenAI-style tool schemas |
| `POST /ask` | `{"prompt": "...", "version": 1, "think": "high", "natural": true, "consensus": true, "soft": true, "debug": false}` | `Answer` as JSON (`candidates` and `scratchpad` only when `debug` is true) |

Only `prompt` is required. Errors return `{"error": ...}` with status 400, 404 or 500. In code: `from bubblelm.server import serve; serve(bl, host, port).serve_forever()`.

## 16. Project layout on disk

```
my_project/
  config.json            EngineConfig
  corpus.jsonl.gz        tokenised documents (text and media)
  main_bubble.json       identity and rules
  soft.npz               soft matcher (if fitted)
  visual.npz             visual codebook (if fitted)
  state.json             media threshold
  weights/registry.json  active slot
  weights/slot_01/       model.pt, vocab.json, meta.json   (up to slot_20)
```

`bl.export_zip(path)` and `BubbleLM.import_zip(zip, dest)` move a whole project.

## 17. Code map

| Module | Responsibility |
|---|---|
| `config.py` | dataclass configs, profiles, `MAX_VERSIONS` |
| `tokenizer.py` | normalisation, splitting, `Vocab` |
| `corpus.py` | `Document`, `Corpus`, file loading |
| `index.py` | `BubbleIndex`: weights, activation, coverage, relation check, consensus, lookup, verify |
| `embeddings.py` | `SoftMatcher` |
| `model.py` | `TransformerLM`, `GRULM`, `build_model`, `LM` inference wrapper, int8 |
| `train.py` | sequences, training loop, gradient accumulation, checkpointing, DDP |
| `adapter.py` | `QuestionAdapter`: everyday questions to sentence prefixes |
| `decode.py` | beam search with bubble nudge, candidate ranking, `Answer` |
| `mainbubble.py`, `scratchpad.py` | rules, identity, audit trail |
| `registry.py` | the 20-slot weight store |
| `presets.py` | the 20 size presets, `exact_params` |
| `tools.py` | `ToolRegistry`, safe calculator |
| `think.py` | voting between thinking passes |
| `vision.py` | visual tokenizer and loaders |
| `evaluate.py` | metrics and threshold tuning |
| `engine.py` | `BubbleLM`, the public API |
| `server.py` | JSON HTTP server |
| `cli.py` | `bubblelm` command |

## 18. Extending the library

- **New architecture:** add a class to `model.py` mapping ids `(B, T)` to causal logits `(B, T, V)` and branch on `ModelConfig.arch` in `build_model`.
- **Other training setups:** wrap or replace `train_model`; keep `make_sequences` and the registry format.
- **New verifier signal:** add a method to `BubbleIndex`, call it in `BubbleIndex.verify`, expose a flag in `DecodeConfig`, and put its result in the `info` dict so the scratchpad shows it.
- **New modality:** emit tokens as strings with a unique prefix (like `v:`), store them in `Document.visual`, and add `ask_<modality>` to the engine.
- **Better soft matching:** replace `SoftMatcher.fit` with external embeddings; keep `canonicalize` and `attach`.
- **New tool:** `@bl.tool(...)` or `ToolRegistry.register`.

## 19. Tests and contributing

```bash
pytest
```

Tests cover the tokenizer, corpus, index and verification, conflict detection, soft matching, main bubble, scratchpad, registry and presets, training and
saving, tools, thinking mode, light-mode features, distributed training, the HTTP server, vision and the CLI. Tests that train use tiny models and fixed seeds.

CI (`.github/workflows/ci.yml`) runs pyflakes and the tests on Python 3.10, 3.12 and 3.13. Conventions: the code carries no comments or docstrings; usage and behaviour are documented in this README. Every verifier signal must appear in
`Answer.candidates[i]["info"]`. Keep `NOTICE` when redistributing. Contributions are accepted under Apache 2.0.
