import numpy as np

from bubblelm import BubbleLM, EngineConfig, VisionConfig


def picture(kind, rng, size=48):
    img = np.full((size, size, 3), 235, dtype=np.uint8)
    if kind == "red":
        img[8:40, 8:40] = (220, 30, 30)
    elif kind == "stripes":
        img[:, ::8] = (30, 30, 220)
    elif kind == "bar":
        img[20:28, :] = (30, 180, 40)
    noise = rng.integers(-12, 12, img.shape)
    return np.clip(img.astype(int) + noise, 0, 255).astype(np.uint8)


rng = np.random.default_rng(0)
bl = BubbleLM("media_project", EngineConfig(vision=VisionConfig(codebook=24, size=32)))
train = [(picture(k, rng), k) for k in ("red", "stripes", "bar") for _ in range(6)]
bl.fit_visual([im for im, _ in train])
for i, (im, k) in enumerate(train):
    bl.add_image(im, f"a picture with {k}", f"img{i}")

frames = [picture("red", rng) for _ in range(3)] + [picture("bar", rng) for _ in range(3)]
bl.add_video(frames, "red then bar", "clip1")
bl.build()

print(bl.ask_media(picture("stripes", rng)).text)
print(bl.ask_media(frames, kind="video").text)
