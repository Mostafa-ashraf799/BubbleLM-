from bubblelm import BubbleLM, EngineConfig, ModelConfig

docs = [
    "Aron lives in Cairo. Aron works as a doctor.",
    "Bela lives in Giza. Bela works as a pilot.",
    "Cyrus lives in Luxor. Cyrus works as a chef.",
    "Dania lives in Aswan. Dania works as a nurse.",
    "Elias lives in Tanta. Elias works as a baker.",
    "Farah lives in Suez. Farah works as a judge.",
]

config = EngineConfig(model=ModelConfig(d_model=48, layers=2, heads=4, maxlen=24, epochs=80, lr=4e-3, batch_size=16))
bl = BubbleLM("my_project", config)
bl.add_texts(docs)
bl.build()
slot = bl.train(name="tiny", log=print)

bl.calibrate([("Aron lives in", "cairo"), ("Bela lives in", "giza"), ("Gamal lives in", None)])

bl.set_identity("Atlas", "Acme")
bl.add_rule("no_jobs", "refuse", when_any=["works"], text="I do not discuss jobs.")

for q in ["Aron lives in", "Gamal lives in", "What is your name", "Aron works as"]:
    a = bl.ask(q)
    print(q, "->", a.text, "|", a.status, "|", round(a.verification, 3), "|", a.reason)

print(bl.ask("Bela lives in").scratchpad.render())
bl.save()
