from bubblelm import BubbleLM, EngineConfig, ModelConfig

docs = [
    "Kamo lives in Cairo. Kamo works as a doctor.",
    "Rimi lives in Giza. Rimi works as a pilot.",
    "Sunadi lives in Luxor. Sunadi works as a chef.",
    "Velo lives in Aswan. Velo works as a nurse.",
    "Tandor lives in Tanta. Tandor works as a baker.",
    "Bezu lives in Suez. Bezu works as a judge.",
]

config = EngineConfig(model=ModelConfig(d_model=48, layers=2, heads=4, maxlen=24, epochs=80, lr=4e-3, batch_size=16))
bl = BubbleLM("my_project", config)
bl.add_texts(docs)
bl.build()
slot = bl.train(name="tiny", log=print)

bl.calibrate([("Kamo lives in", "cairo"), ("Rimi lives in", "giza"), ("Zorbo lives in", None)])

bl.set_identity("Atlas", "Acme")
bl.add_rule("no_jobs", "refuse", when_any=["works"], text="I do not discuss jobs.")

for q in ["Kamo lives in", "Zorbo lives in", "What is your name", "Kamo works as"]:
    a = bl.ask(q)
    print(q, "->", a.text, "|", a.status, "|", round(a.verification, 3), "|", a.reason)

print(bl.ask("Rimi lives in").scratchpad.render())
bl.save()
