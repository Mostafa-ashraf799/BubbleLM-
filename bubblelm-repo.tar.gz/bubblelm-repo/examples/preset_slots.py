from bubblelm import BubbleLM, exact_params, preset, table

for row in table():
    print(row["slot"], row["label"], row["d_model"], row["layers"], row["heads"], round(row["params"] / 1e9, 3))

cfg = preset(1, epochs=1)
print(exact_params(cfg, 32000))

bl = BubbleLM("big_project")
bl.add_path("my_corpus_folder")
bl.build()
bl.train(slot=1, use_preset=True, log=print)
