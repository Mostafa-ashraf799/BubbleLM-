from bubblelm import BubbleLM, EngineConfig, ModelConfig

FACTS = [
    ("kamo", "cairo", "doctor"), ("rimi", "giza", "pilot"), ("sunadi", "luxor", "chef"),
    ("velo", "aswan", "nurse"), ("tandor", "tanta", "baker"), ("bezu", "suez", "judge"),
]


def doc(name, city, job):
    return f"{name} lives in {city} .\n\n{name} works as {job} ."


def small_engine(path, epochs=60, extra_docs=()):
    cfg = EngineConfig(model=ModelConfig(d_model=48, layers=2, heads=4, maxlen=24, epochs=epochs, lr=4e-3,
                                         batch_size=16, threads=2))
    bl = BubbleLM(str(path), cfg)
    for n, c, j in FACTS:
        bl.add_text(doc(n, c, j))
    for d in extra_docs:
        bl.add_text(d)
    bl.build()
    return bl
