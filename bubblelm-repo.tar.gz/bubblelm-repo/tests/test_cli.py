import json
import subprocess
import sys
import os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")


def run(*args, cwd=None):
    r = subprocess.run([sys.executable, "-m", "bubblelm", *args], cwd=ROOT, capture_output=True, text=True,
                       env={**os.environ, "PYTHONPATH": ROOT})
    assert r.returncode == 0, r.stderr
    return r.stdout


def test_cli_full_flow(tmp_path):
    proj = str(tmp_path / "p")
    data = tmp_path / "docs"
    data.mkdir()
    for i, (n, c) in enumerate([("kamo", "cairo"), ("rimi", "giza"), ("velo", "aswan"), ("bezu", "suez")]):
        (data / f"{i}.txt").write_text(f"{n} lives in {c} .", encoding="utf-8")
    assert "added 4" in run("--project", proj, "add", str(data))
    out = run("--project", proj, "train", "--d-model", "32", "--layers", "2", "--heads", "4", "--epochs", "80",
              "--lr", "0.004", "--batch-size", "8", "--maxlen", "16", "--name", "tiny")
    assert "slot 1" in out
    ans = json.loads(run("--project", proj, "ask", "kamo lives in"))
    assert ans["text"] == "cairo" and ans["status"] == "answered"
    assert "tiny" in run("--project", proj, "versions")
    ex = tmp_path / "ex.jsonl"
    ex.write_text('{"prompt":"kamo lives in","truth":"cairo"}\n{"prompt":"zorbo lives in","truth":null}\n')
    assert "tau" in run("--project", proj, "calibrate", str(ex))
    assert "recall" in run("--project", proj, "evaluate", str(ex))
    assert "slot  1" in run("--project", proj, "compare", str(ex))
    assert "deleted" in run("--project", proj, "delete-version", "1")


def test_cli_presets_lists_twenty():
    out = run("presets").strip().splitlines()
    assert len(out) == 20 and "30B" in out[-1] and "100M" in out[0]
