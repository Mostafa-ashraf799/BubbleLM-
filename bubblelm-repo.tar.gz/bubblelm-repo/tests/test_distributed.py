import os
import subprocess
import sys
import textwrap
from pathlib import Path

import torch

from bubblelm.config import ModelConfig
from bubblelm.model import build_model
from bubblelm.tokenizer import Vocab
from bubblelm.train import make_sequences, train_model

SENTS = [f"w{i} lives in c{i % 5} ." for i in range(40)]


def _loss(**kw):
    vocab = Vocab.build(SENTS, 1, 1000)
    cfg = ModelConfig(d_model=32, layers=2, heads=4, maxlen=12, epochs=15, lr=4e-3, batch_size=8, threads=1,
                      device="cpu", **kw)
    torch.manual_seed(0)
    model = build_model(cfg, len(vocab))
    return train_model(model, make_sequences(SENTS, vocab, cfg.maxlen), cfg)


def test_checkpointing_matches_plain():
    assert abs(_loss() - _loss(checkpoint=True)) < 1e-4


def test_grad_accum_trains():
    assert _loss(grad_accum=2) < 2.0


def test_distributed_requires_launcher():
    for k in ("RANK", "WORLD_SIZE"):
        os.environ.pop(k, None)
    try:
        _loss(distributed=True)
    except RuntimeError as e:
        assert "torchrun" in str(e)
    else:
        raise AssertionError


def test_two_process_training(tmp_path):
    script = tmp_path / "run.py"
    script.write_text(textwrap.dedent("""
        import sys
        from bubblelm import BubbleLM, EngineConfig, ModelConfig
        cfg = EngineConfig(model=ModelConfig(d_model=32, layers=2, heads=4, maxlen=24, epochs=40, lr=4e-3,
                                             batch_size=8, threads=1, device="cpu", distributed=True))
        bl = BubbleLM(sys.argv[1], cfg)
        for n, c in [("aron", "cairo"), ("bela", "giza"), ("dania", "aswan"), ("farah", "suez")]:
            bl.add_text(f"{n} lives in {c} .")
        bl.build()
        bl.train(slot=1)
    """))
    proc = subprocess.run([sys.executable, "-m", "torch.distributed.run", "--nproc_per_node=2",
                           str(script), str(tmp_path / "proj")], capture_output=True, text=True, timeout=240,
                          env={**os.environ, "PYTHONPATH": str(Path(__file__).resolve().parents[1])})
    assert proc.returncode == 0, proc.stderr[-1500:]
    assert any((tmp_path / "proj").rglob("model.pt"))


def test_two_process_fsdp_matches_state_shapes(tmp_path):
    script = tmp_path / "run_fsdp.py"
    script.write_text(textwrap.dedent("""
        import sys
        import torch
        from bubblelm import BubbleLM, EngineConfig, ModelConfig
        from bubblelm.model import build_model
        cfg = EngineConfig(model=ModelConfig(d_model=32, layers=2, heads=4, maxlen=24, epochs=60, lr=4e-3,
                                             batch_size=8, grad_accum=2, threads=1, device="cpu",
                                             distributed=True, parallel="fsdp"))
        bl = BubbleLM(sys.argv[1], cfg)
        for n, c in [("aron", "cairo"), ("bela", "giza"), ("dania", "aswan"), ("farah", "suez")]:
            bl.add_text(f"{n} lives in {c} .")
        bl.build()
        bl.train(slot=1)
        if int(__import__("os").environ["RANK"]) == 0:
            state, vocab, mc, meta = bl.registry.load(1)
            ref = build_model(mc, len(vocab))
            assert set(state) == set(ref.state_dict())
            assert all(state[k].shape == v.shape for k, v in ref.state_dict().items())
            assert all(torch.isfinite(v).all() for v in state.values())
            print("FSDP_OK")
    """))
    proc = subprocess.run([sys.executable, "-m", "torch.distributed.run", "--nproc_per_node=2",
                           str(script), str(tmp_path / "proj")], capture_output=True, text=True, timeout=240,
                          env={**os.environ, "PYTHONPATH": str(Path(__file__).resolve().parents[1])})
    assert proc.returncode == 0, proc.stderr[-2500:]
    assert "FSDP_OK" in proc.stdout
