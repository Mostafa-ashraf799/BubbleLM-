import json
import threading
import urllib.error
import urllib.request

import pytest

from bubblelm.server import serve

from helpers import small_engine


@pytest.fixture(scope="module")
def base(tmp_path_factory):
    bl = small_engine(tmp_path_factory.mktemp("srv"), epochs=40)
    bl.train(name="tiny")
    bl.enable_builtin_tools()
    server = serve(bl, "127.0.0.1", 0)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{server.server_address[1]}"
    server.shutdown()
    server.server_close()


def call(url, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


def test_health_versions_tools(base):
    assert call(base + "/health") == (200, {"ok": True})
    code, body = call(base + "/versions")
    assert code == 200 and body["active"] == 1 and len(body["versions"]) == 1
    code, body = call(base + "/tools")
    assert code == 200 and {t["function"]["name"] for t in body["tools"]} >= {"calculator"}


def test_ask(base):
    code, body = call(base + "/ask", {"prompt": "aron lives in"})
    assert code == 200 and body["status"] == "answered" and body["text"] == "cairo"
    assert "candidates" not in body and "scratchpad" not in body
    code, body = call(base + "/ask", {"prompt": "aron lives in", "debug": True})
    assert "candidates" in body and "scratchpad" in body
    assert call(base + "/ask", {"prompt": "what is 2 + 3"})[1]["text"] == "5"


def test_ask_natural(base):
    code, body = call(base + "/ask", {"prompt": "Where does aron live?", "natural": True})
    assert code == 200 and body["text"] == "cairo"


def test_ask_with_think(base):
    code, body = call(base + "/ask", {"prompt": "aron lives in", "think": "low"})
    assert code == 200 and body["thinking"]


def test_bad_requests(base):
    assert call(base + "/ask", {"prompt": ""})[0] == 400
    assert call(base + "/ask", {"prompt": "x", "think": "extreme"})[0] == 400
    assert call(base + "/ask", {"prompt": "x", "version": 7})[0] == 500
    assert call(base + "/nope")[0] == 404
    assert call(base + "/nope", {})[0] == 404
