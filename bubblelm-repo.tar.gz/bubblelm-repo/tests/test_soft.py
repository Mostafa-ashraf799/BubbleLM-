import random

from bubblelm.config import IndexConfig, SoftConfig
from bubblelm.corpus import Corpus
from bubblelm.embeddings import SoftMatcher
from bubblelm.index import BubbleIndex

CITIES = ["cairo", "giza", "luxor", "aswan", "tanta", "suez", "doha", "oslo", "lima", "rome"]


def build():
    rng = random.Random(0)
    c = Corpus()
    for i in range(80):
        c.add_text(f"p{i} lives in {rng.choice(CITIES)} .\n\np{i} works as clerk .")
    ix = BubbleIndex(c, IndexConfig(stop_ratio=0.9))
    aux = [f"q{i} resides in {rng.choice(CITIES)} ." for i in range(80)]
    sents = list(c.lm_sentences())
    for a in aux:
        sents += Corpus().tokenizer.parse(a)[0]
    return ix, sents


def test_oov_word_is_mapped_to_known_relation_word_with_aux():
    ix, sents = build()
    m = SoftMatcher(SoftConfig(sim_min=0.05, margin=0.0)).fit(sents, ix)
    out, changes = m.canonicalize(["p1", "resides", "in"], ix)
    assert out == ["p1", "lives", "in"] and changes[0]["token"] == "resides"


def test_without_aux_the_word_is_left_alone():
    ix, _ = build()
    c = Corpus()
    for i in range(80):
        c.add_text(f"p{i} lives in cairo .")
    m = SoftMatcher(SoftConfig(sim_min=0.05, margin=0.0)).fit(list(c.lm_sentences()), ix)
    out, changes = m.canonicalize(["p1", "resides", "in"], ix)
    assert out == ["p1", "resides", "in"] and not changes


def test_unseen_name_not_canonicalized():
    ix, sents = build()
    m = SoftMatcher(SoftConfig(sim_min=0.05, margin=0.0)).fit(sents, ix)
    out, _ = m.canonicalize(["gamal", "lives", "in"], ix)
    assert out[0] == "gamal"


def test_save_load_roundtrip(tmp_path):
    ix, sents = build()
    m = SoftMatcher(SoftConfig(sim_min=0.05, margin=0.0)).fit(sents, ix)
    m.save(str(tmp_path / "s.npz"))
    m2 = SoftMatcher.load(str(tmp_path / "s.npz"), ix)
    assert m2.canonicalize(["p1", "resides", "in"], ix)[0] == m.canonicalize(["p1", "resides", "in"], ix)[0]
