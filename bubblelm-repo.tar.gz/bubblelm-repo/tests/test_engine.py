import json

import pytest

from bubblelm import BubbleLM, CapacityError, ModelConfig, RegistryFull

from helpers import FACTS, small_engine


@pytest.fixture(scope="module")
def engine(tmp_path_factory):
    bl = small_engine(tmp_path_factory.mktemp("proj"))
    bl.train(name="tiny")
    return bl


def test_trained_model_answers_known_fact(engine):
    a = engine.ask("kamo lives in")
    assert a.status == "answered" and a.text == "cairo"
    assert a.evidence and a.evidence[0]["doc"] == "doc0"
    assert a.scratchpad.of("candidate") and a.scratchpad.of("decision")


def test_unknown_entity_abstains_after_calibration(engine):
    val = [(f"{n} lives in", c) for n, c, _ in FACTS] + [("zorbo lives in", None), ("quill lives in", None)]
    tau = engine.calibrate(val)
    a = engine.ask("zorbo lives in")
    assert a.abstained
    assert engine.ask("rimi lives in").text == "giza"
    assert tau is None or tau > 0


def test_evaluate_metrics_keys(engine):
    m = engine.evaluate([("kamo lives in", "cairo"), ("zorbo lives in", None)])
    for k in ("recall", "precision", "hallucination_rate", "utility", "coverage"):
        assert k in m
    assert m["hallucinated_unknown"] == 0


def test_main_bubble_overrides_model(engine):
    engine.set_identity("Atlas", "Acme")
    assert "Atlas" in engine.ask("what is your name").text
    engine.add_rule("no_jobs", "refuse", when_any=["works"], text="blocked")
    a = engine.ask("kamo works as")
    assert a.status == "refused" and a.text == "blocked"
    engine.main.remove_rule("no_jobs")
    assert engine.ask("kamo works as").status in ("answered", "abstained")


def test_ask_many_matches_ask(engine):
    qs = ["kamo lives in", "velo lives in"]
    assert [a.text for a in engine.ask_many(qs)] == [engine.ask(q).text for q in qs]


def test_save_and_reload(engine, tmp_path):
    path = engine.save()
    again = BubbleLM(path)
    assert again.registry.active == engine.registry.active
    assert again.ask("kamo lives in").text == engine.ask("kamo lives in").text
    assert len(again.corpus) == len(engine.corpus)


def test_multiple_versions_and_compare(tmp_path):
    bl = small_engine(tmp_path, epochs=8)
    s1 = bl.train(name="a")
    s2 = bl.train(name="b", model_cfg=ModelConfig(arch="gru", d_model=32, hidden=48, epochs=8, lr=4e-3,
                                                    batch_size=16, threads=2))
    assert (s1, s2) == (1, 2)
    res = bl.compare([("kamo lives in", "cairo")])
    assert set(res) == {1, 2} and res[2]["name"] == "b"
    bl.use(2)
    assert bl.ask("kamo lives in").version == 2
    assert set(bl.ask_versions("kamo lives in")) == {1, 2}
    bl.delete_version(1)
    assert bl.registry.used() == [2]


def test_twenty_one_trainings_blocked(tmp_path):
    bl = small_engine(tmp_path, epochs=1)
    cfg = ModelConfig(d_model=16, layers=1, heads=2, maxlen=16, epochs=1, batch_size=64, threads=2)
    for _ in range(20):
        bl.train(model_cfg=cfg)
    with pytest.raises(RegistryFull):
        bl.train(model_cfg=cfg)
    assert len(bl.versions()) == 20


def test_capacity_guard_blocks_huge_models(tmp_path):
    bl = small_engine(tmp_path, epochs=1)
    with pytest.raises(CapacityError):
        bl.train(slot=20, use_preset=True)


def test_arabic_end_to_end(tmp_path):
    from bubblelm import EngineConfig
    cfg = EngineConfig(model=ModelConfig(d_model=48, layers=2, heads=4, maxlen=24, epochs=80, lr=4e-3,
                                         batch_size=16, threads=2))
    bl = BubbleLM(str(tmp_path), cfg)
    for n, c in [("احمد", "القاهرة"), ("سارة", "الجيزة"), ("خالد", "اسوان"), ("منى", "طنطا")]:
        bl.add_text(f"{n} يسكن في {c} .")
    bl.build()
    bl.train()
    assert bl.ask("سارة يسكن في").text == "الجيزة"
