import pytest

from bubblelm.adapter import QuestionAdapter, stem

from helpers import FACTS, small_engine


@pytest.fixture(scope="module")
def engine(tmp_path_factory):
    bl = small_engine(tmp_path_factory.mktemp("adp"), epochs=60)
    bl.train(name="tiny")
    bl.calibrate([(f"{n} lives in", c) for n, c, _ in FACTS] + [("gamal lives in", None), ("quill lives in", None),
                                                             ("gamal works as", None), ("quill works as", None)])
    return bl


def test_stem():
    assert stem("lives") == stem("live")
    assert stem("works") == stem("work")
    assert stem("cairo") == "cairo"


def test_prefix_from_wh_question(engine):
    ad = QuestionAdapter(engine._ensure_index(), engine.tokenizer)
    got = ad.prefixes("Where does aron live?")
    assert got and got[0]["prefix"] == "aron lives in"


def test_unseen_name_keeps_the_question_name(engine):
    ad = QuestionAdapter(engine._ensure_index(), engine.tokenizer)
    got = ad.prefixes("Where does gamal live?")
    assert got and got[0]["prefix"].startswith("gamal ")


def test_natural_answers(engine):
    for name, city, job in FACTS[:4]:
        a = engine.ask(f"Where does {name} live?", natural=True)
        assert a.status == "answered" and a.text == city, (name, a.text, a.status)
        assert a.scratchpad.of("question_rewrite")
    assert engine.ask("What does aron work as?", natural=True).text == "doctor"


def test_natural_abstains_on_unknown_and_nonsense(engine):
    assert engine.ask("Where does gamal live?", natural=True).abstained
    a = engine.ask("???", natural=True)
    assert a.abstained and a.reason == "question not understood"


def test_plain_prefix_still_works_with_natural_off(engine):
    assert engine.ask("aron lives in").text == "cairo"
