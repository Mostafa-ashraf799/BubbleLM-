import os

import numpy as np
import pytest

from bubblelm import BubbleLM, EngineConfig, VisionConfig
from bubblelm.vision import VisualTokenizer, load_image, load_video

pytest.importorskip("PIL")


def shape_image(kind, rng, size=48):
    img = np.full((size, size, 3), 235, dtype=np.uint8)
    if kind == "red_block":
        img[8:40, 8:40] = (220, 30, 30)
    elif kind == "blue_stripes":
        img[:, ::8] = (30, 30, 220)
        img[:, 1::8] = (30, 30, 220)
    elif kind == "green_bar":
        img[20:28, :] = (30, 180, 40)
    elif kind == "black_dot":
        img[18:30, 18:30] = (10, 10, 10)
    noise = rng.integers(-12, 12, img.shape)
    return np.clip(img.astype(int) + noise, 0, 255).astype(np.uint8)


KINDS = ["red_block", "blue_stripes", "green_bar", "black_dot"]


def make_engine(path, per_class=6):
    rng = np.random.default_rng(0)
    cfg = EngineConfig(vision=VisionConfig(codebook=24, grid=4, size=32))
    bl = BubbleLM(str(path), cfg)
    train = [(shape_image(k, rng), k) for k in KINDS for _ in range(per_class)]
    bl.fit_visual([im for im, _ in train])
    for i, (im, k) in enumerate(train):
        bl.add_image(im, f"picture of {k.replace('_', ' ')}", f"img{i}")
    bl.build()
    return bl, rng


def test_image_classification_on_synthetic_shapes(tmp_path):
    bl, rng = make_engine(tmp_path)
    test = [(shape_image(k, rng), f"picture of {k.replace('_', ' ')}") for k in KINDS for _ in range(5)]
    m = bl.evaluate_media(test)
    assert m["recall"] > 0.7


def test_media_abstains_after_calibration(tmp_path):
    bl, rng = make_engine(tmp_path)
    val = [(shape_image(k, rng), f"picture of {k.replace('_', ' ')}") for k in KINDS for _ in range(3)]
    weird = [(rng.integers(0, 255, (48, 48, 3), dtype=np.uint8), None) for _ in range(6)]
    bl.calibrate_media(val + weird)
    calibrated = bl.evaluate_media(val + weird)["utility"]
    bl.media_tau = None
    assert calibrated >= bl.evaluate_media(val + weird)["utility"]


def test_video_frames_and_file(tmp_path):
    cv2 = pytest.importorskip("cv2")
    rng = np.random.default_rng(1)
    cfg = EngineConfig(vision=VisionConfig(codebook=24, grid=4, size=32, max_frames=4))
    bl = BubbleLM(str(tmp_path), cfg)
    bl.fit_visual([shape_image(k, rng) for k in KINDS for _ in range(4)])

    def clip(a, b, n=6):
        return [shape_image(a if i < n // 2 else b, rng) for i in range(n)]

    bl.add_video(clip("red_block", "black_dot"), "red then dark", "v1")
    bl.add_video(clip("blue_stripes", "green_bar"), "stripes then bar", "v2")
    bl.build()
    a = bl.ask_media(clip("red_block", "black_dot"), "video")
    assert a.text == "red then dark"
    path = str(tmp_path / "t.avi")
    w = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"MJPG"), 5, (48, 48))
    for fr in clip("blue_stripes", "green_bar"):
        w.write(cv2.cvtColor(fr, cv2.COLOR_RGB2BGR))
    w.release()
    assert len(load_video(path, 4)) == 4
    assert bl.ask_media(path, "video").text == "stripes then bar"


def test_image_file_loader_and_persistence(tmp_path):
    from PIL import Image
    bl, rng = make_engine(tmp_path / "p")
    p = str(tmp_path / "x.png")
    Image.fromarray(shape_image("green_bar", rng)).save(p)
    assert load_image(p).shape == (48, 48, 3)
    bl.save()
    again = BubbleLM(str(tmp_path / "p"))
    assert again.ask_media(load_image(p)).text == "picture of green bar"


def test_vision_is_optional():
    import bubblelm
    assert not hasattr(bubblelm, "VisualTokenizer")
    bl = BubbleLM()
    with pytest.raises(RuntimeError):
        bl.add_image(np.zeros((8, 8, 3)), "x")
