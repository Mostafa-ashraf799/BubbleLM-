from bubblelm.corpus import Corpus
from bubblelm.tokenizer import Tokenizer, Vocab


def test_english_tokens_and_sentences():
    t = Tokenizer()
    assert t.words("Kamo lives in Cairo.") == ["kamo", "lives", "in", "cairo"]
    assert t.sentences("One two. Three four!\nFive") == [["one", "two"], ["three", "four"], ["five"]]


def test_arabic_normalization():
    t = Tokenizer()
    assert t.words("أَحمد يسكن في القاهرة") == ["احمد", "يسكن", "في", "القاهره"[:-1] + "ة"]
    assert t.words("إبراهيم") == t.words("ابراهيم")
    assert t.words("٣ ٤") == ["3", "4"]


def test_arabic_sentence_split():
    t = Tokenizer()
    assert len(t.sentences("يسكن احمد في القاهرة؟ يعمل طبيبا.")) == 2


def test_parse_paragraphs():
    t = Tokenizer()
    doc = t.parse("a b. c d.\n\ne f.")
    assert len(doc) == 2 and len(doc[0]) == 2 and len(doc[1]) == 1


def test_vocab_specials_and_unk():
    v = Vocab.build([["a", "b"], ["a"]])
    assert v.itos[:4] == ["<pad>", "<bos>", "<eos>", "<unk>"]
    assert v.id("zzz") == 3 and v.id("a") >= 4


def test_corpus_roundtrip(tmp_path):
    c = Corpus()
    c.add_text("a b c. d e.\n\nf g.", "x")
    c.add_text("h i.", "x")
    assert [d.doc_id for d in c.docs] == ["x", "x#2"]
    p = tmp_path / "c.gz"
    c.save(str(p))
    c2 = Corpus.load(str(p))
    assert c2.docs[0].paragraphs == c.docs[0].paragraphs and len(c2) == 2


def test_add_path_dir_and_jsonl(tmp_path):
    (tmp_path / "a.txt").write_text("alpha beta. gamma.", encoding="utf-8")
    (tmp_path / "b.jsonl").write_text('{"id":"r1","text":"one two."}\n{"text":"three four."}\n', encoding="utf-8")
    c = Corpus()
    assert len(c.add_path(str(tmp_path))) == 3
