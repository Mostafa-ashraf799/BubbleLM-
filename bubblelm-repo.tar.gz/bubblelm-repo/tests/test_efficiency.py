import os
import zipfile

import pytest
import torch

from bubblelm import BubbleLM
from bubblelm.config import PROFILES, apply_profile, EngineConfig
from bubblelm.decode import beam_search
from bubblelm.model import LM, TransformerLM
from bubblelm.tokenizer import BOS, PAD, UNK, Vocab

from helpers import small_engine


@pytest.fixture(scope="module")
def engine(tmp_path_factory):
    bl = small_engine(tmp_path_factory.mktemp("eff"))
    bl.train(name="tiny")
    return bl


def test_kv_cache_matches_full_recompute(engine):
    lm = engine._lm(None)
    prompts = [engine.tokenizer.words(p) for p in ["aron lives in", "bela works as", "dania lives in", "farah"]]
    cfg = engine.config.decode
    a = beam_search(lm, prompts, engine.index, cfg, use_cache=True)
    b = beam_search(lm, prompts, engine.index, cfg, use_cache=False)
    for x, y in zip(a, b):
        assert [c["w"] for c in x] == [c["w"] for c in y]
        for cx, cy in zip(x, y):
            assert abs(cx["s"] - cy["s"]) < 1e-3


def test_cached_logits_equal_uncached():
    torch.manual_seed(0)
    m = TransformerLM(50, 32, 2, 4, 24).eval()
    vocab = Vocab([f"w{i}" for i in range(50)])
    lm = LM(m, vocab, {PAD, BOS, UNK})
    bases = [[1, 5, 6, 7], [1, 8, 9, 10], [1, 11, 12]]
    state = lm.prime(bases)
    for reqs in ([(0, [20, 21]), (1, [22, 23])], [(0, [20]), (1, [22]), (2, [30])], [(0, []), (1, []), (2, [])]):
        got = lm.step(state, bases, reqs)
        want = lm.next_logp([bases[q] + t for q, t in reqs])
        assert torch.allclose(got, want, atol=1e-5)


def test_int8_runtime_answers_known_fact(engine):
    engine.config.runtime.quantize = True
    engine._lms.clear()
    try:
        assert engine._lm(None).quantized
        assert engine.ask("aron lives in", tau=None).text == "cairo"
    finally:
        engine.config.runtime.quantize = False
        engine._lms.clear()


def test_fast_path_skips_model_for_indexed_fact(engine):
    engine.config.runtime.fast_path = True
    try:
        a = engine.ask("aron lives in", tau=None)
        assert a.text == "cairo" and a.scratchpad.of("fast_path")
        b = engine.ask("gamal lives in", tau=None)
        assert not b.scratchpad.of("fast_path")
    finally:
        engine.config.runtime.fast_path = False


def test_answer_cache_and_invalidation(engine):
    engine.config.runtime.answer_cache = 8
    engine._cache.clear()
    try:
        a = engine.ask("aron lives in")
        assert engine.ask("aron lives in") is a
        engine.add_text("someone lives in nowhere .")
        assert engine.ask("aron lives in") is not a
    finally:
        engine.config.runtime.answer_cache = 0
        engine._cache.clear()


def test_profiles():
    cfg = apply_profile(EngineConfig(), "light")
    assert cfg.decode.beam == 2 and cfg.runtime.quantize and cfg.runtime.fast_path
    assert set(PROFILES) == {"light", "balanced", "accurate"}
    with pytest.raises(ValueError):
        apply_profile(EngineConfig(), "x")


def test_half_precision_storage(tmp_path):
    bl = small_engine(tmp_path, epochs=30)
    bl.train(name="full")
    bl.train(name="half", store_half=True)
    f32 = os.path.getsize(os.path.join(bl.registry.slot_dir(1), "model.pt"))
    f16 = os.path.getsize(os.path.join(bl.registry.slot_dir(2), "model.pt"))
    assert f16 < 0.65 * f32 and bl.registry.meta(2)["stored_dtype"] == "float16"
    assert bl.ask("aron lives in", version=2, tau=None).text


def test_export_import_roundtrip(engine, tmp_path):
    z = engine.export_zip(str(tmp_path / "p.zip"))
    again = BubbleLM.import_zip(z, str(tmp_path / "restored"))
    assert again.ask("aron lives in", tau=None).text == engine.ask("aron lives in", tau=None).text


def test_import_rejects_path_traversal(tmp_path):
    bad = tmp_path / "bad.zip"
    with zipfile.ZipFile(bad, "w") as z:
        z.writestr("../evil.txt", "x")
    with pytest.raises(ValueError):
        BubbleLM.import_zip(str(bad), str(tmp_path / "dest"))
    assert not (tmp_path / "evil.txt").exists()
