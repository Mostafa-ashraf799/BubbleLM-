import pytest

from bubblelm.think import vote

from helpers import small_engine


def test_vote_majority_and_agreement():
    r = vote([dict(text="a", ver=0.9), dict(text="a", ver=0.7), dict(text="b", ver=0.99), dict(text=None, ver=0)])
    assert r["top"] == "a" and r["agree"] == 0.5 and r["ver"] == 0.9


def test_vote_all_abstain():
    assert vote([dict(text=None, ver=0.0)])["top"] is None


def test_vote_tie_prefers_higher_verification():
    assert vote([dict(text="a", ver=0.4), dict(text="b", ver=0.8)])["top"] == "b"


@pytest.fixture(scope="module")
def engine(tmp_path_factory):
    bl = small_engine(tmp_path_factory.mktemp("think"), epochs=60)
    bl.train(name="one")
    bl.train(name="two")
    return bl


@pytest.mark.parametrize("level", ["low", "medium", "high"])
def test_thinking_levels_answer_and_trace(engine, level):
    a = engine.ask("aron lives in", think=level, tau=None)
    assert a.status == "answered" and a.text == "cairo"
    kinds = [s["step"] for s in a.thinking]
    assert kinds[0] == "plan" and "candidates" in kinds and "vote" in kinds and kinds[-1] == "decision"
    assert ("version" in kinds) == (level == "high")
    assert a.thinking_text().startswith("1. [plan]")
    assert a.scratchpad.of("thinking")


def test_thinking_true_means_medium(engine):
    assert engine.ask("aron lives in", think=True, tau=None).text == "cairo"


def test_invalid_level_rejected(engine):
    with pytest.raises(ValueError):
        engine.ask("aron lives in", think="extreme")


def test_thinking_unknown_entity_still_abstains_after_calibration(engine):
    val = [("aron lives in", "cairo"), ("bela lives in", "giza"), ("gamal lives in", None), ("quill lives in", None)]
    engine.calibrate(val, think="high")
    assert engine.ask("gamal lives in", think="high").abstained
    assert engine.ask("bela lives in", think="high").text == "giza"


def test_disagreement_forces_abstention(engine):
    engine.config.think.min_agree = 1.01
    try:
        a = engine.ask("aron lives in", think="high", tau=None)
        assert a.status == "abstained" and "disagree" in a.reason
    finally:
        engine.config.think.min_agree = 0.5


def test_rules_and_tools_skip_thinking(engine):
    engine.enable_builtin_tools(["calculator"])
    a = engine.ask("what is 1 + 2", think="high")
    assert a.status == "tool_response" and a.thinking == []


def test_evaluate_with_thinking(engine):
    m = engine.evaluate([("aron lives in", "cairo"), ("gamal lives in", None)], think="medium", tau=None)
    assert m["recall"] == 1.0
