from bubblelm.mainbubble import MainBubble
from bubblelm.scratchpad import Scratchpad
from bubblelm.tokenizer import Tokenizer


def test_identity_english_and_arabic():
    mb = MainBubble(Tokenizer())
    mb.set_identity("Atlas", "Acme")
    r = mb.consult(Tokenizer().words("What is your name?"))
    assert r.action == "respond" and "Atlas" in r.text
    r = mb.consult(Tokenizer().words("مين انت؟"))
    assert r is not None and "Atlas" in r.text
    assert "Acme" in mb.consult(Tokenizer().words("who made you")).text


def test_identity_change_without_retraining():
    mb = MainBubble(Tokenizer())
    mb.set_identity("Atlas", "Acme")
    mb.set_identity("Zeta", "Initech")
    assert "Zeta" in mb.consult(["your", "name"]).text
    assert len([r for r in mb.rules if r.name.startswith("identity:")]) == 2


def test_refuse_rule_any_all():
    mb = MainBubble(Tokenizer())
    mb.add_rule("no_salary", "refuse", when_any=["salary", "earns"], text="no")
    assert mb.consult(["what", "is", "his", "salary"]).name == "no_salary"
    assert mb.consult(["where", "does", "he", "live"]) is None
    mb.add_rule("both", "refuse", when_all=["secret", "code"])
    assert mb.consult(["secret", "x"]) is None
    assert mb.consult(["the", "secret", "code"]).name == "both"


def test_rule_persistence(tmp_path):
    t = Tokenizer()
    mb = MainBubble(t)
    mb.set_identity("A", "B")
    mb.add_rule("r", "refuse", when_any=["x"])
    mb.save(str(tmp_path / "m.json"))
    mb2 = MainBubble.load(str(tmp_path / "m.json"), t)
    assert mb2.consult(["x"]).name == "r" and "A" in mb2.consult(["your", "name"]).text


def test_scratchpad():
    s = Scratchpad("q")
    s.note("candidate", text="a")
    s.note("decision", result="answer")
    assert len(s.of("candidate")) == 1 and "decision" in s.render()
