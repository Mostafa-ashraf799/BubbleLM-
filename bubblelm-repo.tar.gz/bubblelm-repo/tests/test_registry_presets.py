import pytest
import torch

from bubblelm import MAX_VERSIONS, ModelConfig, RegistryFull, SlotEmpty, WeightRegistry, preset, table
from bubblelm.presets import TARGETS, exact_params


def put(reg, slot=None, **kw):
    slot = slot or reg.next_free()
    reg.save(slot, {"w": torch.zeros(2, 2)}, ["<pad>", "<bos>", "<eos>", "<unk>", "a"], ModelConfig(), **kw)
    return slot


def test_twenty_slots_then_full(tmp_path):
    reg = WeightRegistry(str(tmp_path))
    for _ in range(MAX_VERSIONS):
        put(reg)
    assert len(reg.used()) == 20 and reg.free() == []
    with pytest.raises(RegistryFull):
        reg.next_free()
    with pytest.raises(ValueError):
        reg.slot_dir(21)
    with pytest.raises(ValueError):
        reg.slot_dir(0)


def test_active_and_delete(tmp_path):
    reg = WeightRegistry(str(tmp_path))
    a, b = put(reg), put(reg)
    assert reg.active == a
    reg.set_active(b)
    reg.delete(b)
    assert reg.active == a and reg.free()[0] == b
    with pytest.raises(SlotEmpty):
        reg.meta(b)


def test_overwrite_rules(tmp_path):
    reg = WeightRegistry(str(tmp_path))
    s = put(reg)
    with pytest.raises(FileExistsError):
        put(reg, s)
    reg.save(s, {"w": torch.ones(2)}, ["a"], ModelConfig(), overwrite=True)
    assert reg.load(s)[0]["w"].sum() == 2


def test_meta_roundtrip(tmp_path):
    reg = WeightRegistry(str(tmp_path))
    s = put(reg, name="x", tau=0.3)
    reg.update_meta(s, tau=0.5)
    state, vocab, cfg, meta = reg.load(s)
    assert meta["tau"] == 0.5 and cfg.d_model == ModelConfig().d_model and vocab[-1] == "a"


def test_presets_cover_requested_sizes():
    labels = [t[0] for t in TARGETS]
    assert labels[:6] == ["100M", "500M", "1B", "1.5B", "2B", "2.5B"] and labels[-1] == "30B"
    assert len(labels) == MAX_VERSIONS and len(set(labels)) == 20


def test_preset_parameter_counts_match_targets():
    for row, (label, target) in zip(table(), TARGETS):
        assert abs(row["params"] - target) / target < 0.01, label


def test_preset_heads_divide_width():
    for s in range(1, 21):
        c = preset(s)
        assert c.d_model % c.heads == 0
