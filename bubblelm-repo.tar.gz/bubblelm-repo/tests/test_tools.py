import time

import pytest

from bubblelm.tools import safe_eval

from helpers import small_engine


@pytest.fixture(scope="module")
def engine(tmp_path_factory):
    bl = small_engine(tmp_path_factory.mktemp("tools"), epochs=40)
    bl.train(name="tiny")
    bl.enable_builtin_tools()
    return bl


def test_safe_eval_arithmetic():
    assert safe_eval("2+3*4") == 14
    assert safe_eval("(1+2)^3") == 27
    assert safe_eval("10/4") == 2.5
    assert safe_eval("7 % 4") == 3


@pytest.mark.parametrize("bad", ["__import__('os').system('x')", "2**1000", "1/0", "abs(3)", "a+1", "9"*300, ""])
def test_safe_eval_rejects(bad):
    with pytest.raises(Exception):
        safe_eval(bad)


def test_calculator_answers_english_and_arabic(engine):
    a = engine.ask("what is 12 * (3 + 4)?")
    assert a.status == "tool_response" and a.text == "84" and a.scratchpad.of("tool")
    assert engine.ask("احسب ٣ + ٤").text == "7"
    assert engine.ask("compute 10 / 4").text == "2.5"


def test_calculator_failure_is_a_tool_error(engine):
    a = engine.ask("calculate 1 / 0")
    assert a.status == "tool_error" and a.abstained and "ZeroDivisionError" in a.reason


def test_non_math_questions_still_reach_the_model(engine):
    a = engine.ask("aron lives in", tau=None)
    assert a.status == "answered" and a.text == "cairo"


def test_search_tool_returns_indexed_sentences(engine):
    a = engine.ask("search aron lives")
    assert a.status == "tool_response" and "aron lives in cairo" in a.text and "[doc0]" in a.text


def test_custom_tool_decorator_with_typed_arguments(engine):
    @engine.tool(patterns=[r"^add (?P<a>\d+) and (?P<b>\d+)$"], description="Add two integers")
    def add(a: int, b: int):
        return a + b

    try:
        assert engine.ask("add 2 and 40").text == "42"
        assert engine.call_tool("add", a=1, b=2) == 3
        names = [s["function"]["name"] for s in engine.tool_schemas()]
        assert "add" in names and "calculator" in names
        schema = [s for s in engine.tool_schemas() if s["function"]["name"] == "add"][0]
        assert schema["function"]["parameters"]["properties"]["a"]["type"] == "integer"
    finally:
        engine.remove_tool("add")


def test_raw_tool_with_triggers(engine):
    @engine.tool(name="clock", triggers=["what time is it"], raw=True, template="It is noon ({result})")
    def clock(text: str):
        return "demo"

    try:
        assert engine.ask("what time is it now").text == "It is noon (demo)"
    finally:
        engine.remove_tool("clock")


def test_tool_timeout(engine):
    @engine.tool(patterns=[r"^slow$"], timeout=0.2)
    def slow():
        time.sleep(2)
        return "late"

    try:
        a = engine.ask("slow")
        assert a.status == "tool_error" and "timeout" in a.reason
    finally:
        engine.remove_tool("slow")


def test_main_bubble_refusal_beats_tools(engine):
    engine.add_rule("no_math", "refuse", when_any=["calculate"], text="no")
    try:
        assert engine.ask("calculate 1 + 1").status == "refused"
    finally:
        engine.main.remove_rule("no_math")


def test_tool_answers_count_as_answers_in_evaluation(engine):
    m = engine.evaluate([("what is 2 + 2", "4"), ("aron lives in", "cairo")], tau=None)
    assert m["recall"] == 1.0
