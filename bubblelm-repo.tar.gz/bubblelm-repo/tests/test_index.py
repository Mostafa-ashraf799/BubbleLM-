from bubblelm.config import IndexConfig
from bubblelm.corpus import Corpus
from bubblelm.index import BubbleIndex

from helpers import FACTS, doc


CFG = IndexConfig(stop_ratio=0.6, rel_min_df=8)
CITIES = ["cairo", "giza", "luxor", "aswan", "tanta", "suez", "doha", "oslo"]
JOBS = ["clerk", "pilot", "chef", "nurse", "baker"]


def make(extra=()):
    c = Corpus()
    for n, ci, j in FACTS:
        c.add_text(doc(n, ci, j))
    for i in range(40):
        c.add_text(doc(f"fill{i}x", CITIES[i % 8], JOBS[i % 5]))
    for t in extra:
        c.add_text(t)
    return BubbleIndex(c, CFG)


def test_sizes():
    s = make().sizes()
    assert s["documents"] == len(FACTS) + 40 and s["sentences"] == 2 * (len(FACTS) + 40)


def test_true_answer_verifies_higher_than_false():
    ix = make()
    good, _ = ix.verify(["aron", "lives", "in"], ["cairo"], relation=False)
    bad, _ = ix.verify(["aron", "lives", "in"], ["giza"], relation=False)
    assert good > bad


def test_unseen_entity_gets_low_score():
    ix = make()
    seen, _ = ix.verify(["aron", "lives", "in"], ["cairo"], relation=False)
    unseen, _ = ix.verify(["gamal", "lives", "in"], ["cairo"], relation=False)
    assert unseen < seen


def test_best_sentences_cite_source():
    ev = make().best_sentences(["aron", "lives", "in", "cairo"])
    assert ev[0]["sentence"] == "aron lives in cairo" and ev[0]["doc"] == "doc0"


def test_conflict_detection_on_disagreeing_documents():
    extra = ["aron lives in giza .", "aron lives in giza ."]
    ix = make(extra)
    v_cairo, info = ix.verify(["aron", "lives", "in"], ["cairo"], relation=False, consensus=True, ratio=2.0)
    v_giza, info2 = ix.verify(["aron", "lives", "in"], ["giza"], relation=False, consensus=True, ratio=2.0)
    assert info.get("conflict") and v_cairo == 0.0
    assert not info2.get("conflict") and v_giza > 0.0


def test_consensus_neutral_without_rival():
    ix = make()
    v0, _ = ix.verify(["aron", "lives", "in"], ["cairo"], relation=False, consensus=False)
    v1, info = ix.verify(["aron", "lives", "in"], ["cairo"], relation=False, consensus=True)
    assert v0 == v1 and not info.get("conflict")


def test_majority_weighting():
    extra = ["aron lives in cairo .", "aron lives in cairo .", "aron lives in giza ."]
    ix = make(extra)
    v_plain, _ = ix.verify(["aron", "lives", "in"], ["cairo"], relation=False)
    v_cons, info = ix.verify(["aron", "lives", "in"], ["cairo"], relation=False, consensus=True)
    assert 0 < v_cons < v_plain and info["consensus"]["rival"] == 1


def test_relation_check_blocks_wrong_attribute():
    ix = make()
    assert ix.relation_ok(["aron", "lives", "in"], ["cairo"])
    c = Corpus()
    for i in range(40):
        c.add_text(f"p{i} lives in cairo .\n\np{i} works as doctor .")
    ix2 = BubbleIndex(c, CFG)
    assert not ix2.relation_ok(["p1", "lives", "in"], ["doctor"])
    assert ix2.relation_ok(["p1", "lives", "in"], ["cairo"])


def test_lookup_returns_majority_with_support():
    ix = make(["aron lives in cairo .", "aron lives in giza ."])
    ans, support, rival, stem = ix.lookup(["aron", "lives", "in"])
    assert ans == ["cairo"] and support == 2 and rival == 1 and stem == "aron lives in"


def test_lookup_none_for_unseen_entity():
    assert make().lookup(["gamal", "lives", "in"]) is None


def test_levels_on_facts_spread_over_sentences():
    idx = make(["hadi was born in doha . hadi works as astronomer ."])
    ev = "hadi was born in doha works as astronomer".split()
    sent = idx.coverage(ev, "sent")
    par = idx.coverage(ev, "par")
    doc_ = idx.coverage(ev, "doc")
    tree = idx.coverage(ev, "tree")
    assert sent < 1.0
    assert abs(par - 1.0) < 1e-6 and abs(doc_ - 1.0) < 1e-6
    assert tree >= par * 0.9 - 1e-9
    wrong = "hadi was born in doha works as chef".split()
    assert idx.coverage(wrong, "par") < par
