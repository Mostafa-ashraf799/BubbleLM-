from __future__ import annotations

import json
import os
import shutil
import time

import torch

from .config import MAX_VERSIONS, ModelConfig, from_dict, to_dict


class RegistryFull(RuntimeError):
    pass


class SlotEmpty(KeyError):
    pass


class WeightRegistry:
    def __init__(self, root: str):
        self.root = root
        os.makedirs(root, exist_ok=True)
        self._state = os.path.join(root, "registry.json")
        if not os.path.exists(self._state):
            self._write_state({"active": None})

    def _write_state(self, d):
        with open(self._state, "w", encoding="utf-8") as f:
            json.dump(d, f)

    def _read_state(self):
        with open(self._state, encoding="utf-8") as f:
            return json.load(f)

    def slot_dir(self, slot: int) -> str:
        if not 1 <= slot <= MAX_VERSIONS:
            raise ValueError(f"slot must be between 1 and {MAX_VERSIONS}")
        return os.path.join(self.root, f"slot_{slot:02d}")

    def used(self):
        return [s for s in range(1, MAX_VERSIONS + 1) if os.path.exists(os.path.join(self.slot_dir(s), "meta.json"))]

    def free(self):
        u = set(self.used())
        return [s for s in range(1, MAX_VERSIONS + 1) if s not in u]

    def next_free(self) -> int:
        f = self.free()
        if not f:
            raise RegistryFull(f"all {MAX_VERSIONS} weight slots are used; delete one or pass slot= to overwrite")
        return f[0]

    @property
    def active(self):
        a = self._read_state()["active"]
        return a if a in self.used() else None

    def set_active(self, slot: int):
        if slot not in self.used():
            raise SlotEmpty(slot)
        self._write_state({"active": slot})

    def save(self, slot, state_dict, vocab_list, model_cfg: ModelConfig, name="", tau=None, metrics=None,
             extra=None, overwrite=False):
        d = self.slot_dir(slot)
        if slot in self.used() and not overwrite:
            raise FileExistsError(f"slot {slot} is already used")
        os.makedirs(d, exist_ok=True)
        torch.save(state_dict, os.path.join(d, "model.pt"))
        with open(os.path.join(d, "vocab.json"), "w", encoding="utf-8") as f:
            json.dump(vocab_list, f, ensure_ascii=False)
        n = sum(int(v.numel()) for v in state_dict.values())
        meta = dict(slot=slot, name=name or f"version-{slot}", created=time.strftime("%Y-%m-%d %H:%M:%S"),
                    model=to_dict(model_cfg), params=n, vocab_size=len(vocab_list), tau=tau,
                    metrics=metrics or {}, extra=extra or {})
        self.write_meta(slot, meta)
        if self.active is None:
            self.set_active(slot)
        return meta

    def write_meta(self, slot, meta):
        with open(os.path.join(self.slot_dir(slot), "meta.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)

    def meta(self, slot):
        p = os.path.join(self.slot_dir(slot), "meta.json")
        if not os.path.exists(p):
            raise SlotEmpty(slot)
        with open(p, encoding="utf-8") as f:
            return json.load(f)

    def update_meta(self, slot, **kw):
        m = self.meta(slot)
        m.update(kw)
        self.write_meta(slot, m)
        return m

    def load(self, slot):
        m = self.meta(slot)
        d = self.slot_dir(slot)
        state = torch.load(os.path.join(d, "model.pt"), map_location="cpu")
        with open(os.path.join(d, "vocab.json"), encoding="utf-8") as f:
            vocab = json.load(f)
        return state, vocab, from_dict(ModelConfig, m["model"]), m

    def delete(self, slot):
        if slot not in self.used():
            raise SlotEmpty(slot)
        shutil.rmtree(self.slot_dir(slot))
        if self._read_state()["active"] == slot:
            u = self.used()
            self._write_state({"active": u[0] if u else None})

    def listing(self):
        return [self.meta(s) for s in self.used()]
