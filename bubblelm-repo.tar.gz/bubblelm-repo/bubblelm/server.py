from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_BODY = 1 << 20


def make_handler(bl, lock):
    class Handler(BaseHTTPRequestHandler):
        def _send(self, code, payload):
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                raise ValueError("request body too large")
            return json.loads(self.rfile.read(n) or b"{}")

        def do_GET(self):
            if self.path == "/health":
                self._send(200, {"ok": True})
            elif self.path == "/versions":
                with lock:
                    self._send(200, {"versions": bl.versions(), "active": bl.registry.active})
            elif self.path == "/tools":
                with lock:
                    self._send(200, {"tools": bl.tool_schemas()})
            else:
                self._send(404, {"error": "not found"})

        def do_POST(self):
            try:
                data = self._body()
            except (ValueError, json.JSONDecodeError) as e:
                self._send(400, {"error": str(e)})
                return
            if self.path != "/ask":
                self._send(404, {"error": "not found"})
                return
            prompt = data.get("prompt")
            if not isinstance(prompt, str) or not prompt.strip():
                self._send(400, {"error": "prompt must be a non-empty string"})
                return
            opts = {k: data[k] for k in ("consensus", "soft", "natural") if k in data}
            think = data.get("think")
            if think not in (None, "low", "medium", "high"):
                self._send(400, {"error": "think must be low, medium or high"})
                return
            try:
                with lock:
                    a = bl.ask(prompt, data.get("version"), think=think, **opts)
            except Exception as e:
                self._send(500, {"error": f"{type(e).__name__}: {e}"})
                return
            out = a.as_dict()
            if not data.get("debug"):
                out.pop("candidates", None)
                out.pop("scratchpad", None)
            self._send(200, out)

        def log_message(self, *args):
            pass

    return Handler


def serve(bl, host="127.0.0.1", port=8000):
    server = ThreadingHTTPServer((host, port), make_handler(bl, threading.Lock()))
    return server
