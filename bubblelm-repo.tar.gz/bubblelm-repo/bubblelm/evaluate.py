from __future__ import annotations

import numpy as np


def utility(answered, correct, unknown, penalty=1.0):
    good = (answered & correct).sum() + ((~answered) & unknown).sum()
    bad = (answered & ~correct).sum()
    return float(good - penalty * bad)


def tune_threshold(score, correct, unknown, present):
    cands = sorted(set(score[present].tolist()))
    best_u, best_t = -1e18, float("inf")
    for t in [float("-inf")] + cands:
        u = utility(present & (score >= t), correct, unknown)
        if u > best_u + 1e-9:
            best_u, best_t = u, t
    return best_t


def metrics(score, correct, unknown, present, tau):
    ans = present & (score >= tau)
    known = ~unknown
    nk = max(1, int(known.sum()))
    c = int((ans & correct).sum())
    wrong_known = int((ans & known & ~correct).sum())
    hall_unknown = int((ans & unknown).sum())
    n_ans = int(ans.sum())
    nu = int(unknown.sum())
    return dict(
        recall=c / nk,
        precision=c / n_ans if n_ans else 1.0,
        hallucination_rate=(wrong_known + hall_unknown) / max(1, len(score)),
        wrong_known=wrong_known,
        hallucinated_unknown=hall_unknown,
        abstained_unknown=nu - hall_unknown,
        known=int(known.sum()),
        unknown=nu,
        coverage=n_ans / max(1, len(score)),
        utility=utility(ans, correct, unknown),
    )


def recall_at_precision(score, correct, unknown, present, target):
    nk = max(1, int((~unknown).sum()))
    best = 0.0
    for t in sorted(set(score[present].tolist())):
        ans = present & (score >= t)
        n = int(ans.sum())
        if n and (ans & correct).sum() / n >= target:
            best = max(best, (ans & correct).sum() / nk)
    return float(best)


def arrays(truths, texts, norm):
    unknown = np.array([t is None for t in truths])
    correct = np.array([(a is not None and t is not None and norm(a) == norm(t)) for t, a in zip(truths, texts)])
    present = np.array([a is not None for a in texts])
    return unknown, correct, present
