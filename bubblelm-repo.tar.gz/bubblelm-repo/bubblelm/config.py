from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from typing import Optional

LEVELS = {"sent": [0], "par": [1], "doc": [2], "tree": [0, 1, 2]}
MAX_VERSIONS = 20


@dataclass
class TokenizerConfig:
    lowercase: bool = True
    normalize_arabic: bool = True
    min_freq: int = 1
    max_vocab: Optional[int] = None


@dataclass
class IndexConfig:
    power: float = 2.0
    stop_ratio: float = 0.25
    level_discount: tuple = (1.0, 0.9, 0.8)
    rel_min_ratio: float = 0.0074
    rel_min_df: int = 3
    stem_max: int = 5
    answer_max: int = 6


@dataclass
class ModelConfig:
    arch: str = "transformer"
    d_model: int = 96
    layers: int = 3
    heads: int = 4
    hidden: int = 192
    maxlen: int = 48
    epochs: int = 80
    lr: float = 3e-3
    batch_size: int = 128
    weight_decay: float = 0.01
    seed: int = 0
    threads: int = 0
    device: str = "auto"
    dtype: str = "float32"
    grad_accum: int = 1


@dataclass
class SoftConfig:
    dim: int = 32
    sim_min: float = 0.5
    margin: float = 0.0
    min_source_count: int = 3
    alpha: float = 0.75
    min_context: int = 20
    max_tokens: int = 30000


@dataclass
class ConsensusConfig:
    ratio: float = 2.0


@dataclass
class DecodeConfig:
    beam: int = 5
    topk: int = 6
    lam: float = 2.0
    mu: float = 8.0
    level: str = "tree"
    max_new: int = 4
    verify: bool = True
    relation: bool = True
    consensus: bool = False
    soft: bool = False


@dataclass
class VisionConfig:
    grid: int = 4
    size: int = 64
    codebook: int = 64
    max_frames: int = 8
    kmeans_iters: int = 25
    seed: int = 0
    min_coverage: float = 0.0


@dataclass
class EngineConfig:
    tokenizer: TokenizerConfig = field(default_factory=TokenizerConfig)
    index: IndexConfig = field(default_factory=IndexConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    soft: SoftConfig = field(default_factory=SoftConfig)
    consensus: ConsensusConfig = field(default_factory=ConsensusConfig)
    decode: DecodeConfig = field(default_factory=DecodeConfig)
    vision: VisionConfig = field(default_factory=VisionConfig)
    abstain_text: str = "I am not sure."
    refuse_text: str = "I cannot help with that."


def to_dict(obj):
    return asdict(obj)


def from_dict(cls, data):
    kwargs = {}
    for f in fields(cls):
        if f.name not in data:
            continue
        v = data[f.name]
        ftype = cls.__dataclass_fields__[f.name].type
        sub = _SUB.get(f.name) if cls is EngineConfig else None
        if sub is not None and isinstance(v, dict):
            v = from_dict(sub, v)
        elif f.name == "level_discount":
            v = tuple(v)
        kwargs[f.name] = v
    return cls(**kwargs)


_SUB = {
    "tokenizer": TokenizerConfig,
    "index": IndexConfig,
    "model": ModelConfig,
    "soft": SoftConfig,
    "consensus": ConsensusConfig,
    "decode": DecodeConfig,
    "vision": VisionConfig,
}


def save_config(cfg, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(to_dict(cfg), f, indent=2, ensure_ascii=False)


def load_config(path):
    with open(path, encoding="utf-8") as f:
        return from_dict(EngineConfig, json.load(f))
