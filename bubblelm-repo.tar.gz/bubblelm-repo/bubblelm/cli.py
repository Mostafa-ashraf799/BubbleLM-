from __future__ import annotations

import argparse
import json
import sys

from .config import MAX_VERSIONS, ModelConfig
from .engine import BubbleLM
from .presets import table


def _load_examples(path):
    out = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                r = json.loads(line)
                out.append((r["prompt"], r.get("truth")))
    return out


def build_parser():
    p = argparse.ArgumentParser(prog="bubblelm")
    p.add_argument("--project", default="bubblelm_project")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add")
    a.add_argument("paths", nargs="+")

    t = sub.add_parser("train")
    t.add_argument("--slot", type=int)
    t.add_argument("--preset", action="store_true")
    t.add_argument("--name", default="")
    t.add_argument("--arch", choices=["transformer", "gru"])
    t.add_argument("--d-model", type=int)
    t.add_argument("--layers", type=int)
    t.add_argument("--heads", type=int)
    t.add_argument("--epochs", type=int)
    t.add_argument("--lr", type=float)
    t.add_argument("--batch-size", type=int)
    t.add_argument("--maxlen", type=int)
    t.add_argument("--seed", type=int)
    t.add_argument("--device")
    t.add_argument("--dtype")
    t.add_argument("--overwrite", action="store_true")
    t.add_argument("--allow-large", action="store_true")

    c = sub.add_parser("calibrate")
    c.add_argument("examples")
    c.add_argument("--version", type=int)

    q = sub.add_parser("ask")
    q.add_argument("prompt")
    q.add_argument("--version", type=int)
    q.add_argument("--consensus", action="store_true")
    q.add_argument("--soft", action="store_true")
    q.add_argument("--scratchpad", action="store_true")

    e = sub.add_parser("evaluate")
    e.add_argument("examples")
    e.add_argument("--version", type=int)
    e.add_argument("--consensus", action="store_true")
    e.add_argument("--soft", action="store_true")

    cp = sub.add_parser("compare")
    cp.add_argument("examples")

    sub.add_parser("versions")
    u = sub.add_parser("use")
    u.add_argument("slot", type=int)
    d = sub.add_parser("delete-version")
    d.add_argument("slot", type=int)
    sub.add_parser("presets")
    s = sub.add_parser("soft")
    s.add_argument("--aux", nargs="*", default=[])

    im = sub.add_parser("add-image")
    im.add_argument("path")
    im.add_argument("--caption", default="")
    vd = sub.add_parser("add-video")
    vd.add_argument("path")
    vd.add_argument("--caption", default="")
    fv = sub.add_parser("fit-visual")
    fv.add_argument("images", nargs="+")
    am = sub.add_parser("ask-media")
    am.add_argument("path")
    am.add_argument("--kind", choices=["image", "video"], default="image")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.cmd == "presets":
        for r in table():
            print(f"slot {r['slot']:2d}  {r['label']:>5}  d_model={r['d_model']:5d} layers={r['layers']:3d} "
                  f"heads={r['heads']:3d}  params={r['params'] / 1e9:7.3f}B  bf16={r['bf16_gb']:6.1f} GB")
        return 0
    bl = BubbleLM(args.project)
    if args.cmd == "add":
        n = 0
        for path in args.paths:
            n += len(bl.add_path(path))
        bl.save()
        print(f"added {n} documents; total {len(bl.corpus)}")
    elif args.cmd == "train":
        base = bl.config.model
        kw = {k: v for k, v in dict(arch=args.arch, d_model=args.d_model, layers=args.layers, heads=args.heads,
                                    epochs=args.epochs, lr=args.lr, batch_size=args.batch_size, maxlen=args.maxlen,
                                    seed=args.seed, device=args.device, dtype=args.dtype).items() if v is not None}
        from dataclasses import replace
        mc = replace(base, **kw) if kw else None
        if args.preset and kw:
            from .presets import preset
            mc = preset(args.slot or bl.registry.next_free(), **kw)
        slot = bl.train(args.slot, args.preset, mc, args.name, args.overwrite, args.allow_large,
                        log=lambda s: print(s, flush=True))
        bl.save()
        print(f"saved weights in slot {slot}")
    elif args.cmd == "calibrate":
        tau = bl.calibrate(_load_examples(args.examples), args.version)
        print(f"tau = {tau}")
    elif args.cmd == "ask":
        a = bl.ask(args.prompt, args.version, consensus=args.consensus, soft=args.soft)
        print(json.dumps(dict(text=a.text, status=a.status, verification=round(a.verification, 4),
                              reason=a.reason, evidence=a.evidence), ensure_ascii=False, indent=2))
        if args.scratchpad:
            print(a.scratchpad.render())
    elif args.cmd == "evaluate":
        print(json.dumps(bl.evaluate(_load_examples(args.examples), args.version, consensus=args.consensus,
                                     soft=args.soft), indent=2))
    elif args.cmd == "compare":
        for s, m in bl.compare(_load_examples(args.examples)).items():
            print(f"slot {s:2d} {m['name']:>12} params={m['params']:>12,} recall={m['recall']:.3f} "
                  f"precision={m['precision']:.3f} hallucination={m['hallucination_rate']:.3f} "
                  f"utility={m['utility']:.0f}")
    elif args.cmd == "versions":
        for m in bl.versions():
            mark = "*" if m["slot"] == bl.registry.active else " "
            print(f"{mark} slot {m['slot']:2d}/{MAX_VERSIONS}  {m['name']:<14} params={m['params']:>14,} "
                  f"tau={m['tau']} created={m['created']}")
    elif args.cmd == "use":
        bl.use(args.slot)
        print(f"active slot = {args.slot}")
    elif args.cmd == "delete-version":
        bl.delete_version(args.slot)
        print(f"deleted slot {args.slot}")
    elif args.cmd == "soft":
        aux = []
        for path in args.aux:
            with open(path, encoding="utf-8") as f:
                aux.append(f.read())
        bl.fit_soft(aux)
        bl.save()
        print("soft matcher fitted")
    elif args.cmd == "fit-visual":
        from .vision import load_image
        bl.fit_visual([load_image(p) for p in args.images])
        bl.save()
        print("visual tokenizer fitted")
    elif args.cmd == "add-image":
        from .vision import load_image
        bl.add_image(load_image(args.path), args.caption, args.path)
        bl.save()
    elif args.cmd == "add-video":
        bl.add_video(args.path, args.caption, args.path)
        bl.save()
    elif args.cmd == "ask-media":
        from .vision import load_image
        media = load_image(args.path) if args.kind == "image" else args.path
        a = bl.ask_media(media, args.kind)
        print(json.dumps(dict(text=a.text, status=a.status, verification=round(a.verification, 4),
                              evidence=a.evidence), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
