from __future__ import annotations

import re
import unicodedata
from collections import Counter

from .config import TokenizerConfig

SPECIALS = ["<pad>", "<bos>", "<eos>", "<unk>"]
PAD, BOS, EOS, UNK = 0, 1, 2, 3

_DIACRITICS = re.compile("[ً-ٰٟـ]")
_WORD = re.compile(r"\w+(?:['’\-]\w+)*", re.UNICODE)
_SENT = re.compile(r"(?<=[.!?؟…])\s+|\n+")
_PARA = re.compile(r"\n\s*\n")
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩"
                        "۰۱۲۳۴۵۶۷۸۹",
                        "01234567890123456789")
_ALEF = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا",
                       "ى": "ي"})


class Tokenizer:
    def __init__(self, cfg: TokenizerConfig | None = None):
        self.cfg = cfg or TokenizerConfig()

    def normalize(self, text: str) -> str:
        text = unicodedata.normalize("NFKC", text)
        text = text.translate(_DIGITS)
        if self.cfg.normalize_arabic:
            text = _DIACRITICS.sub("", text).translate(_ALEF)
        if self.cfg.lowercase:
            text = text.lower()
        return text

    def words(self, text: str) -> list[str]:
        return _WORD.findall(self.normalize(text))

    def sentences(self, text: str) -> list[list[str]]:
        out = []
        for chunk in _SENT.split(self.normalize(text)):
            w = _WORD.findall(chunk)
            if w:
                out.append(w)
        return out

    def parse(self, text: str) -> list[list[list[str]]]:
        paragraphs = []
        for p in _PARA.split(text.strip()):
            s = self.sentences(p)
            if s:
                paragraphs.append(s)
        return paragraphs


class Vocab:
    def __init__(self, itos: list[str]):
        self.itos = list(itos)
        self.stoi = {w: i for i, w in enumerate(self.itos)}

    def __len__(self):
        return len(self.itos)

    def id(self, w: str) -> int:
        return self.stoi.get(w, UNK)

    def encode(self, tokens) -> list[int]:
        return [self.id(t) for t in tokens]

    @classmethod
    def build(cls, sentences, min_freq: int = 1, max_vocab=None) -> "Vocab":
        c = Counter(t for s in sentences for t in s)
        items = [(t, n) for t, n in c.items() if n >= min_freq and t not in SPECIALS]
        items.sort(key=lambda x: (-x[1], x[0]))
        if max_vocab:
            items = items[: max(0, max_vocab - len(SPECIALS))]
        return cls(SPECIALS + [t for t, _ in sorted(items)])
