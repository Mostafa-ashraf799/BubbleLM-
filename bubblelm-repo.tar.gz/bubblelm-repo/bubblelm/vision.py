from __future__ import annotations

import numpy as np

from .config import VisionConfig


class VisionDependencyError(ImportError):
    pass


def load_image(path):
    try:
        from PIL import Image
    except ImportError as e:
        raise VisionDependencyError("reading image files needs Pillow (pip install bubblelm[vision])") from e
    with Image.open(path) as im:
        return np.asarray(im.convert("RGB"))


def load_video(path, max_frames=8):
    frames = []
    try:
        import cv2
        cap = cv2.VideoCapture(path)
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if total > 0:
            wanted = set(np.linspace(0, total - 1, min(max_frames, total)).astype(int).tolist())
            i = 0
            while True:
                ok, fr = cap.read()
                if not ok:
                    break
                if i in wanted:
                    frames.append(cv2.cvtColor(fr, cv2.COLOR_BGR2RGB))
                i += 1
        cap.release()
        if frames:
            return frames
    except ImportError:
        pass
    try:
        import imageio.v3 as iio
    except ImportError as e:
        raise VisionDependencyError("reading video files needs opencv-python or imageio") from e
    allf = [np.asarray(f)[..., :3] for f in iio.imiter(path)]
    if not allf:
        raise ValueError("no frames decoded")
    sel = np.linspace(0, len(allf) - 1, min(max_frames, len(allf))).astype(int)
    return [allf[i] for i in sel]


def _as_array(obj):
    if isinstance(obj, (str, bytes)) or hasattr(obj, "__fspath__"):
        return load_image(obj)
    a = np.asarray(obj)
    if a.ndim == 2:
        a = np.stack([a] * 3, -1)
    if a.shape[-1] == 4:
        a = a[..., :3]
    return a


def _resize(a, size):
    a = a.astype(np.float32)
    if a.max() > 1.5:
        a = a / 255.0
    h, w = a.shape[:2]
    if (h, w) == (size, size):
        return a
    try:
        import cv2
        return cv2.resize(a, (size, size), interpolation=cv2.INTER_AREA)
    except ImportError:
        pass
    yi = np.linspace(0, h - 1, size).astype(int)
    xi = np.linspace(0, w - 1, size).astype(int)
    return a[yi][:, xi]


def patch_features(a, grid):
    size = a.shape[0]
    p = size // grid
    gray = a.mean(-1)
    gx = np.abs(np.diff(gray, axis=1, prepend=gray[:, :1]))
    gy = np.abs(np.diff(gray, axis=0, prepend=gray[:1, :]))
    feats = np.zeros((grid, grid, 6), dtype=np.float32)
    for i in range(grid):
        for j in range(grid):
            sl = (slice(i * p, (i + 1) * p), slice(j * p, (j + 1) * p))
            feats[i, j, :3] = a[sl].reshape(-1, 3).mean(0)
            feats[i, j, 3] = gray[sl].std()
            feats[i, j, 4] = gx[sl].mean()
            feats[i, j, 5] = gy[sl].mean()
    return feats.reshape(grid * grid, 6)


def kmeans(x, k, iters, seed):
    rng = np.random.default_rng(seed)
    n = len(x)
    k = min(k, n)
    cent = [x[rng.integers(n)]]
    d2 = ((x - cent[0]) ** 2).sum(1)
    for _ in range(1, k):
        probs = d2 / d2.sum() if d2.sum() > 0 else np.full(n, 1 / n)
        cent.append(x[rng.choice(n, p=probs)])
        d2 = np.minimum(d2, ((x - cent[-1]) ** 2).sum(1))
    cent = np.stack(cent)
    for _ in range(iters):
        dist = ((x[:, None, :] - cent[None]) ** 2).sum(-1)
        lab = dist.argmin(1)
        new = np.stack([x[lab == c].mean(0) if (lab == c).any() else cent[c] for c in range(len(cent))])
        if np.allclose(new, cent):
            break
        cent = new
    return cent


class VisualTokenizer:
    def __init__(self, cfg: VisionConfig | None = None):
        self.cfg = cfg or VisionConfig()
        self.mean = None
        self.std = None
        self.centroids = None

    @property
    def ready(self):
        return self.centroids is not None

    def fit(self, images):
        feats = np.concatenate([patch_features(_resize(_as_array(i), self.cfg.size), self.cfg.grid)
                                for i in images])
        self.mean = feats.mean(0)
        self.std = feats.std(0) + 1e-6
        z = (feats - self.mean) / self.std
        self.centroids = kmeans(z, self.cfg.codebook, self.cfg.kmeans_iters, self.cfg.seed)
        return self

    def _codes(self, image):
        if not self.ready:
            raise RuntimeError("visual tokenizer is not fitted")
        f = patch_features(_resize(_as_array(image), self.cfg.size), self.cfg.grid)
        z = (f - self.mean) / self.std
        dist = ((z[:, None, :] - self.centroids[None]) ** 2).sum(-1)
        return dist.argmin(1).reshape(self.cfg.grid, self.cfg.grid)

    def image_rows(self, image):
        codes = self._codes(image)
        return [[f"v:{int(c)}" for c in row] for row in codes]

    def video_paragraphs(self, frames):
        frames = list(frames)
        if len(frames) > self.cfg.max_frames:
            sel = np.linspace(0, len(frames) - 1, self.cfg.max_frames).astype(int)
            frames = [frames[i] for i in sel]
        paras = []
        for fi, fr in enumerate(frames):
            rows = self.image_rows(fr)
            rows[0] = [f"t:{fi}"] + rows[0]
            paras.append(rows)
        return paras

    def save(self, path):
        np.savez_compressed(path, mean=self.mean, std=self.std, centroids=self.centroids)

    @classmethod
    def load(cls, path, cfg: VisionConfig | None = None):
        z = np.load(path)
        v = cls(cfg)
        v.mean, v.std, v.centroids = z["mean"], z["std"], z["centroids"]
        return v
