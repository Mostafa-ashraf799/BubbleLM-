from __future__ import annotations

from collections import Counter

LEVELS = ("low", "medium", "high")


def vote(passes):
    answers = [p["text"] for p in passes if p["text"] is not None]
    if not answers:
        return dict(top=None, agree=0.0, votes={}, ver=0.0)
    counts = Counter(answers)
    top = max(counts, key=lambda t: (counts[t], max(p["ver"] for p in passes if p["text"] == t)))
    ver = max(p["ver"] for p in passes if p["text"] == top)
    return dict(top=top, agree=counts[top] / len(passes), votes=dict(counts), ver=ver)
