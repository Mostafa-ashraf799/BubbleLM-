from __future__ import annotations

import collections
import math
from dataclasses import dataclass

import numpy as np

from .config import LEVELS, IndexConfig


@dataclass
class Consensus:
    available: bool = False
    support: int = 0
    rival: int = 0
    rival_text: str = ""
    stem: str = ""

    def as_dict(self):
        return dict(available=self.available, support=self.support, rival=self.rival,
                    rival_text=self.rival_text, stem=self.stem)


class BubbleIndex:
    def __init__(self, corpus, cfg: IndexConfig | None = None):
        self.cfg = cfg or IndexConfig()
        self.inv = [collections.defaultdict(list) for _ in range(3)]
        self.sent_tokens: list[tuple] = []
        self.sent_doc: list[int] = []
        self.par_count = 0
        self.doc_ids: list[str] = []
        self.df = collections.Counter()
        self._sc: dict = {}
        for di, doc in enumerate(corpus.docs):
            self.doc_ids.append(doc.doc_id)
            dset = set()
            for para in doc.all_paragraphs():
                pset = set()
                for toks in para:
                    s = set(toks)
                    sid = len(self.sent_tokens)
                    self.sent_tokens.append(tuple(toks))
                    self.sent_doc.append(di)
                    for t in s:
                        self.inv[0][t].append(sid)
                        self.df[t] += 1
                    pset |= s
                pid = self.par_count
                self.par_count += 1
                for t in pset:
                    self.inv[1][t].append(pid)
                dset |= pset
            for t in dset:
                self.inv[2][t].append(di)
        self.ns = len(self.sent_tokens)
        self.inv = [{t: np.asarray(v, dtype=np.int32) for t, v in lv.items()} for lv in self.inv]
        self._sizes = (self.ns, self.par_count, len(self.doc_ids))
        self.idf_unseen = math.log(1 + self.ns / 0.5)
        self.rel_min = max(self.cfg.rel_min_df, int(math.ceil(self.cfg.rel_min_ratio * self.ns)))

    def sizes(self):
        return dict(sentences=self.ns, paragraphs=self.par_count, documents=len(self.doc_ids),
                    vocabulary=len(self.df))

    def weight(self, t):
        d = self.df.get(t)
        if d is None:
            return self.idf_unseen ** self.cfg.power
        if d / self.ns > self.cfg.stop_ratio:
            return 0.0
        return math.log(1 + self.ns / d) ** self.cfg.power

    def activation(self, ctx):
        w = {}
        for t in set(ctx):
            x = self.weight(t)
            if x > 0:
                w[t] = x
        acc = [np.zeros(n) for n in self._sizes]
        for t, x in w.items():
            for lv in range(3):
                p = self.inv[lv].get(t)
                if p is not None:
                    acc[lv][p] += x
        return acc, sum(w.values())

    def cand_support(self, acc, tot, cand, levels):
        wc = self.weight(cand)
        if wc == 0:
            return 0.0
        best = 0.0
        disc_all = self.cfg.level_discount
        for lv in levels:
            p = self.inv[lv].get(cand)
            if p is None or len(p) == 0:
                continue
            disc = disc_all[lv] if len(levels) > 1 else 1.0
            cov = disc * (float(acc[lv][p].max()) + wc) / (tot + wc)
            if cov > best:
                best = cov
        return best

    def coverage(self, ev, level):
        acc, tot = self.activation(ev)
        if tot == 0:
            return 0.0
        levels = LEVELS[level]
        best = 0.0
        for lv in levels:
            disc = self.cfg.level_discount[lv] if len(levels) > 1 else 1.0
            best = max(best, disc * float(acc[lv].max()) / tot)
        return best

    def best_sentences(self, ev, k=2):
        acc, tot = self.activation(ev)
        if tot == 0:
            return []
        order = np.argsort(-acc[0])[:k]
        return [dict(doc=self.doc_ids[self.sent_doc[int(sid)]], sentence=" ".join(self.sent_tokens[int(sid)]),
                     coverage=round(float(acc[0][sid]) / tot, 3)) for sid in order if acc[0][sid] > 0]

    def _sset(self, t):
        if t not in self._sc:
            self._sc[t] = set(self.inv[0].get(t, ()))
        return self._sc[t]

    def relation_tokens(self, prompt):
        return [t for t in set(prompt) if self.rel_min <= self.df.get(t, 0) <= self.cfg.stop_ratio * self.ns]

    def anchor_tokens(self, prompt):
        return [t for t in set(prompt) if 0 < self.df.get(t, 0) < self.rel_min]

    def relation_ok(self, prompt, ans):
        rel = self.relation_tokens(prompt)
        if not rel:
            return True
        return any(self._sset(r) & self._sset(a) for r in rel for a in ans)

    def _continuations(self, prompt):
        P = tuple(prompt)
        for m in range(min(len(P), self.cfg.stem_max), 0, -1):
            stem = P[-m:]
            if not any(0 < self.df.get(t, 0) < self.rel_min for t in stem):
                continue
            lists = [self.inv[0].get(t, ()) for t in stem]
            if any(len(x) == 0 for x in lists):
                continue
            rare = min(lists, key=len)
            found = []
            for sid in rare:
                toks = self.sent_tokens[sid]
                for i in range(len(toks) - m + 1):
                    if toks[i:i + m] == stem:
                        found.append((sid, toks[i + m:i + m + self.cfg.answer_max]))
                        break
            if found:
                return found, stem
        return [], ()

    def lookup(self, prompt):
        found, stem = self._continuations(prompt)
        if not found:
            return None
        votes = collections.defaultdict(set)
        for sid, cont in found:
            votes[cont].add(self.sent_doc[sid])
        ranked = sorted(votes.items(), key=lambda kv: (-len(kv[1]), kv[0]))
        best, docs = ranked[0]
        rival = len(ranked[1][1]) if len(ranked) > 1 else 0
        return list(best), len(docs), rival, " ".join(stem)

    def consensus(self, prompt, ans) -> Consensus:
        found, stem = self._continuations(prompt)
        if not found:
            return Consensus()
        n = len(ans)
        a = tuple(ans)
        votes = collections.defaultdict(set)
        for sid, cont in found:
            votes[tuple(cont[:n])].add(self.sent_doc[sid])
        support = len(votes.get(a, ()))
        rival, rival_text = 0, ""
        for k, d in votes.items():
            if k != a and len(d) > rival:
                rival, rival_text = len(d), " ".join(k)
        anchors = self.anchor_tokens(prompt)
        if anchors and support == 0:
            sets = [self._sset(t) for t in list(anchors) + list(ans)]
            rel = self.relation_tokens(prompt)
            common = set.intersection(*sets) if sets else set()
            if rel:
                relset = set()
                for r in rel:
                    relset |= self._sset(r)
                common &= relset
            support = len({self.sent_doc[s] for s in common})
        return Consensus(True, support, rival, rival_text, " ".join(stem))

    def verify(self, prompt, ans, level="tree", relation=True, consensus=False, ratio=2.0):
        v = self.coverage(list(prompt) + list(ans), level)
        info = {"coverage": round(v, 4)}
        if v > 0 and relation and not self.relation_ok(prompt, ans):
            info["relation_failed"] = True
            v = 0.0
        if v > 0 and consensus:
            c = self.consensus(prompt, ans)
            info["consensus"] = c.as_dict()
            if c.available and c.rival > 0:
                if c.support < ratio * c.rival:
                    info["conflict"] = True
                    v = 0.0
                else:
                    v *= c.support / (c.support + c.rival)
        return v, info
