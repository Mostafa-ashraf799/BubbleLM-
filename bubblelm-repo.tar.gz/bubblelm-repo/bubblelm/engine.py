from __future__ import annotations

import json
import os
import tempfile
import zipfile
from collections import OrderedDict
from dataclasses import replace

import numpy as np
import torch

from . import evaluate as ev
from .config import (MAX_VERSIONS, DecodeConfig, EngineConfig, ModelConfig, apply_profile, load_config,
                     save_config)
from .corpus import Corpus, Document
from .decode import Answer, beam_search, candidate_records, confidence, rank_candidates
from .embeddings import SoftMatcher
from .index import BubbleIndex
from .mainbubble import MainBubble
from .model import LM, build_model, resolve_device, restore_state
from .presets import exact_params, preset, preset_label
from .registry import WeightRegistry
from .scratchpad import Scratchpad
from .think import LEVELS as THINK_LEVELS, vote
from .tools import (CALCULATOR_PATTERN, SEARCH_PATTERN, ToolRegistry, format_number, safe_eval)
from .tokenizer import BOS, PAD, UNK, Tokenizer, Vocab
from .train import is_main, make_sequences, train_model


class CapacityError(MemoryError):
    pass


def _available_bytes(device):
    if device == "cuda" and torch.cuda.is_available():
        return torch.cuda.mem_get_info()[0]
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable"):
                    return int(line.split()[1]) * 1024
    except OSError:
        pass
    return 8 * 2 ** 30


class BubbleLM:
    def __init__(self, path: str | None = None, config: EngineConfig | None = None):
        self.path = path or tempfile.mkdtemp(prefix="bubblelm_")
        os.makedirs(self.path, exist_ok=True)
        cfg_file = os.path.join(self.path, "config.json")
        if config is None and os.path.exists(cfg_file):
            config = load_config(cfg_file)
        self.config = config or EngineConfig()
        self.tokenizer = Tokenizer(self.config.tokenizer)
        self.corpus = Corpus(self.tokenizer)
        self.index: BubbleIndex | None = None
        self.matcher: SoftMatcher | None = None
        self.visual = None
        self.media_tau = self.config.vision.min_coverage
        self.main = MainBubble(self.tokenizer)
        self.tools = ToolRegistry(self.tokenizer)
        self.registry = WeightRegistry(os.path.join(self.path, "weights"))
        self._dirty = True
        self._lms: dict[int, LM] = {}
        self._cache = OrderedDict()
        if self.config.runtime.threads:
            torch.set_num_threads(self.config.runtime.threads)
        self._load_state()

    def _load_state(self):
        p = os.path.join(self.path, "corpus.jsonl.gz")
        if os.path.exists(p):
            self.corpus = Corpus.load(p, self.tokenizer)
        mp = os.path.join(self.path, "main_bubble.json")
        if os.path.exists(mp):
            self.main = MainBubble.load(mp, self.tokenizer)
        vp = os.path.join(self.path, "visual.npz")
        if os.path.exists(vp):
            from .vision import VisualTokenizer
            self.visual = VisualTokenizer.load(vp, self.config.vision)
        sp = os.path.join(self.path, "state.json")
        if os.path.exists(sp):
            with open(sp) as f:
                self.media_tau = json.load(f).get("media_tau", self.media_tau)
        if len(self.corpus):
            self._ensure_index()
            ep = os.path.join(self.path, "soft.npz")
            if os.path.exists(ep):
                self.matcher = SoftMatcher.load(ep, self.index)

    def save(self):
        save_config(self.config, os.path.join(self.path, "config.json"))
        self.corpus.save(os.path.join(self.path, "corpus.jsonl.gz"))
        self.main.save(os.path.join(self.path, "main_bubble.json"))
        if self.matcher is not None:
            self.matcher.save(os.path.join(self.path, "soft.npz"))
        if self.visual is not None and self.visual.ready:
            self.visual.save(os.path.join(self.path, "visual.npz"))
        with open(os.path.join(self.path, "state.json"), "w") as f:
            json.dump({"media_tau": self.media_tau}, f)
        return self.path

    def add_text(self, text, doc_id=None, meta=None):
        d = self.corpus.add_text(text, doc_id, meta)
        self._dirty = True
        self._cache.clear()
        return d

    def add_texts(self, texts, prefix="doc"):
        out = [self.corpus.add_text(t, f"{prefix}{len(self.corpus)}") for t in texts]
        self._dirty = True
        self._cache.clear()
        return [d for d in out if d]

    def add_path(self, path):
        out = self.corpus.add_path(path)
        self._dirty = True
        self._cache.clear()
        return out

    def build(self):
        self.index = BubbleIndex(self.corpus, self.config.index)
        if self.matcher is not None:
            self.matcher.attach(self.index)
        self._dirty = False
        return self.index

    def _ensure_index(self):
        if self.index is None or self._dirty:
            self.build()
        return self.index

    def fit_soft(self, aux_texts=None):
        index = self._ensure_index()
        sents = list(self.corpus.lm_sentences())
        for t in aux_texts or []:
            for p in self.tokenizer.parse(t):
                sents += p
        self.matcher = SoftMatcher(self.config.soft).fit(sents, index)
        self._cache.clear()
        return self.matcher

    def tool(self, fn=None, **kw):
        out = self.tools.register(fn, **kw)
        self._cache.clear()
        return out

    def remove_tool(self, name):
        self.tools.remove(name)
        self._cache.clear()

    def call_tool(self, name, **args):
        t = self.tools.tools[name]
        ok, value = self.tools.run(t, args)
        if not ok:
            raise RuntimeError(value)
        return value

    def tool_schemas(self):
        return self.tools.schemas()

    def enable_builtin_tools(self, names=("calculator", "search")):
        if "calculator" in names:
            def calculator(expr: str):
                return format_number(safe_eval(expr))

            self.tools.register(calculator, description="Evaluate an arithmetic expression", patterns=[CALCULATOR_PATTERN])
        if "search" in names:
            def search(q: str):
                index = self._ensure_index()
                hits = index.best_sentences(self.tokenizer.words(q), 3)
                return " | ".join(f"[{h['doc']}] {h['sentence']}" for h in hits) or "no matching sentence"

            self.tools.register(search, description="Search the indexed documents", patterns=[SEARCH_PATTERN])
        self._cache.clear()

    def set_identity(self, name=None, company=None):
        self.main.set_identity(name, company)
        self._cache.clear()

    def add_rule(self, name, action, when_any=(), when_all=(), text=""):
        self.main.add_rule(name, action, when_any, when_all, text or
                           (self.config.refuse_text if action == "refuse" else ""))
        self._cache.clear()

    def versions(self):
        return self.registry.listing()

    def use(self, slot: int):
        self.registry.set_active(slot)
        self._cache.clear()

    def delete_version(self, slot: int):
        self._cache.clear()
        self._lms.pop(slot, None)
        self.registry.delete(slot)

    def train(self, slot=None, use_preset=False, model_cfg: ModelConfig | None = None, name="",
              overwrite=False, allow_large=False, log=None, store_half=False):
        if not len(self.corpus):
            raise ValueError("add documents before training")
        if slot is None:
            slot = self.registry.next_free()
        if slot in self.registry.used() and not overwrite:
            raise FileExistsError(f"slot {slot} is used; pass overwrite=True or choose another slot")
        mc = model_cfg or (preset(slot) if use_preset else self.config.model)
        sents = list(self.corpus.lm_sentences())
        vocab = Vocab.build(sents, self.config.tokenizer.min_freq, self.config.tokenizer.max_vocab)
        device = resolve_device(mc.device)
        n_est = exact_params(mc, len(vocab))
        need = n_est * (16 if mc.dtype == "float32" else 18)
        if need > _available_bytes(device) * 0.8 and not allow_large:
            raise CapacityError(
                f"training {n_est / 1e9:.2f}B parameters needs about {need / 2 ** 30:.0f} GiB of memory on "
                f"{device}; only {_available_bytes(device) / 2 ** 30:.0f} GiB are available")
        torch.manual_seed(mc.seed)
        model = build_model(mc, len(vocab))
        seqs = make_sequences(sents, vocab, mc.maxlen)
        loss = train_model(model, seqs, mc, log)
        if not is_main():
            return slot
        label = preset_label(slot) if use_preset else ""
        self.registry.save(slot, {k: v.detach().cpu() for k, v in (getattr(model, "gathered_state", None) or model.state_dict()).items()}, vocab.itos, mc,
                                  name=name or label or f"version-{slot}", metrics={"final_loss": loss},
                                  extra=dict(sentences=len(sents), preset=label), overwrite=overwrite, half=store_half)
        self._lms.pop(slot, None)
        self._cache.clear()
        return slot

    def _lm(self, slot) -> LM:
        if slot is None:
            slot = self.registry.active
        if slot is None:
            raise RuntimeError("no trained weights: call train() first")
        if slot not in self._lms:
            state, vocab_list, mc, _meta = self.registry.load(slot)
            vocab = Vocab(vocab_list)
            model = build_model(mc, len(vocab))
            model.load_state_dict(restore_state(state))
            self._lms[slot] = LM(model, vocab, {PAD, BOS, UNK}, resolve_device(mc.device), self.config.runtime.quantize)
        return self._lms[slot]

    def _slot(self, version):
        s = version if version is not None else self.registry.active
        if s is None:
            raise RuntimeError("no trained weights: call train() first")
        return s

    def _decode(self, prompts, slot, cfg: DecodeConfig, think=None):
        index = self._ensure_index()
        lm = self._lm(slot)
        items = []
        for p in prompts:
            toks = self.tokenizer.words(p)
            it = dict(prompt=p, toks=toks, pad=Scratchpad(p), rule=None, repl=[], cands=[], best=None)
            it["pad"].note("prompt_tokens", tokens=toks)
            r = self.main.consult(toks)
            if r is not None:
                it["rule"] = r
                it["pad"].note("main_bubble", rule=r.name, action=r.action)
            elif (tm := self.tools.match(p)) is not None:
                tool, args = tm
                ok, value = self.tools.run(tool, args)
                text = self.tools.render(tool, value) if ok else None
                it["tool"] = dict(name=tool.name, args=args, ok=ok, text=text, error=None if ok else value)
                it["pad"].note("tool", name=tool.name, args=args, ok=ok, result=text if ok else value)
            else:
                use = toks
                if cfg.soft and self.matcher is not None:
                    use, it["repl"] = self.matcher.canonicalize(toks, index)
                    if it["repl"]:
                        it["pad"].note("soft_match", replacements=it["repl"])
                it["use"] = use
            items.append(it)
        rt = self.config.runtime
        if rt.fast_path and cfg.verify:
            for it in items:
                if it["rule"] is not None or it.get("tool") or think:
                    continue
                hit = index.lookup(it["use"])
                if hit is None or hit[2] != 0 or hit[1] < rt.fast_min_support:
                    continue
                ver, info = index.verify(it["use"], hit[0], cfg.level, cfg.relation, cfg.consensus,
                                         self.config.consensus.ratio)
                if ver <= 0:
                    continue
                best = dict(s=0.0, v=0.0, w=hit[0], ver=ver, info=info)
                it["best"], it["fast"] = best, True
                it["cands"] = candidate_records([best], best)
                it["pad"].note("fast_path", answer=" ".join(hit[0]), support=hit[1])
        todo = [i for i, it in enumerate(items) if it["rule"] is None and not it.get("tool") and not it.get("fast")
                and not think]
        if think:
            for it in items:
                if it["rule"] is None and not it.get("tool"):
                    self._think_refine(it, slot, cfg, think)
        if todo:
            res = beam_search(lm, [items[i]["use"] for i in todo], index, cfg, rt.kv_cache)
            for i, cands in zip(todo, res):
                it = items[i]
                it["best"] = rank_candidates(index, it["use"], cands, cfg, self.config.consensus.ratio)
                it["cands"] = candidate_records(cands, it["best"]) if cands else []
        return items

    def _think_refine(self, it, slot, cfg, level):
        level = "medium" if level is True else level
        if level not in THINK_LEVELS:
            raise ValueError(f"think must be one of {THINK_LEVELS}")
        tc = self.config.think
        index = self.index
        steps = []

        def step(kind, text, **data):
            steps.append(dict(step=kind, text=text, **data))

        toks = it["toks"]
        anchors, rels = index.anchor_tokens(toks), index.relation_tokens(toks)
        step("plan", f"question tokens {toks}; anchors {sorted(anchors)}; relation words {sorted(rels)}; level {level}")
        wide = replace(cfg, beam=min(12, cfg.beam * tc.beam_factor), topk=cfg.topk + 2, consensus=True, verify=True)
        main = self._decode([it["prompt"]], slot, wide)[0]
        passes = []
        b = main["best"]
        passes.append(dict(source="main", text=" ".join(b["w"]) if b else None, ver=(b["ver"] or 0.0) if b else 0.0,
                           best=b, item=main))
        step("candidates", f"main pass with beam {wide.beam}: " +
             (f"'{passes[0]['text']}' (verification {passes[0]['ver']:.3f})" if b else "no candidate"),
             candidates=main["cands"][:5])
        if b:
            ev_ = index.best_sentences(list(main["use"]) + b["w"])
            step("evidence", "supporting sentences: " + ("; ".join(f"[{e['doc']}] {e['sentence']}" for e in ev_) or "none"))
            c = b["info"].get("consensus")
            if c and c.get("available"):
                step("consensus", f"{c['support']} documents support it, {c['rival']} support a different continuation "
                     f"({c['rival_text'] or 'none'})")
        if level in ("medium", "high") and self.matcher is not None:
            for alt in self.matcher.alternatives(main["use"], index, tc.variants):
                if index.lookup(alt) is None:
                    step("variant", f"skipped '{' '.join(alt)}': that phrasing is not attested in the documents")
                    continue
                vi = self._decode([" ".join(alt)], slot, replace(wide, soft=False))[0]
                vb = vi["best"]
                passes.append(dict(source="variant", text=" ".join(vb["w"]) if vb else None,
                                   ver=(vb["ver"] or 0.0) if vb else 0.0, best=vb, item=vi))
                step("variant", f"rephrased as '{' '.join(alt)}' -> {passes[-1]['text'] or 'no answer'}")
        if level == "high":
            for s2 in [x for x in self.registry.used() if x != slot][:tc.versions]:
                vi = self._decode([it["prompt"]], s2, wide)[0]
                vb = vi["best"]
                passes.append(dict(source=f"version {s2}", text=" ".join(vb["w"]) if vb else None,
                                   ver=(vb["ver"] or 0.0) if vb else 0.0, best=vb, item=vi))
                step("version", f"weights version {s2} -> {passes[-1]['text'] or 'no answer'}")
        counted = [p for p in passes if p["source"] == "main" or p["ver"] > 0]
        res = vote(counted)
        step("vote", f"{len(counted)} of {len(passes)} passes had verified answers, answers {res['votes'] or 'none'}, agreement {res['agree']:.2f}")
        if res["top"] is None:
            it["best"], it["cands"] = None, main["cands"]
        else:
            chosen = next(p for p in passes if p["text"] == res["top"] and p["ver"] == res["ver"])
            best = dict(chosen["best"])
            best["info"] = dict(best["info"])
            if res["agree"] < tc.min_agree:
                best["info"]["disagreement"] = True
                best["ver"] = 0.0
                step("decision", f"checks disagree ({res['agree']:.2f} < {tc.min_agree}); not answering")
            else:
                best["ver"] = res["ver"] * res["agree"]
                step("decision", f"answer '{res['top']}' with verification {res['ver']:.3f} x agreement {res['agree']:.2f}")
            it["best"], it["cands"] = best, main["cands"]
            it["use"] = chosen["item"]["use"]
        it["thinking"] = steps
        for st in steps:
            it["pad"].note("thinking", step=st["step"], text=st["text"])

    def _score(self, it, cfg):
        if it.get("tool") is not None:
            return it["tool"]["text"], 1.0 if it["tool"]["ok"] else None
        if it["rule"] is not None:
            return None, 1.0 if it["rule"].action == "respond" else None
        b = it["best"]
        if b is None:
            return None, 0.0
        v = b["ver"] if b["ver"] is not None else confidence(b)
        return " ".join(b["w"]), v

    def _to_answer(self, it, cfg, tau, slot):
        a = self._to_answer_core(it, cfg, tau, slot)
        a.thinking = it.get("thinking", [])
        return a

    def _to_answer_core(self, it, cfg, tau, slot):
        pad = it["pad"]
        if it.get("tool") is not None:
            t = it["tool"]
            if t["ok"]:
                return Answer(t["text"], "tool_response", 1.0, tau, f"tool: {t['name']}", [], [], [], slot, pad)
            return Answer(self.config.tool_error_text, "tool_error", 0.0, tau, f"tool {t['name']} failed: {t['error']}",
                          [], [], [], slot, pad)
        if it["rule"] is not None:
            r = it["rule"]
            if r.action == "respond":
                return Answer(r.text, "rule_response", 1.0, tau, f"main bubble: {r.name}", [], [], [], slot, pad)
            return Answer(r.text or self.config.refuse_text, "refused", 0.0, tau, f"main bubble: {r.name}", [], [],
                          [], slot, pad)
        b = it["best"]
        for c in it["cands"]:
            pad.note("candidate", **{k: c[k] for k in ("text", "logp", "verification", "chosen")}, info=c["info"])
        if b is None:
            pad.note("decision", result="abstain", why="no candidate")
            return Answer(self.config.abstain_text, "abstained", 0.0, tau, "no candidate", it["cands"], [],
                          it["repl"], slot, pad)
        text, v = self._score(it, cfg)
        if b["info"].get("disagreement"):
            pad.note("decision", result="abstain", why="disagreement across checks")
            return Answer(self.config.abstain_text, "abstained", 0.0, tau, "disagreement across checks", it["cands"], [],
                          it["repl"], slot, pad)
        evidence = self.index.best_sentences(list(it["use"]) + b["w"]) if cfg.verify else []
        if tau is not None and v < tau:
            why = "conflict between sources" if b["info"].get("conflict") else (
                "relation not supported" if b["info"].get("relation_failed") else "verification below threshold")
            pad.note("decision", result="abstain", why=why, verification=round(v, 4), tau=tau)
            return Answer(self.config.abstain_text, "abstained", v, tau, why, it["cands"], evidence, it["repl"],
                          slot, pad)
        pad.note("decision", result="answer", verification=round(v, 4), tau=tau)
        return Answer(text, "answered", v, tau, "verified", it["cands"], evidence, it["repl"], slot, pad)

    def _cfg(self, overrides):
        return replace(self.config.decode, **overrides) if overrides else self.config.decode

    def ask_many(self, prompts, version=None, tau="slot", think=None, **overrides):
        slot = self._slot(version)
        cfg = self._cfg(overrides)
        if tau == "slot":
            tau = self.registry.meta(slot).get("tau")
        items = self._decode(prompts, slot, cfg, think)
        return [self._to_answer(it, cfg, tau, slot) for it in items]

    def ask_natural(self, question, version=None, tau="slot", think=None, **overrides):
        from .adapter import QuestionAdapter
        index = self._ensure_index()
        found = QuestionAdapter(index, self.tokenizer, self.matcher).prefixes(question)
        if not found:
            pad = Scratchpad(question)
            pad.note("decision", result="abstain", why="question not understood")
            return Answer(self.config.abstain_text, "abstained", 0.0, None, "question not understood", [], [], [],
                          None, pad)
        best = None
        for f in found:
            a = self.ask(f["prefix"], version, tau, think, **overrides)
            a.scratchpad.note("question_rewrite", original=question, prefix=f["prefix"], template=f["template"])
            if a.status == "answered":
                return a
            if best is None or a.verification > best.verification:
                best = a
        return best

    def ask(self, prompt, version=None, tau="slot", think=None, natural=False, **overrides):
        if natural:
            return self.ask_natural(prompt, version, tau, think, **overrides)
        size = self.config.runtime.answer_cache
        key = (self._slot(version), prompt, tuple(sorted(overrides.items())), tau, think)
        if size and key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key]
        ans = self.ask_many([prompt], version, tau, think, **overrides)[0]
        if size:
            self._cache[key] = ans
            while len(self._cache) > size:
                self._cache.popitem(last=False)
        return ans

    def set_profile(self, name):
        self.config = apply_profile(self.config, name)
        self._lms.clear()
        self._cache.clear()
        return self.config

    def ask_versions(self, prompt, versions=None, **overrides):
        return {s: self.ask(prompt, s, **overrides) for s in (versions or self.registry.used())}

    def lookup(self, prompt, soft=False):
        index = self._ensure_index()
        toks = self.tokenizer.words(prompt)
        pad = Scratchpad(prompt)
        repl = []
        if soft and self.matcher is not None:
            toks, repl = self.matcher.canonicalize(toks, index)
        hit = index.lookup(toks)
        if hit is None:
            pad.note("decision", result="abstain", why="no matching sentence")
            return Answer(self.config.abstain_text, "abstained", 0.0, None, "no matching sentence", [], [], repl,
                          None, pad)
        ans, support, rival, stem = hit
        share = support / (support + rival)
        pad.note("lookup", answer=" ".join(ans), support=support, rival=rival, stem=stem)
        return Answer(" ".join(ans), "answered", share, None, "index lookup", [], index.best_sentences(toks + ans),
                      repl, None, pad)

    def _norm(self, s):
        return " ".join(self.tokenizer.words(s))

    def _examples(self, examples):
        out = []
        for e in examples:
            if isinstance(e, dict):
                out.append((e["prompt"], e.get("truth")))
            else:
                out.append((e[0], e[1]))
        return out

    def _run(self, examples, slot, cfg, think=None):
        ex = self._examples(examples)
        items = self._decode([p for p, _ in ex], slot, cfg, think)
        texts, scores = [], []
        for it in items:
            t, v = self._score(it, cfg)
            texts.append(t)
            scores.append(v)
        truths = [t for _, t in ex]
        return truths, texts, np.array(scores)

    def calibrate(self, examples, version=None, think=None, **overrides):
        slot = self._slot(version)
        cfg = self._cfg(overrides)
        truths, texts, score = self._run(examples, slot, cfg, think)
        unknown, correct, present = ev.arrays(truths, texts, self._norm)
        tau = ev.tune_threshold(score, correct, unknown, present)
        tau = None if tau == float("-inf") else float(tau)
        self.registry.update_meta(slot, tau=tau)
        return tau

    def evaluate(self, examples, version=None, tau="slot", think=None, **overrides):
        slot = self._slot(version)
        cfg = self._cfg(overrides)
        if tau == "slot":
            tau = self.registry.meta(slot).get("tau")
        truths, texts, score = self._run(examples, slot, cfg, think)
        unknown, correct, present = ev.arrays(truths, texts, self._norm)
        m = ev.metrics(score, correct, unknown, present, float("-inf") if tau is None else tau)
        m["recall_at_precision_99"] = ev.recall_at_precision(score, correct, unknown, present, 0.99)
        m["tau"] = tau
        return m

    def compare(self, examples, versions=None, **overrides):
        return {s: dict(name=self.registry.meta(s)["name"], params=self.registry.meta(s)["params"],
                        **self.evaluate(examples, s, **overrides)) for s in (versions or self.registry.used())}

    def fit_visual(self, images):
        from .vision import VisualTokenizer
        self.visual = VisualTokenizer(self.config.vision).fit(images)
        return self.visual

    def _need_visual(self):
        if self.visual is None or not self.visual.ready:
            raise RuntimeError("fit the visual tokenizer first: fit_visual(images)")

    def add_image(self, image, caption="", doc_id=None, meta=None):
        self._need_visual()
        rows = self.visual.image_rows(image)
        paras = self.tokenizer.parse(caption) if caption else []
        m = dict(meta or {})
        m["caption"] = caption
        d = Document(doc_id or f"image{len(self.corpus)}", paras, [rows], "image", m)
        self.corpus.add_document(d)
        self._dirty = True
        return d

    def add_video(self, video, caption="", doc_id=None, meta=None):
        self._need_visual()
        if isinstance(video, (str, bytes)) or hasattr(video, "__fspath__"):
            from .vision import load_video
            frames = load_video(video, self.config.vision.max_frames)
        else:
            frames = list(video)
        paras = self.tokenizer.parse(caption) if caption else []
        m = dict(meta or {})
        m["caption"] = caption
        d = Document(doc_id or f"video{len(self.corpus)}", paras, self.visual.video_paragraphs(frames), "video", m)
        self.corpus.add_document(d)
        self._dirty = True
        return d

    def _media_tokens(self, media, kind):
        self._need_visual()
        if kind == "video":
            if isinstance(media, (str, bytes)) or hasattr(media, "__fspath__"):
                from .vision import load_video
                media = load_video(media, self.config.vision.max_frames)
            return [t for para in self.visual.video_paragraphs(media) for row in para for t in row]
        return [t for row in self.visual.image_rows(media) for t in row]

    def _media_scores(self, media, kind):
        index = self._ensure_index()
        toks = self._media_tokens(media, kind)
        acc, tot = index.activation(toks)
        ranked = []
        if tot > 0:
            for di in np.nonzero(acc[2])[0]:
                d = self.corpus.docs[int(di)]
                if d.kind in ("image", "video"):
                    ranked.append((float(acc[2][di]) / tot, d))
            ranked.sort(key=lambda x: -x[0])
        return ranked

    def ask_media(self, media, kind="image", top=3, tau="media"):
        pad = Scratchpad(f"<{kind}>")
        ranked = self._media_scores(media, kind)
        if tau == "media":
            tau = self.media_tau
        ev_ = [dict(doc=d.doc_id, caption=d.meta.get("caption", ""), coverage=round(c, 4)) for c, d in ranked[:top]]
        for e in ev_:
            pad.note("candidate", **e)
        if not ranked:
            return Answer(self.config.abstain_text, "abstained", 0.0, tau, "no matching bubble", [], ev_, [], None, pad)
        c, d = ranked[0]
        if tau is not None and c < tau:
            pad.note("decision", result="abstain", verification=round(c, 4), tau=tau)
            return Answer(self.config.abstain_text, "abstained", c, tau, "verification below threshold", ev_, ev_, [],
                          None, pad)
        pad.note("decision", result="answer", verification=round(c, 4), tau=tau)
        return Answer(d.meta.get("caption", ""), "answered", c, tau, "verified", ev_, ev_, [], None, pad)

    def calibrate_media(self, examples, kind="image"):
        truths, texts, scores = [], [], []
        for media, truth in examples:
            ranked = self._media_scores(media, kind)
            truths.append(truth)
            texts.append(ranked[0][1].meta.get("caption", "") if ranked else None)
            scores.append(ranked[0][0] if ranked else 0.0)
        unknown, correct, pres = ev.arrays(truths, texts, self._norm)
        tau = ev.tune_threshold(np.array(scores), correct, unknown, pres)
        self.media_tau = None if tau == float("-inf") else float(tau)
        return self.media_tau

    def evaluate_media(self, examples, kind="image"):
        truths, texts, scores = [], [], []
        for media, truth in examples:
            a = self.ask_media(media, kind)
            truths.append(truth)
            texts.append(None if a.abstained else a.text)
            scores.append(a.verification)
        unknown, correct, present = ev.arrays(truths, texts, self._norm)
        return ev.metrics(np.array(scores), correct, unknown, present, float("-inf"))

    def export_zip(self, path):
        self.save()
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for root, _d, files in os.walk(self.path):
                for f in files:
                    full = os.path.join(root, f)
                    z.write(full, os.path.relpath(full, self.path))
        return path

    @classmethod
    def import_zip(cls, path, dest):
        os.makedirs(dest, exist_ok=True)
        base = os.path.realpath(dest)
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                target = os.path.realpath(os.path.join(dest, name))
                if not (target == base or target.startswith(base + os.sep)):
                    raise ValueError(f"unsafe path in archive: {name}")
            z.extractall(dest)
        return cls(dest)

    def stats(self):
        out = dict(documents=len(self.corpus), versions_used=len(self.registry.used()), versions_max=MAX_VERSIONS)
        if self.index is not None:
            out.update(self.index.sizes())
        return out
