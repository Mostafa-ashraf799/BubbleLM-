from __future__ import annotations

import json
import os
import tempfile
from dataclasses import replace

import numpy as np
import torch

from . import evaluate as ev
from .config import MAX_VERSIONS, DecodeConfig, EngineConfig, ModelConfig, load_config, save_config
from .corpus import Corpus, Document
from .decode import Answer, beam_search, candidate_records, confidence, rank_candidates
from .embeddings import SoftMatcher
from .index import BubbleIndex
from .mainbubble import MainBubble
from .model import LM, build_model, count_params, resolve_device
from .presets import exact_params, preset, preset_label
from .registry import WeightRegistry
from .scratchpad import Scratchpad
from .tokenizer import BOS, PAD, UNK, Tokenizer, Vocab
from .train import make_sequences, train_model


class CapacityError(MemoryError):
    pass


def _available_bytes(device):
    if device == "cuda" and torch.cuda.is_available():
        return torch.cuda.mem_get_info()[0]
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable"):
                    return int(line.split()[1]) * 1024
    except OSError:
        pass
    return 8 * 2 ** 30


class BubbleLM:
    def __init__(self, path: str | None = None, config: EngineConfig | None = None):
        self.path = path or tempfile.mkdtemp(prefix="bubblelm_")
        os.makedirs(self.path, exist_ok=True)
        cfg_file = os.path.join(self.path, "config.json")
        if config is None and os.path.exists(cfg_file):
            config = load_config(cfg_file)
        self.config = config or EngineConfig()
        self.tokenizer = Tokenizer(self.config.tokenizer)
        self.corpus = Corpus(self.tokenizer)
        self.index: BubbleIndex | None = None
        self.matcher: SoftMatcher | None = None
        self.visual = None
        self.media_tau = self.config.vision.min_coverage
        self.main = MainBubble(self.tokenizer)
        self.registry = WeightRegistry(os.path.join(self.path, "weights"))
        self._dirty = True
        self._lms: dict[int, LM] = {}
        self._load_state()

    def _load_state(self):
        p = os.path.join(self.path, "corpus.jsonl.gz")
        if os.path.exists(p):
            self.corpus = Corpus.load(p, self.tokenizer)
        mp = os.path.join(self.path, "main_bubble.json")
        if os.path.exists(mp):
            self.main = MainBubble.load(mp, self.tokenizer)
        vp = os.path.join(self.path, "visual.npz")
        if os.path.exists(vp):
            from .vision import VisualTokenizer
            self.visual = VisualTokenizer.load(vp, self.config.vision)
        sp = os.path.join(self.path, "state.json")
        if os.path.exists(sp):
            with open(sp) as f:
                self.media_tau = json.load(f).get("media_tau", self.media_tau)
        if len(self.corpus):
            self._ensure_index()
            ep = os.path.join(self.path, "soft.npz")
            if os.path.exists(ep):
                self.matcher = SoftMatcher.load(ep, self.index)

    def save(self):
        save_config(self.config, os.path.join(self.path, "config.json"))
        self.corpus.save(os.path.join(self.path, "corpus.jsonl.gz"))
        self.main.save(os.path.join(self.path, "main_bubble.json"))
        if self.matcher is not None:
            self.matcher.save(os.path.join(self.path, "soft.npz"))
        if self.visual is not None and self.visual.ready:
            self.visual.save(os.path.join(self.path, "visual.npz"))
        with open(os.path.join(self.path, "state.json"), "w") as f:
            json.dump({"media_tau": self.media_tau}, f)
        return self.path

    def add_text(self, text, doc_id=None, meta=None):
        d = self.corpus.add_text(text, doc_id, meta)
        self._dirty = True
        return d

    def add_texts(self, texts, prefix="doc"):
        out = [self.corpus.add_text(t, f"{prefix}{len(self.corpus)}") for t in texts]
        self._dirty = True
        return [d for d in out if d]

    def add_path(self, path):
        out = self.corpus.add_path(path)
        self._dirty = True
        return out

    def build(self):
        self.index = BubbleIndex(self.corpus, self.config.index)
        if self.matcher is not None:
            self.matcher.attach(self.index)
        self._dirty = False
        return self.index

    def _ensure_index(self):
        if self.index is None or self._dirty:
            self.build()
        return self.index

    def fit_soft(self, aux_texts=None):
        index = self._ensure_index()
        sents = list(self.corpus.lm_sentences())
        for t in aux_texts or []:
            for p in self.tokenizer.parse(t):
                sents += p
        self.matcher = SoftMatcher(self.config.soft).fit(sents, index)
        return self.matcher

    def set_identity(self, name=None, company=None):
        self.main.set_identity(name, company)

    def add_rule(self, name, action, when_any=(), when_all=(), text=""):
        self.main.add_rule(name, action, when_any, when_all, text or
                           (self.config.refuse_text if action == "refuse" else ""))

    def versions(self):
        return self.registry.listing()

    def use(self, slot: int):
        self.registry.set_active(slot)

    def delete_version(self, slot: int):
        self._lms.pop(slot, None)
        self.registry.delete(slot)

    def train(self, slot=None, use_preset=False, model_cfg: ModelConfig | None = None, name="",
              overwrite=False, allow_large=False, log=None):
        if not len(self.corpus):
            raise ValueError("add documents before training")
        if slot is None:
            slot = self.registry.next_free()
        if slot in self.registry.used() and not overwrite:
            raise FileExistsError(f"slot {slot} is used; pass overwrite=True or choose another slot")
        mc = model_cfg or (preset(slot) if use_preset else self.config.model)
        sents = list(self.corpus.lm_sentences())
        vocab = Vocab.build(sents, self.config.tokenizer.min_freq, self.config.tokenizer.max_vocab)
        device = resolve_device(mc.device)
        n_est = exact_params(mc, len(vocab))
        need = n_est * (16 if mc.dtype == "float32" else 18)
        if need > _available_bytes(device) * 0.8 and not allow_large:
            raise CapacityError(
                f"training {n_est / 1e9:.2f}B parameters needs about {need / 2 ** 30:.0f} GiB of memory on "
                f"{device}; only {_available_bytes(device) / 2 ** 30:.0f} GiB are available")
        torch.manual_seed(mc.seed)
        model = build_model(mc, len(vocab))
        seqs = make_sequences(sents, vocab, mc.maxlen)
        loss = train_model(model, seqs, mc, log)
        label = preset_label(slot) if use_preset else ""
        meta = self.registry.save(slot, {k: v.detach().cpu() for k, v in model.state_dict().items()}, vocab.itos, mc,
                                  name=name or label or f"version-{slot}", metrics={"final_loss": loss},
                                  extra=dict(sentences=len(sents), preset=label), overwrite=overwrite)
        self._lms.pop(slot, None)
        return slot

    def _lm(self, slot) -> LM:
        if slot is None:
            slot = self.registry.active
        if slot is None:
            raise RuntimeError("no trained weights: call train() first")
        if slot not in self._lms:
            state, vocab_list, mc, _meta = self.registry.load(slot)
            vocab = Vocab(vocab_list)
            model = build_model(mc, len(vocab))
            model.load_state_dict(state)
            self._lms[slot] = LM(model, vocab, {PAD, BOS, UNK}, resolve_device(mc.device))
        return self._lms[slot]

    def _slot(self, version):
        s = version if version is not None else self.registry.active
        if s is None:
            raise RuntimeError("no trained weights: call train() first")
        return s

    def _decode(self, prompts, slot, cfg: DecodeConfig):
        index = self._ensure_index()
        lm = self._lm(slot)
        items = []
        for p in prompts:
            toks = self.tokenizer.words(p)
            it = dict(prompt=p, toks=toks, pad=Scratchpad(p), rule=None, repl=[], cands=[], best=None)
            it["pad"].note("prompt_tokens", tokens=toks)
            r = self.main.consult(toks)
            if r is not None:
                it["rule"] = r
                it["pad"].note("main_bubble", rule=r.name, action=r.action)
            else:
                use = toks
                if cfg.soft and self.matcher is not None:
                    use, it["repl"] = self.matcher.canonicalize(toks, index)
                    if it["repl"]:
                        it["pad"].note("soft_match", replacements=it["repl"])
                it["use"] = use
            items.append(it)
        todo = [i for i, it in enumerate(items) if it["rule"] is None]
        if todo:
            res = beam_search(lm, [items[i]["use"] for i in todo], index, cfg)
            for i, cands in zip(todo, res):
                it = items[i]
                it["best"] = rank_candidates(index, it["use"], cands, cfg, self.config.consensus.ratio)
                it["cands"] = candidate_records(cands, it["best"]) if cands else []
        return items

    def _score(self, it, cfg):
        if it["rule"] is not None:
            return None, 1.0 if it["rule"].action == "respond" else None
        b = it["best"]
        if b is None:
            return None, 0.0
        v = b["ver"] if b["ver"] is not None else confidence(b)
        return " ".join(b["w"]), v

    def _to_answer(self, it, cfg, tau, slot):
        pad = it["pad"]
        if it["rule"] is not None:
            r = it["rule"]
            if r.action == "respond":
                return Answer(r.text, "rule_response", 1.0, tau, f"main bubble: {r.name}", [], [], [], slot, pad)
            return Answer(r.text or self.config.refuse_text, "refused", 0.0, tau, f"main bubble: {r.name}", [], [],
                          [], slot, pad)
        b = it["best"]
        for c in it["cands"]:
            pad.note("candidate", **{k: c[k] for k in ("text", "logp", "verification", "chosen")}, info=c["info"])
        if b is None:
            pad.note("decision", result="abstain", why="no candidate")
            return Answer(self.config.abstain_text, "abstained", 0.0, tau, "no candidate", it["cands"], [],
                          it["repl"], slot, pad)
        text, v = self._score(it, cfg)
        evidence = self.index.best_sentences(list(it["use"]) + b["w"]) if cfg.verify else []
        if tau is not None and v < tau:
            why = "conflict between sources" if b["info"].get("conflict") else (
                "relation not supported" if b["info"].get("relation_failed") else "verification below threshold")
            pad.note("decision", result="abstain", why=why, verification=round(v, 4), tau=tau)
            return Answer(self.config.abstain_text, "abstained", v, tau, why, it["cands"], evidence, it["repl"],
                          slot, pad)
        pad.note("decision", result="answer", verification=round(v, 4), tau=tau)
        return Answer(text, "answered", v, tau, "verified", it["cands"], evidence, it["repl"], slot, pad)

    def _cfg(self, overrides):
        return replace(self.config.decode, **overrides) if overrides else self.config.decode

    def ask_many(self, prompts, version=None, tau="slot", **overrides):
        slot = self._slot(version)
        cfg = self._cfg(overrides)
        if tau == "slot":
            tau = self.registry.meta(slot).get("tau")
        items = self._decode(prompts, slot, cfg)
        return [self._to_answer(it, cfg, tau, slot) for it in items]

    def ask(self, prompt, version=None, tau="slot", **overrides):
        return self.ask_many([prompt], version, tau, **overrides)[0]

    def ask_versions(self, prompt, versions=None, **overrides):
        return {s: self.ask(prompt, s, **overrides) for s in (versions or self.registry.used())}

    def _norm(self, s):
        return " ".join(self.tokenizer.words(s))

    def _examples(self, examples):
        out = []
        for e in examples:
            if isinstance(e, dict):
                out.append((e["prompt"], e.get("truth")))
            else:
                out.append((e[0], e[1]))
        return out

    def _run(self, examples, slot, cfg):
        ex = self._examples(examples)
        items = self._decode([p for p, _ in ex], slot, cfg)
        texts, scores = [], []
        for it in items:
            t, v = self._score(it, cfg)
            texts.append(t)
            scores.append(v)
        truths = [t for _, t in ex]
        return truths, texts, np.array(scores)

    def calibrate(self, examples, version=None, **overrides):
        slot = self._slot(version)
        cfg = self._cfg(overrides)
        truths, texts, score = self._run(examples, slot, cfg)
        unknown, correct, present = ev.arrays(truths, texts, self._norm)
        tau = ev.tune_threshold(score, correct, unknown, present)
        tau = None if tau == float("-inf") else float(tau)
        self.registry.update_meta(slot, tau=tau)
        return tau

    def evaluate(self, examples, version=None, tau="slot", **overrides):
        slot = self._slot(version)
        cfg = self._cfg(overrides)
        if tau == "slot":
            tau = self.registry.meta(slot).get("tau")
        truths, texts, score = self._run(examples, slot, cfg)
        unknown, correct, present = ev.arrays(truths, texts, self._norm)
        m = ev.metrics(score, correct, unknown, present, float("-inf") if tau is None else tau)
        m["recall_at_precision_99"] = ev.recall_at_precision(score, correct, unknown, present, 0.99)
        m["tau"] = tau
        return m

    def compare(self, examples, versions=None, **overrides):
        return {s: dict(name=self.registry.meta(s)["name"], params=self.registry.meta(s)["params"],
                        **self.evaluate(examples, s, **overrides)) for s in (versions or self.registry.used())}

    def fit_visual(self, images):
        from .vision import VisualTokenizer
        self.visual = VisualTokenizer(self.config.vision).fit(images)
        return self.visual

    def _need_visual(self):
        if self.visual is None or not self.visual.ready:
            raise RuntimeError("fit the visual tokenizer first: fit_visual(images)")

    def add_image(self, image, caption="", doc_id=None, meta=None):
        self._need_visual()
        rows = self.visual.image_rows(image)
        paras = self.tokenizer.parse(caption) if caption else []
        m = dict(meta or {})
        m["caption"] = caption
        d = Document(doc_id or f"image{len(self.corpus)}", paras, [rows], "image", m)
        self.corpus.add_document(d)
        self._dirty = True
        return d

    def add_video(self, video, caption="", doc_id=None, meta=None):
        self._need_visual()
        if isinstance(video, (str, bytes)) or hasattr(video, "__fspath__"):
            from .vision import load_video
            frames = load_video(video, self.config.vision.max_frames)
        else:
            frames = list(video)
        paras = self.tokenizer.parse(caption) if caption else []
        m = dict(meta or {})
        m["caption"] = caption
        d = Document(doc_id or f"video{len(self.corpus)}", paras, self.visual.video_paragraphs(frames), "video", m)
        self.corpus.add_document(d)
        self._dirty = True
        return d

    def _media_tokens(self, media, kind):
        self._need_visual()
        if kind == "video":
            if isinstance(media, (str, bytes)) or hasattr(media, "__fspath__"):
                from .vision import load_video
                media = load_video(media, self.config.vision.max_frames)
            return [t for para in self.visual.video_paragraphs(media) for row in para for t in row]
        return [t for row in self.visual.image_rows(media) for t in row]

    def _media_scores(self, media, kind):
        index = self._ensure_index()
        toks = self._media_tokens(media, kind)
        acc, tot = index.activation(toks)
        ranked = []
        if tot > 0:
            for di, v in acc[2].items():
                d = self.corpus.docs[di]
                if d.kind in ("image", "video"):
                    ranked.append((v / tot, d))
            ranked.sort(key=lambda x: -x[0])
        return ranked

    def ask_media(self, media, kind="image", top=3, tau="media"):
        pad = Scratchpad(f"<{kind}>")
        ranked = self._media_scores(media, kind)
        if tau == "media":
            tau = self.media_tau
        ev_ = [dict(doc=d.doc_id, caption=d.meta.get("caption", ""), coverage=round(c, 4)) for c, d in ranked[:top]]
        for e in ev_:
            pad.note("candidate", **e)
        if not ranked:
            return Answer(self.config.abstain_text, "abstained", 0.0, tau, "no matching bubble", [], ev_, [], None, pad)
        c, d = ranked[0]
        if tau is not None and c < tau:
            pad.note("decision", result="abstain", verification=round(c, 4), tau=tau)
            return Answer(self.config.abstain_text, "abstained", c, tau, "verification below threshold", ev_, ev_, [],
                          None, pad)
        pad.note("decision", result="answer", verification=round(c, 4), tau=tau)
        return Answer(d.meta.get("caption", ""), "answered", c, tau, "verified", ev_, ev_, [], None, pad)

    def calibrate_media(self, examples, kind="image"):
        truths, texts, scores, present = [], [], [], []
        for media, truth in examples:
            ranked = self._media_scores(media, kind)
            truths.append(truth)
            texts.append(ranked[0][1].meta.get("caption", "") if ranked else None)
            scores.append(ranked[0][0] if ranked else 0.0)
        unknown, correct, pres = ev.arrays(truths, texts, self._norm)
        tau = ev.tune_threshold(np.array(scores), correct, unknown, pres)
        self.media_tau = None if tau == float("-inf") else float(tau)
        return self.media_tau

    def evaluate_media(self, examples, kind="image"):
        truths, texts, scores = [], [], []
        for media, truth in examples:
            a = self.ask_media(media, kind)
            truths.append(truth)
            texts.append(None if a.abstained else a.text)
            scores.append(a.verification)
        unknown, correct, present = ev.arrays(truths, texts, self._norm)
        return ev.metrics(np.array(scores), correct, unknown, present, float("-inf"))

    def stats(self):
        out = dict(documents=len(self.corpus), versions_used=len(self.registry.used()), versions_max=MAX_VERSIONS)
        if self.index is not None:
            out.update(self.index.sizes())
        return out
