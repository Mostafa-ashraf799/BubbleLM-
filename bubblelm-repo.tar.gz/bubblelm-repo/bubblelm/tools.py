from __future__ import annotations

import ast
import inspect
import operator
import re
import threading
from dataclasses import dataclass, field

_CONVERT = {"int": int, "float": float, "str": str}
_BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
_UNARY = {ast.USub: operator.neg, ast.UAdd: operator.pos}

CALCULATOR_PATTERN = (r"^\s*(?:calculate|compute|calc|what is|what's|\u0627\u062d\u0633\u0628|\u0643\u0645 \u064a\u0633\u0627\u0648\u064a|"
                      r"\u0643\u0645 \u0646\u0627\u062a\u062c|\u0646\u0627\u062a\u062c)\s+"
                      r"(?P<expr>[0-9+\-*/().,^%\u00d7\u00f7 ]*\d[0-9+\-*/().,^%\u00d7\u00f7 ]*?)\s*[?\u061f.!=]*\s*$")
SEARCH_PATTERN = (r"^\s*(?:search for|search|find|look up|\u0627\u0628\u062d\u062b \u0639\u0646|\u062f\u0648\u0631 \u0639\u0644\u0649)\s+"
                  r"(?P<q>.+?)\s*[?\u061f.!]*\s*$")


def format_number(x):
    if isinstance(x, float):
        if x != x or x in (float("inf"), float("-inf")):
            raise ValueError("result is not finite")
        if x == int(x) and abs(x) < 1e15:
            return str(int(x))
        return f"{x:.10g}"
    return str(x)


def safe_eval(expr: str):
    expr = expr.replace("\u00d7", "*").replace("\u00f7", "/").replace("^", "**").replace(",", "").strip()
    if not expr or len(expr) > 200:
        raise ValueError("expression is empty or too long")
    tree = ast.parse(expr, mode="eval")

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and type(n.value) in (int, float):
            return n.value
        if isinstance(n, ast.UnaryOp) and type(n.op) in _UNARY:
            return _UNARY[type(n.op)](ev(n.operand))
        if isinstance(n, ast.BinOp) and type(n.op) in _BIN:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 100:
                raise ValueError("exponent too large")
            r = _BIN[type(n.op)](a, b)
            if isinstance(r, (int, float)) and abs(r) > 1e300:
                raise ValueError("result too large")
            return r
        raise ValueError("unsupported expression")

    return ev(tree)


@dataclass
class Tool:
    name: str
    fn: object
    description: str = ""
    params: dict = field(default_factory=dict)
    patterns: list = field(default_factory=list)
    triggers: list = field(default_factory=list)
    template: str = "{result}"
    raw: bool = False
    timeout: float = 5.0

    def schema(self):
        types = {"int": "integer", "float": "number", "str": "string"}
        props = {k: {"type": types.get(v, "string")} for k, v in self.params.items()}
        return dict(type="function", function=dict(name=self.name, description=self.description,
                                                   parameters=dict(type="object", properties=props,
                                                                   required=list(self.params))))


class ToolRegistry:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        self.tools: dict[str, Tool] = {}

    def register(self, fn=None, *, name=None, description="", params=None, patterns=(), triggers=(),
                 template="{result}", raw=False, timeout=5.0):
        def deco(f):
            tname = name or f.__name__
            if params is not None:
                p = dict(params)
            else:
                p = {}
                for k, v in inspect.signature(f).parameters.items():
                    p[k] = {int: "int", float: "float"}.get(v.annotation, "str")
            self.tools[tname] = Tool(tname, f, description or (f.__doc__ or "").strip(), p,
                                     [re.compile(x, re.IGNORECASE | re.UNICODE) if isinstance(x, str) else x
                                      for x in patterns],
                                     [self.tokenizer.words(t) for t in triggers], template, raw, timeout)
            return f

        return deco(fn) if fn is not None else deco

    def remove(self, name):
        self.tools.pop(name, None)

    def match(self, text):
        norm = self.tokenizer.normalize(text)
        words = self.tokenizer.words(text)
        for t in self.tools.values():
            for pat in t.patterns:
                m = pat.search(norm)
                if not m:
                    continue
                try:
                    args = {k: _CONVERT.get(t.params.get(k, "str"), str)(v.strip())
                            for k, v in m.groupdict().items() if v is not None}
                except ValueError:
                    continue
                return t, args
            if t.raw and any(_contains(words, tr) for tr in t.triggers):
                return t, {"text": text}
        return None

    def run(self, tool: Tool, args: dict):
        box = {}

        def target():
            try:
                box["value"] = tool.fn(**args)
            except Exception as e:
                box["error"] = f"{type(e).__name__}: {e}"

        th = threading.Thread(target=target, daemon=True)
        th.start()
        th.join(tool.timeout)
        if th.is_alive():
            return False, f"timeout after {tool.timeout}s"
        if "error" in box:
            return False, box["error"]
        return True, box.get("value")

    def render(self, tool: Tool, value):
        if isinstance(value, float):
            value = format_number(value)
        return tool.template.format(result=value)

    def schemas(self):
        return [t.schema() for t in self.tools.values()]


def _contains(tokens, phrase):
    m = len(phrase)
    return m > 0 and any(tokens[i:i + m] == phrase for i in range(len(tokens) - m + 1))
