from __future__ import annotations

import gzip
import json
import os
from dataclasses import dataclass, field

from .tokenizer import Tokenizer


@dataclass
class Document:
    doc_id: str
    paragraphs: list
    visual: list = field(default_factory=list)
    kind: str = "text"
    meta: dict = field(default_factory=dict)

    def all_paragraphs(self):
        return list(self.visual) + list(self.paragraphs)


class Corpus:
    def __init__(self, tokenizer: Tokenizer | None = None):
        self.tokenizer = tokenizer or Tokenizer()
        self.docs: list[Document] = []
        self._ids: set[str] = set()

    def __len__(self):
        return len(self.docs)

    def _unique(self, doc_id):
        base, n = doc_id, 1
        while doc_id in self._ids:
            n += 1
            doc_id = f"{base}#{n}"
        self._ids.add(doc_id)
        return doc_id

    def add_text(self, text: str, doc_id: str | None = None, meta: dict | None = None):
        paragraphs = self.tokenizer.parse(text)
        if not paragraphs:
            return None
        doc = Document(self._unique(doc_id or f"doc{len(self.docs)}"), paragraphs, meta=dict(meta or {}))
        self.docs.append(doc)
        return doc

    def add_texts(self, texts, prefix: str = "doc"):
        return [self.add_text(t, f"{prefix}{len(self.docs)}") for t in texts]

    def add_document(self, doc: Document):
        doc.doc_id = self._unique(doc.doc_id)
        self.docs.append(doc)
        return doc

    def add_path(self, path: str):
        added = []
        if os.path.isdir(path):
            for root, _dirs, files in sorted(os.walk(path)):
                for name in sorted(files):
                    added += self.add_path(os.path.join(root, name))
            return added
        ext = os.path.splitext(path)[1].lower()
        with open(path, encoding="utf-8") as f:
            if ext == ".jsonl":
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line:
                        continue
                    row = json.loads(line)
                    d = self.add_text(row["text"], row.get("id", f"{os.path.basename(path)}:{i}"),
                                      {k: v for k, v in row.items() if k not in ("text", "id")})
                    if d:
                        added.append(d)
            elif ext in (".txt", ".md", ""):
                d = self.add_text(f.read(), os.path.basename(path), {"path": path})
                if d:
                    added.append(d)
        return added

    def lm_sentences(self):
        for d in self.docs:
            for p in d.paragraphs:
                for s in p:
                    yield s

    def n_sentences(self):
        return sum(len(p) for d in self.docs for p in d.all_paragraphs())

    def save(self, path: str):
        with gzip.open(path, "wt", encoding="utf-8") as f:
            for d in self.docs:
                f.write(json.dumps({"id": d.doc_id, "kind": d.kind, "meta": d.meta,
                                    "paragraphs": d.paragraphs, "visual": d.visual}, ensure_ascii=False) + "\n")

    @classmethod
    def load(cls, path: str, tokenizer: Tokenizer | None = None):
        c = cls(tokenizer)
        with gzip.open(path, "rt", encoding="utf-8") as f:
            for line in f:
                r = json.loads(line)
                c.add_document(Document(r["id"], r["paragraphs"], r.get("visual", []), r.get("kind", "text"),
                                        r.get("meta", {})))
        return c
