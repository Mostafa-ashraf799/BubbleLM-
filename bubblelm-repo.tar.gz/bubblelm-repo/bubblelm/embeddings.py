from __future__ import annotations

import json
import math

import warnings

import numpy as np
import torch

warnings.filterwarnings("ignore", message="Sparse invariant checks")

from .config import SoftConfig


class SoftMatcher:
    def __init__(self, cfg: SoftConfig | None = None):
        self.cfg = cfg or SoftConfig()
        self.tokens: list[str] = []
        self.vec = np.zeros((0, 0), dtype=np.float32)
        self.count = {}
        self.tidx = {}
        self.targets: list[str] = []
        self.target_mat = np.zeros((0, 0), dtype=np.float32)
        self.target_idx = np.zeros(0, dtype=np.int64)
        self.pairs = np.zeros(0, dtype=np.int64)

    def fit(self, sentences, index=None):
        cfg = self.cfg
        from collections import Counter
        cnt = Counter(t for s in sentences for t in set(s))
        toks = [t for t, _ in cnt.most_common(cfg.max_tokens)]
        self.tokens = toks
        self.tidx = {t: i for i, t in enumerate(toks)}
        self.count = {t: cnt[t] for t in toks}
        V = len(toks)
        rows, cols = [], []
        for s in sentences:
            ids = sorted({self.tidx[t] for t in s if t in self.tidx})
            if len(ids) < 2 or len(ids) > 80:
                continue
            a = np.array(ids)
            i, j = np.meshgrid(a, a, indexing="ij")
            mask = i != j
            rows.append(i[mask])
            cols.append(j[mask])
        if not rows or V < 3:
            self.vec = np.zeros((V, 1), dtype=np.float32)
            self._set_targets(index)
            return self
        r = np.concatenate(rows)
        c = np.concatenate(cols)
        key = r.astype(np.int64) * V + c
        uk, cn = np.unique(key, return_counts=True)
        self.pairs = uk
        r, c = uk // V, uk % V
        cn = cn.astype(np.float64)
        total = cn.sum()
        rs = np.bincount(r, weights=cn, minlength=V)
        cs = np.bincount(c, weights=cn, minlength=V)
        csa = cs ** cfg.alpha
        pc = csa / csa.sum()
        pmi = np.log((cn / total) / ((rs[r] / total) * pc[c] + 1e-12) + 1e-12)
        cnt_arr = np.array([self.count[t] for t in toks])
        keep = (pmi > 0) & (cnt_arr[c] >= cfg.min_context)
        r, c, val = r[keep], c[keep], pmi[keep]
        q = int(min(cfg.dim, V - 1))
        idx = torch.tensor(np.stack([r, c]), dtype=torch.long)
        A = torch.sparse_coo_tensor(idx, torch.tensor(val, dtype=torch.float32), (V, V)).coalesce()
        torch.manual_seed(0)
        U, S, _ = torch.svd_lowrank(A, q=q, niter=4)
        E = (U * S.sqrt()).numpy()
        E /= np.linalg.norm(E, axis=1, keepdims=True) + 1e-9
        self.vec = E.astype(np.float32)
        self._set_targets(index)
        return self

    def _set_targets(self, index):
        self.targets, rows, ids = [], [], []
        if index is None:
            self.target_mat = np.zeros((0, self.vec.shape[1] if self.vec.size else 1), dtype=np.float32)
            return
        for t in self.tokens:
            if index.df.get(t, 0) >= index.rel_min and index.weight(t) > 0:
                self.targets.append(t)
                rows.append(self.vec[self.tidx[t]])
                ids.append(self.tidx[t])
        self.target_idx = np.array(ids, dtype=np.int64)
        self.target_mat = np.stack(rows) if rows else np.zeros((0, self.vec.shape[1]), dtype=np.float32)

    def attach(self, index):
        self._set_targets(index)
        return self

    def nearest(self, token):
        i = self.tidx.get(token)
        if i is None or not len(self.targets):
            return None
        sims = self.target_mat @ self.vec[i]
        if len(self.pairs):
            V = len(self.tokens)
            sims = np.where(np.isin(i * V + self.target_idx, self.pairs), -2.0, sims)
        order = np.argsort(-sims)
        top = float(sims[order[0]])
        second = float(sims[order[1]]) if len(order) > 1 else -1.0
        return self.targets[order[0]], top, top - second

    def alternatives(self, tokens, index, k=3):
        out = []
        for pos, t in enumerate(tokens):
            if index.df.get(t, 0) < index.rel_min or t not in self.tidx or not len(self.targets):
                continue
            i = self.tidx[t]
            sims = self.target_mat @ self.vec[i]
            if len(self.pairs):
                V = len(self.tokens)
                sims = np.where(np.isin(i * V + self.target_idx, self.pairs), -2.0, sims)
            for j in np.argsort(-sims)[:2]:
                if sims[j] >= self.cfg.sim_min and self.targets[j] != t:
                    out.append((float(sims[j]), tokens[:pos] + [self.targets[j]] + tokens[pos + 1:]))
        out.sort(key=lambda x: -x[0])
        seen, res = {tuple(tokens)}, []
        for _, v in out:
            if tuple(v) not in seen:
                seen.add(tuple(v))
                res.append(v)
            if len(res) >= k:
                break
        return res

    def canonicalize(self, tokens, index):
        out, changes = [], []
        for t in tokens:
            if t in index.df or self.count.get(t, 0) < self.cfg.min_source_count:
                out.append(t)
                continue
            n = self.nearest(t)
            if n and n[1] >= self.cfg.sim_min and n[2] >= self.cfg.margin:
                out.append(n[0])
                changes.append(dict(token=t, replaced_by=n[0], similarity=round(n[1], 3)))
            else:
                out.append(t)
        return out, changes

    def save(self, path):
        np.savez_compressed(path, vec=self.vec, pairs=self.pairs, tokens=np.array(json.dumps(self.tokens)),
                            count=np.array(json.dumps(self.count)), cfg=np.array(json.dumps(self.cfg.__dict__)))

    @classmethod
    def load(cls, path, index=None):
        z = np.load(path, allow_pickle=False)
        m = cls(SoftConfig(**json.loads(str(z["cfg"]))))
        m.vec = z["vec"]
        m.pairs = z["pairs"]
        m.tokens = json.loads(str(z["tokens"]))
        m.count = json.loads(str(z["count"]))
        m.tidx = {t: i for i, t in enumerate(m.tokens)}
        m._set_targets(index)
        return m
