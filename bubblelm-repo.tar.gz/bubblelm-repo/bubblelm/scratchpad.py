from __future__ import annotations

import time


class Scratchpad:
    def __init__(self, prompt: str = ""):
        self.prompt = prompt
        self.entries: list[dict] = []
        self.started = time.time()

    def note(self, kind: str, **data):
        self.entries.append(dict(kind=kind, **data))

    def of(self, kind: str):
        return [e for e in self.entries if e["kind"] == kind]

    def to_dict(self):
        return dict(prompt=self.prompt, entries=self.entries)

    def render(self) -> str:
        lines = [f"prompt: {self.prompt}"]
        for e in self.entries:
            rest = ", ".join(f"{k}={v}" for k, v in e.items() if k != "kind")
            lines.append(f"[{e['kind']}] {rest}")
        return "\n".join(lines)
