from __future__ import annotations

import math
from dataclasses import dataclass, field

from .config import LEVELS, DecodeConfig
from .scratchpad import Scratchpad
from .tokenizer import BOS, EOS, PAD, UNK


@dataclass
class Answer:
    text: str | None
    status: str
    verification: float = 0.0
    tau: float | None = None
    reason: str = ""
    candidates: list = field(default_factory=list)
    evidence: list = field(default_factory=list)
    replacements: list = field(default_factory=list)
    version: int | None = None
    scratchpad: Scratchpad | None = None

    @property
    def abstained(self):
        return self.status in ("abstained", "refused")

    def as_dict(self):
        return dict(text=self.text, status=self.status, verification=self.verification, tau=self.tau,
                    reason=self.reason, candidates=self.candidates, evidence=self.evidence,
                    replacements=self.replacements, version=self.version,
                    scratchpad=self.scratchpad.to_dict() if self.scratchpad else None)


def beam_search(lm, prompts, index, cfg: DecodeConfig):
    Q = len(prompts)
    maxlen = getattr(lm.model, "maxlen", None)
    limit = (maxlen - cfg.max_new - 2) if maxlen else 10 ** 9
    base = [[BOS] + lm.vocab.encode(p[-limit:]) for p in prompts]
    beams = [[dict(s=0.0, v=0.0, w=[], done=False)] for _ in range(Q)]
    levels = LEVELS[cfg.level]
    nudge = cfg.lam > 0 and index is not None
    cache = {}
    for _ in range(cfg.max_new + 1):
        reqs = [(q, i) for q in range(Q) for i, b in enumerate(beams[q]) if not b["done"]]
        if not reqs:
            break
        seqs = [base[q] + lm.vocab.encode(beams[q][i]["w"]) for q, i in reqs]
        lp = lm.next_logp(seqs)
        lp[:, lm.bad] = -1e9
        topv, topi = lp.topk(min(cfg.topk, lp.size(-1)), dim=-1)
        topv, topi = topv.tolist(), topi.tolist()
        new = [[b for b in beams[q] if b["done"]] for q in range(Q)]
        for r, (q, i) in enumerate(reqs):
            b = beams[q][i]
            if nudge:
                key = (q, tuple(b["w"]))
                if key not in cache:
                    cache[key] = index.activation(list(prompts[q]) + b["w"])
                acc, tot = cache[key]
            for v, ti in zip(topv[r], topi[r]):
                if v < -1e8:
                    continue
                if ti == EOS:
                    if b["w"]:
                        new[q].append(dict(s=b["s"] + v, v=b["v"], w=b["w"], done=True))
                    continue
                if len(b["w"]) >= cfg.max_new:
                    continue
                w = lm.vocab.itos[ti]
                s = b["s"] + v
                if nudge:
                    s += cfg.lam * index.cand_support(acc, tot, w, levels)
                new[q].append(dict(s=s, v=b["v"] + v, w=b["w"] + [w], done=False))
        for q in range(Q):
            new[q].sort(key=lambda x: -x["s"])
            beams[q] = new[q][:cfg.beam]
    return [[b for b in beams[q] if b["w"]] for q in range(Q)]


def rank_candidates(index, prompt, cands, cfg: DecodeConfig, ratio: float):
    for b in cands:
        if cfg.verify and index is not None:
            b["ver"], b["info"] = index.verify(prompt, b["w"], cfg.level, cfg.relation, cfg.consensus, ratio)
        else:
            b["ver"], b["info"] = None, {}
    if not cands:
        return None
    return max(cands, key=lambda b: b["s"] + (cfg.mu * b["ver"] if b["ver"] is not None else 0.0))


def candidate_records(cands, best):
    out = []
    for b in sorted(cands, key=lambda x: -x["s"]):
        out.append(dict(text=" ".join(b["w"]), logp=round(b["v"], 3), score=round(b["s"], 3),
                        verification=None if b["ver"] is None else round(b["ver"], 4),
                        info=b["info"], chosen=b is best))
    return out


def confidence(best):
    return math.exp(best["v"]) if best else 0.0
