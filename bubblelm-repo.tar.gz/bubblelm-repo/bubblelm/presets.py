from __future__ import annotations

from dataclasses import replace

import torch

from .config import MAX_VERSIONS, ModelConfig

REFERENCE_VOCAB = 32000
REFERENCE_MAXLEN = 2048

TARGETS = [
    ("100M", 100e6), ("500M", 500e6), ("1B", 1e9), ("1.5B", 1.5e9), ("2B", 2e9), ("2.5B", 2.5e9),
    ("3B", 3e9), ("4B", 4e9), ("5B", 5e9), ("6B", 6e9), ("8B", 8e9), ("10B", 10e9), ("12B", 12e9),
    ("14B", 14e9), ("16B", 16e9), ("18B", 18e9), ("20B", 20e9), ("24B", 24e9), ("27B", 27e9),
    ("30B", 30e9),
]
assert len(TARGETS) == MAX_VERSIONS


def estimate_params(d, layers, vocab=REFERENCE_VOCAB, maxlen=REFERENCE_MAXLEN):
    per_block = 12 * d * d + 13 * d
    return 2 * vocab * d + maxlen * d + layers * per_block + 2 * d


def _search(target):
    best = None
    for d in range(256, 12288 + 1, 128):
        for layers in range(4, 129):
            ratio = d / layers
            if ratio < 40 or ratio > 170:
                continue
            err = abs(estimate_params(d, layers) - target) / target
            score = err + 0.004 * abs(ratio - 90) / 90
            if best is None or score < best[0]:
                best = (score, d, layers)
    _, d, layers = best
    return d, layers


def _heads(d):
    return max(4, d // 128)


def preset(slot: int, **overrides) -> ModelConfig:
    if not 1 <= slot <= MAX_VERSIONS:
        raise ValueError(f"slot must be between 1 and {MAX_VERSIONS}")
    label, target = TARGETS[slot - 1]
    d, layers = _search(target)
    cfg = ModelConfig(arch="transformer", d_model=d, layers=layers, heads=_heads(d), maxlen=REFERENCE_MAXLEN,
                      epochs=1, lr=3e-4 if target >= 1e9 else 6e-4, batch_size=32, dtype="bfloat16")
    return replace(cfg, **overrides)


def preset_label(slot: int) -> str:
    return TARGETS[slot - 1][0]


def exact_params(cfg: ModelConfig, vocab_size: int = REFERENCE_VOCAB) -> int:
    from .model import build_model
    with torch.device("meta"):
        m = build_model(cfg, vocab_size)
    return sum(p.numel() for p in m.parameters())


def table(vocab_size: int = REFERENCE_VOCAB):
    rows = []
    for slot in range(1, MAX_VERSIONS + 1):
        cfg = preset(slot)
        n = exact_params(cfg, vocab_size)
        rows.append(dict(slot=slot, label=preset_label(slot), d_model=cfg.d_model, layers=cfg.layers,
                         heads=cfg.heads, params=n, fp32_gb=n * 4 / 1e9, bf16_gb=n * 2 / 1e9))
    return rows
