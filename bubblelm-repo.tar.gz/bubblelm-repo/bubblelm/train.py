from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import ModelConfig
from .model import resolve_device
from .tokenizer import BOS, EOS, PAD


def make_sequences(sentences, vocab, maxlen):
    seqs = []
    for s in sentences:
        ids = vocab.encode(s)[: maxlen - 2]
        seqs.append([BOS] + ids + [EOS])
    return seqs


def train_model(model, seqs, cfg: ModelConfig, log=None):
    if cfg.threads:
        torch.set_num_threads(cfg.threads)
    torch.manual_seed(cfg.seed)
    device = resolve_device(cfg.device)
    model.to(device)
    amp = cfg.dtype == "bfloat16"
    N = len(seqs)
    if N == 0:
        raise ValueError("no training sequences")
    Lmax = max(len(s) for s in seqs)
    X = torch.zeros(N, Lmax, dtype=torch.long)
    lens = torch.tensor([len(s) for s in seqs])
    for i, s in enumerate(seqs):
        X[i, :len(s)] = torch.tensor(s)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    bs = cfg.batch_size
    total = max(20, cfg.epochs * math.ceil(N / bs))
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=cfg.lr, total_steps=total, pct_start=0.1)
    model.train()
    last = 0.0
    for ep in range(cfg.epochs):
        perm = torch.randperm(N)
        tot, cnt = 0.0, 0
        for i in range(0, N, bs):
            idx = perm[i:i + bs]
            xb = X[idx, : int(lens[idx].max())].to(device)
            with torch.autocast(device_type=device if device != "mps" else "cpu", dtype=torch.bfloat16, enabled=amp):
                logits = model(xb[:, :-1])
            loss = F.cross_entropy(logits.float().reshape(-1, logits.size(-1)), xb[:, 1:].reshape(-1), ignore_index=PAD)
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            sched.step()
            tot += loss.item()
            cnt += 1
        last = tot / cnt
        if log and (ep % max(1, cfg.epochs // 5) == 0 or ep == cfg.epochs - 1):
            log(f"epoch {ep + 1}/{cfg.epochs} loss={last:.4f}")
    model.eval().to("cpu")
    return last
