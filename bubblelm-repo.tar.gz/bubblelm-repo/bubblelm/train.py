from __future__ import annotations

import math
import os

import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F

from .config import ModelConfig
from .model import resolve_device
from .tokenizer import BOS, EOS, PAD


def make_sequences(sentences, vocab, maxlen):
    seqs = []
    for s in sentences:
        ids = vocab.encode(s)[: maxlen - 2]
        seqs.append([BOS] + ids + [EOS])
    return seqs


def is_main():
    return not (dist.is_available() and dist.is_initialized()) or dist.get_rank() == 0


def _setup_distributed(device):
    if not (dist.is_available() and "RANK" in os.environ and "WORLD_SIZE" in os.environ):
        raise RuntimeError("distributed training needs launching with torchrun (RANK and WORLD_SIZE are not set)")
    if not dist.is_initialized():
        dist.init_process_group("nccl" if device == "cuda" else "gloo")
    if device == "cuda":
        torch.cuda.set_device(int(os.environ.get("LOCAL_RANK", 0)))
    return dist.get_rank(), dist.get_world_size()


def train_model(model, seqs, cfg: ModelConfig, log=None):
    if cfg.threads:
        torch.set_num_threads(cfg.threads)
    torch.manual_seed(cfg.seed)
    device = resolve_device(cfg.device)
    rank, world = _setup_distributed(device) if cfg.distributed else (0, 1)
    if cfg.distributed and device == "cuda":
        device = f"cuda:{int(os.environ.get('LOCAL_RANK', 0))}"
    model.to(device)
    if hasattr(model, "checkpointing"):
        model.checkpointing = cfg.checkpoint
    wrapped = nn.parallel.DistributedDataParallel(model, device_ids=[device] if device.startswith("cuda") else None) \
        if world > 1 else model
    amp = cfg.dtype == "bfloat16"
    N = len(seqs)
    if N == 0:
        raise ValueError("no training sequences")
    Lmax = max(len(s) for s in seqs)
    X = torch.zeros(N, Lmax, dtype=torch.long)
    lens = torch.tensor([len(s) for s in seqs])
    for i, s in enumerate(seqs):
        X[i, :len(s)] = torch.tensor(s)
    opt = torch.optim.AdamW(wrapped.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    bs = cfg.batch_size
    accum = max(1, cfg.grad_accum)
    per_rank = math.ceil(N / world)
    steps_per_epoch = max(1, math.ceil(per_rank / (bs * accum)))
    total = max(20, cfg.epochs * steps_per_epoch)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=cfg.lr, total_steps=total, pct_start=0.1)
    wrapped.train()
    last = 0.0
    for ep in range(cfg.epochs):
        g = torch.Generator().manual_seed(cfg.seed * 100003 + ep)
        perm = torch.randperm(N, generator=g)
        if world > 1:
            pad = per_rank * world - N
            if pad:
                perm = torch.cat([perm, perm[:pad]])
            perm = perm[rank::world]
        tot, cnt = 0.0, 0
        step_batches = [perm[i:i + bs] for i in range(0, len(perm), bs)]
        for s0 in range(0, len(step_batches), accum):
            group = step_batches[s0:s0 + accum]
            opt.zero_grad()
            for j, idx in enumerate(group):
                xb = X[idx, : int(lens[idx].max())].to(device)
                sync = world == 1 or j == len(group) - 1
                ctx = torch.autocast(device_type="cuda" if device.startswith("cuda") else "cpu",
                                     dtype=torch.bfloat16, enabled=amp)
                with ctx:
                    if sync:
                        logits = wrapped(xb[:, :-1])
                    else:
                        with wrapped.no_sync():
                            logits = wrapped(xb[:, :-1])
                loss = F.cross_entropy(logits.float().reshape(-1, logits.size(-1)), xb[:, 1:].reshape(-1),
                                       ignore_index=PAD)
                if sync:
                    (loss / len(group)).backward()
                else:
                    with wrapped.no_sync():
                        (loss / len(group)).backward()
                tot += loss.item()
                cnt += 1
            nn.utils.clip_grad_norm_(wrapped.parameters(), 1.0)
            opt.step()
            sched.step()
        last = tot / max(cnt, 1)
        if log and is_main() and (ep % max(1, cfg.epochs // 5) == 0 or ep == cfg.epochs - 1):
            log(f"epoch {ep + 1}/{cfg.epochs} loss={last:.4f}")
    if hasattr(model, "checkpointing"):
        model.checkpointing = False
    model.eval().to("cpu")
    if world > 1:
        dist.barrier()
    return last
