from __future__ import annotations

QUESTION_WORDS = frozenset("""
where what who whom whose which when how why does do did is are was were can could will would should
please tell me us about
هل ما ماذا من اين اين فين ايه مين ازاي كيف متي متى لماذا ليه هو هي
""".split())

_EN_SUFFIXES = ("ing", "es", "ed", "s")
_AR_PREFIXES = ("ال", "و", "ب", "ل", "ف")


def stem(word):
    w = word
    if len(w) > 4:
        for p in _AR_PREFIXES:
            if w.startswith(p) and len(w) - len(p) >= 3:
                w = w[len(p):]
                break
    for s in _EN_SUFFIXES:
        if len(w) > len(s) + 2 and w.endswith(s):
            w = w[: -len(s)]
            break
    if len(w) > 3 and w.endswith("e"):
        w = w[:-1]
    return w


class QuestionAdapter:
    def __init__(self, index, tokenizer, matcher=None):
        self.index = index
        self.tokenizer = tokenizer
        self.matcher = matcher
        by_stem = {}
        for t, d in index.df.items():
            s = stem(t)
            if s not in by_stem or d > index.df[by_stem[s]]:
                by_stem[s] = t
        self.by_stem = by_stem

    def _map(self, tokens):
        out, fillers, mapped = [], [], []
        for t in tokens:
            if t in QUESTION_WORDS:
                continue
            if t in self.index.df:
                out.append(t)
                continue
            alt = self.by_stem.get(stem(t))
            if alt is not None:
                out.append(alt)
                mapped.append((t, alt))
                continue
            out.append(t)
            fillers.append(t)
        if self.matcher is not None:
            out, repl = self.matcher.canonicalize(out, self.index)
            fillers = [t for t in fillers if t in out]
        return out, fillers, mapped

    def prefixes(self, question, k=3):
        ix = self.index
        tokens = self.tokenizer.words(question)
        content, fillers, mapped = self._map(tokens)
        if not content:
            return []
        acc, tot = ix.activation(content)
        if tot == 0:
            return []
        known = set(content)
        pool = set()
        for t in known:
            pool.update(int(i) for i in ix.inv[0].get(t, ()))
        if not pool:
            return []
        cand = sorted(pool, key=lambda i: (-float(acc[0][i]), i))[: max(k * 12, 40)]
        overlap = {i: len(known & set(ix.sent_tokens[i])) for i in cand}
        order = sorted(cand, key=lambda i: (-round(float(acc[0][i]), 9), -overlap[i], i))
        seen, results = set(), []
        for sid in order:
            sent = ix.sent_tokens[sid]
            pos = [j for j, t in enumerate(sent) if t in known]
            if not pos:
                continue
            last = max(pos)
            while last + 1 < len(sent) and ix.weight(sent[last + 1]) == 0:
                last += 1
            if last + 1 >= len(sent):
                continue
            queue = list(fillers)
            prefix, ok = [], True
            for t in sent[: last + 1]:
                if t in known or ix.weight(t) == 0 or ix.df.get(t, 0) >= ix.rel_min:
                    prefix.append(t)
                elif queue:
                    prefix.append(queue.pop(0))
                else:
                    ok = False
                    break
            if not ok:
                continue
            for t in queue:
                prefix.insert(0, t)
            text = " ".join(prefix)
            if text in seen:
                continue
            seen.add(text)
            results.append(dict(prefix=text, coverage=round(float(acc[0][sid]) / tot, 3),
                                template=" ".join(sent), mapped=mapped))
            if len(results) >= k:
                break
        return results
