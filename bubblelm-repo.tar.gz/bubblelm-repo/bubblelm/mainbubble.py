from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field


@dataclass
class Rule:
    name: str
    action: str
    when_any: list = field(default_factory=list)
    when_all: list = field(default_factory=list)
    text: str = ""


IDENTITY_TRIGGERS = {
    "name": [["your", "name"], ["who", "are", "you"], ["what", "are", "you", "called"],
             ["اسمك"], ["من", "انت"], ["مين", "انت"], ["ما", "اسمك"]],
    "company": [["who", "made", "you"], ["who", "created", "you"], ["your", "company"], ["who", "built", "you"],
                ["شركتك"], ["من", "صنعك"], ["مين", "عملك"], ["من", "طورك"]],
}


class MainBubble:
    def __init__(self, tokenizer, rules=None, identity=None):
        self.tokenizer = tokenizer
        self.rules: list[Rule] = list(rules or [])
        self.identity = dict(identity or {})

    def set_identity(self, name=None, company=None):
        if name is not None:
            self.identity["name"] = name
        if company is not None:
            self.identity["company"] = company
        self.rules = [r for r in self.rules if not r.name.startswith("identity:")]
        if "name" in self.identity:
            self.rules.append(Rule("identity:name", "respond", IDENTITY_TRIGGERS["name"], [],
                                   f"My name is {self.identity['name']}."))
        if "company" in self.identity:
            self.rules.append(Rule("identity:company", "respond", IDENTITY_TRIGGERS["company"], [],
                                   f"I was made by {self.identity['company']}."))

    def add_rule(self, name, action, when_any=(), when_all=(), text=""):
        if action not in ("respond", "refuse"):
            raise ValueError("action must be 'respond' or 'refuse'")
        self.rules = [r for r in self.rules if r.name != name]
        self.rules.append(Rule(name, action, [self._norm(p) for p in when_any], [self._norm(p) for p in when_all], text))

    def remove_rule(self, name):
        self.rules = [r for r in self.rules if r.name != name]

    def _norm(self, phrase):
        if isinstance(phrase, str):
            return self.tokenizer.words(phrase)
        return [w for p in phrase for w in self.tokenizer.words(p)]

    @staticmethod
    def _contains(tokens, phrase):
        m = len(phrase)
        return m > 0 and any(tokens[i:i + m] == phrase for i in range(len(tokens) - m + 1))

    def consult(self, tokens):
        t = list(tokens)
        for r in self.rules:
            any_ok = (not r.when_any) or any(self._contains(t, list(p)) for p in r.when_any)
            all_ok = all(self._contains(t, list(p)) for p in r.when_all)
            if (r.when_any or r.when_all) and any_ok and all_ok:
                return r
        return None

    def to_dict(self):
        return dict(identity=self.identity, rules=[asdict(r) for r in self.rules])

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, path, tokenizer):
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        mb = cls(tokenizer, [Rule(**r) for r in d.get("rules", [])], d.get("identity", {}))
        return mb
