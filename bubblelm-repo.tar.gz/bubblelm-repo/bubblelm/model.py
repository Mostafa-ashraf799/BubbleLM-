from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import ModelConfig
from .tokenizer import UNK


class Block(nn.Module):
    def __init__(self, d, heads):
        super().__init__()
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.att = nn.MultiheadAttention(d, heads, batch_first=True)
        self.ff = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))

    def forward(self, x, mask):
        h = self.ln1(x)
        a, _ = self.att(h, h, h, attn_mask=mask, need_weights=False)
        x = x + a
        return x + self.ff(self.ln2(x))


class TransformerLM(nn.Module):
    def __init__(self, vocab_size, d=96, layers=3, heads=4, maxlen=48):
        super().__init__()
        self.emb, self.pos = nn.Embedding(vocab_size, d), nn.Embedding(maxlen, d)
        self.blocks = nn.ModuleList([Block(d, heads) for _ in range(layers)])
        self.ln, self.out = nn.LayerNorm(d), nn.Linear(d, vocab_size)
        self.maxlen = maxlen

    def forward(self, x):
        T = x.size(1)
        h = self.emb(x) + self.pos(torch.arange(T, device=x.device))
        mask = torch.triu(torch.ones(T, T, dtype=torch.bool, device=x.device), 1)
        for b in self.blocks:
            h = b(h, mask)
        return self.out(self.ln(h))


class GRULM(nn.Module):
    def __init__(self, vocab_size, d=96, hidden=192, layers=2):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, d)
        self.rnn = nn.GRU(d, hidden, num_layers=layers, batch_first=True)
        self.out = nn.Linear(hidden, vocab_size)

    def forward(self, x):
        o, _ = self.rnn(self.emb(x))
        return self.out(o)


def build_model(cfg: ModelConfig, vocab_size: int):
    if cfg.arch == "transformer":
        return TransformerLM(vocab_size, cfg.d_model, cfg.layers, cfg.heads, cfg.maxlen)
    if cfg.arch == "gru":
        return GRULM(vocab_size, cfg.d_model, cfg.hidden, max(1, cfg.layers - 1))
    raise ValueError(f"unknown architecture: {cfg.arch}")


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def resolve_device(name):
    if name == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    return name


class LM:
    def __init__(self, model, vocab, bad_ids, device="cpu"):
        self.device = device
        self.model = model.to(device).eval()
        self.vocab = vocab
        self.bad = torch.tensor(sorted(bad_ids), dtype=torch.long)

    def id(self, w):
        return self.vocab.stoi.get(w, UNK)

    @torch.no_grad()
    def next_logp(self, seqs, chunk=1024):
        outs = []
        for c in range(0, len(seqs), chunk):
            part = seqs[c:c + chunk]
            L = max(len(s) for s in part)
            x = torch.zeros(len(part), L, dtype=torch.long)
            for i, s in enumerate(part):
                x[i, :len(s)] = torch.tensor(s)
            logits = self.model(x.to(self.device))
            idx = torch.tensor([len(s) - 1 for s in part], device=self.device)
            last = logits[torch.arange(len(part), device=self.device), idx].float()
            outs.append(F.log_softmax(last, -1).cpu())
        return torch.cat(outs, 0)
