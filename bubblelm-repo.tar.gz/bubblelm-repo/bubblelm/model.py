from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from .config import ModelConfig
from .tokenizer import UNK


class Attention(nn.Module):
    def __init__(self, d, heads):
        super().__init__()
        self.heads = heads
        self.in_proj = nn.Linear(d, 3 * d)
        self.out_proj = nn.Linear(d, d)

    def forward(self, x, past=None):
        B, T, D = x.shape
        H = self.heads
        q, k, v = self.in_proj(x).chunk(3, dim=-1)
        q, k, v = (t.view(B, T, H, D // H).transpose(1, 2) for t in (q, k, v))
        if past is not None:
            k = torch.cat([past[0], k], dim=2)
            v = torch.cat([past[1], v], dim=2)
            Tk = k.size(2)
            mask = torch.ones(T, Tk, dtype=torch.bool, device=x.device).tril(diagonal=Tk - T)
            out = F.scaled_dot_product_attention(q, k, v, attn_mask=mask)
        else:
            out = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        out = out.transpose(1, 2).reshape(B, T, D)
        return self.out_proj(out), (k, v)


class Block(nn.Module):
    def __init__(self, d, heads):
        super().__init__()
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.att = Attention(d, heads)
        self.ff = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))

    def forward(self, x, past=None):
        a, present = self.att(self.ln1(x), past)
        x = x + a
        return x + self.ff(self.ln2(x)), present


class TransformerLM(nn.Module):
    supports_cache = True

    def __init__(self, vocab_size, d=96, layers=3, heads=4, maxlen=48):
        super().__init__()
        self.emb, self.pos = nn.Embedding(vocab_size, d), nn.Embedding(maxlen, d)
        self.blocks = nn.ModuleList([Block(d, heads) for _ in range(layers)])
        self.ln, self.out = nn.LayerNorm(d), nn.Linear(d, vocab_size)
        self.maxlen = maxlen
        self.checkpointing = False

    def forward(self, x, past=None, use_cache=False):
        T = x.size(1)
        start = 0 if past is None else past[0][0].size(2)
        h = self.emb(x) + self.pos(torch.arange(start, start + T, device=x.device))
        presents = []
        for i, b in enumerate(self.blocks):
            if self.checkpointing and self.training and past is None and not use_cache:
                h = checkpoint(lambda t, blk=b: blk(t)[0], h, use_reentrant=False)
                continue
            h, pr = b(h, None if past is None else past[i])
            presents.append(pr)
        logits = self.out(self.ln(h))
        return (logits, presents) if use_cache else logits


class GRULM(nn.Module):
    supports_cache = False

    def __init__(self, vocab_size, d=96, hidden=192, layers=2):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, d)
        self.rnn = nn.GRU(d, hidden, num_layers=layers, batch_first=True)
        self.out = nn.Linear(hidden, vocab_size)

    def forward(self, x):
        o, _ = self.rnn(self.emb(x))
        return self.out(o)


def build_model(cfg: ModelConfig, vocab_size: int):
    if cfg.arch == "transformer":
        return TransformerLM(vocab_size, cfg.d_model, cfg.layers, cfg.heads, cfg.maxlen)
    if cfg.arch == "gru":
        return GRULM(vocab_size, cfg.d_model, cfg.hidden, max(1, cfg.layers - 1))
    raise ValueError(f"unknown architecture: {cfg.arch}")


def restore_state(state):
    return {k: v.float() if v.is_floating_point() and v.dtype == torch.float16 else v for k, v in state.items()}


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def resolve_device(name):
    if name == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    return name


def quantize_int8(model):
    return torch.ao.quantization.quantize_dynamic(model.float().cpu(), {nn.Linear, nn.GRU}, dtype=torch.qint8)


class LM:
    def __init__(self, model, vocab, bad_ids, device="cpu", quantize=False):
        self.device = "cpu" if quantize else device
        self.quantized = quantize
        model = quantize_int8(model) if quantize else model
        self.model = model.to(self.device).eval()
        self.vocab = vocab
        self.bad = torch.tensor(sorted(bad_ids), dtype=torch.long)
        self.cacheable = bool(getattr(model, "supports_cache", False))

    def id(self, w):
        return self.vocab.stoi.get(w, UNK)

    @torch.no_grad()
    def next_logp(self, seqs, chunk=1024):
        outs = []
        for c in range(0, len(seqs), chunk):
            part = seqs[c:c + chunk]
            L = max(len(s) for s in part)
            x = torch.zeros(len(part), L, dtype=torch.long)
            for i, s in enumerate(part):
                x[i, :len(s)] = torch.tensor(s)
            logits = self.model(x.to(self.device))
            idx = torch.tensor([len(s) - 1 for s in part], device=self.device)
            last = logits[torch.arange(len(part), device=self.device), idx].float()
            outs.append(F.log_softmax(last, -1).cpu())
        return torch.cat(outs, 0)

    @torch.no_grad()
    def prime(self, bases):
        groups = {}
        for q, ids in enumerate(bases):
            groups.setdefault(len(ids), []).append(q)
        state = {}
        for L, qs in groups.items():
            x = torch.tensor([bases[q] for q in qs], dtype=torch.long, device=self.device)
            logits, past = self.model(x, use_cache=True)
            state[L] = dict(rows={q: r for r, q in enumerate(qs)}, past=past,
                            first=F.log_softmax(logits[:, -1].float(), -1).cpu())
        return state

    @torch.no_grad()
    def step(self, state, bases, reqs):
        out = [None] * len(reqs)
        by_len = {}
        for n, (q, tail) in enumerate(reqs):
            by_len.setdefault(len(bases[q]), []).append(n)
        for L, ns in by_len.items():
            st = state[L]
            rows = [st["rows"][reqs[n][0]] for n in ns]
            if not reqs[ns[0]][1]:
                lp = st["first"][rows]
            else:
                ridx = torch.tensor(rows, device=self.device)
                past = [(k.index_select(0, ridx), v.index_select(0, ridx)) for k, v in st["past"]]
                x = torch.tensor([reqs[n][1] for n in ns], dtype=torch.long, device=self.device)
                logits = self.model(x, past=past)
                lp = F.log_softmax(logits[:, -1].float(), -1).cpu()
            for j, n in enumerate(ns):
                out[n] = lp[j]
        return torch.stack(out)
